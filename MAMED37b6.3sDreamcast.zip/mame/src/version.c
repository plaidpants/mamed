char build_version[] = "0.37 BETA 6 ("__DATE__")";
