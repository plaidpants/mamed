#define SPLIT

#include "cpuintrf.c"
