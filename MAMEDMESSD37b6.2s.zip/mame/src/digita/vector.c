#include "driver.h"
#include <math.h>

/* Scale the vector games to a given resolution */
void scale_vectorgames(int gfx_width,int gfx_height,int *width,int *height)
{
	float x_scale, y_scale, scale;

	if (Machine->orientation & ORIENTATION_SWAP_XY)
	{
		x_scale=(float)gfx_width/(float)(*height);
		y_scale=(float)gfx_height/(float)(*width);
	}
	else
	{
		x_scale=(float)gfx_width/(float)(*width);
		y_scale=(float)gfx_height/(float)(*height);
	}
	if (x_scale<y_scale)
		scale=x_scale;
	else
		scale=y_scale;
	*width=(int)((float)*width*scale);
	*height=(int)((float)*height*scale);

	/* Padding to an dword value */
	*width-=*width % 4;
	*height-=*height % 4;
}
