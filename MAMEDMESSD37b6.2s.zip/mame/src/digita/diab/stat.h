/* stat.h - POSIX definitions for obtaining file characteristics */

#ifndef __STAT_H
#define __STAT_H

#ifdef __cplusplus
extern "C" {
#endif

#if ((CPU_FAMILY==I960) && (defined __GNUC__))
#pragma align 1
#endif

#define	TIME unsigned long
#define STATUS int

struct	stat
{
unsigned long st_dev;
unsigned long st_ino;
unsigned short st_mode;
short st_nlink;
short st_uid;
short st_gid;
unsigned long st_rdev;
unsigned long st_size;
TIME st_atime;
TIME st_mtime;
TIME st_ctime;
long st_blksize;
long st_blocks;
unsigned char st_attrib;
int	reserved1;
int	reserved2;
int	reserved3;
int	reserved4;
int	reserved5;
int	reserved6;
};

typedef struct
{
long val[2];
} fsid_t;

struct statfs
{
long f_type;
long f_bsize;
long f_blocks;
long f_bfree;
long f_bavail;
long f_files;
long f_ffree;
fsid_t f_fsid;
long f_spare[7];
};

#define	S_IFMT	 0xf000
#define	S_IFIFO	 0x1000
#define	S_IFCHR	 0x2000
#define	S_IFDIR	 0x4000
#define	S_IFBLK	 0x6000
#define	S_IFREG	 0x8000
#define	S_IFLNK	 0xa000
#define	S_IFSOCK 0xc000
#define	S_ISUID 0x0800
#define	S_ISGID 0x0400
#define	S_IRUSR 0x0100
#define	S_IWUSR 0x0080
#define	S_IXUSR 0x0040
#define	S_IRWXU 0x01c0
#define	S_IRGRP 0x0020
#define	S_IWGRP 0x0010
#define	S_IXGRP 0x0008
#define	S_IRWXG 0x0038
#define	S_IROTH 0x0004	
#define	S_IWOTH 0x0002
#define	S_IXOTH 0x0001
#define	S_IRWXO 0x0007

#define	S_ISDIR(mode) ((mode & S_IFMT) == S_IFDIR)
#define	S_ISCHR(mode) ((mode & S_IFMT) == S_IFCHR)
#define	S_ISBLK(mode) ((mode & S_IFMT) == S_IFBLK)
#define	S_ISREG(mode) ((mode & S_IFMT) == S_IFREG)
#define	S_ISFIFO(mode) ((mode & S_IFMT) == S_IFIFO)

#if defined(__STDC__) || defined(__cplusplus)
extern STATUS mkdir(char *dirName);
extern STATUS fstat(int fd, struct stat *pStat);
extern STATUS stat(char *name, struct stat *pStat);
extern STATUS fstatfs(int fd, struct statfs *pStat);
extern STATUS statfs(char *name, struct statfs *pStat);
#else
extern STATUS mkdir();
extern STATUS fstat();
extern STATUS stat();
extern STATUS fstatfs();
extern STATUS statfs();
#endif

#if ((CPU_FAMILY==I960) && (defined __GNUC__))
#pragma align 0
#endif

#ifdef __cplusplus
}
#endif

#endif

