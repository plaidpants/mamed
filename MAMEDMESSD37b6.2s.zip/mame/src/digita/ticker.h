#include "osd_cpu.h"


#define TICKER int
#define TICKS_PER_SEC sysClkRateGet()
#define ticker tickGet
