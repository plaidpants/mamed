/* The HPC500 & Minolta 1500 EX are missing some GNU generated functions so I will force
   them to be included here. */
   
extern void __divdi3(void);
extern void __umoddi3(void);
extern void __udivdi3(void);
extern void __moddi3(void);
extern void __fixunssfsi(void);

void * missing[] = {
__divdi3,
__umoddi3,
__udivdi3,
__moddi3,
__fixunssfsi
};