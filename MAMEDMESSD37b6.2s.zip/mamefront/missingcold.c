/* The Coldfire is missing some diab generated functions so I will force
   them to be included here. */

extern void udiv64(void);
extern void umul64(void);
extern void lsl64(void);
extern void lsr64(void);
extern void __adddf3(void);
extern void __addsf3(void);
extern void __assert(void);
extern void __ctype(void);
extern void __divdf3(void);
extern void __divsf3(void);
extern void __eqdf2(void);
extern void __eqsf2(void);
extern void __errno(void);
extern void __extendsfdf2(void);
extern void __fixdfsi(void);
extern void __fixsfsi(void);
extern void __fixunsdfsi(void);
extern void __fixunssfsi(void);
extern void __floatsidf(void);
extern void __floatsisf(void);
extern void __gedf2(void);
extern void __gtdf2(void);
extern void __gtsf2(void);
extern void __ledf2(void);
extern void __ltdf2(void);
extern void __ltsf2(void);
extern void __muldf3(void);
extern void __mulsf3(void);
extern void __nedf2(void);
extern void __srget(void);
extern void __stdin(void);
extern void __subdf3(void);
extern void __subsf3(void);
extern void __truncdfsf2(void);

void * missing[] = {
lsl64,
lsr64,
udiv64,
umul64,

#if 0
__adddf3,
__addsf3,
__assert,
__ctype,
__divdf3,
__divsf3,
__eqdf2,
__eqsf2,
__errno,
__extendsfdf2,
__fixdfsi,
__fixsfsi,
__fixunsdfsi,
__fixunssfsi,
__floatsidf,
__floatsisf,
__gedf2,
__gtdf2,
__gtsf2,
__ledf2,
__ltdf2,
__ltsf2,
__muldf3,
__mulsf3,
__nedf2,
__srget,
__stdin,
__subdf3,
__subsf3,
__truncdfsf2,
#endif
};