INLINE byte M_RDMEM_FAST (dword A);

INLINE byte M_WRMEM_FAST (dword A,byte V);

/* Get next opcode and increment program counter */

INLINE byte M_RDMEM_OPCODE (void);

INLINE void M_ADD (byte Rg);

INLINE void M_SUB (byte Rg);

INLINE void M_ADC (byte Rg);

INLINE void M_SBC (byte Rg);

INLINE void M_CP (byte Rg);

INLINE unsigned M_RDMEM_WORD (dword A);

INLINE void M_WRMEM_WORD (dword A,word V);

