#include "Z80.h"

INLINE byte M_RDMEM_FAST (dword A)

{

 extern byte RAM[];

 return RAM[A];

}


INLINE byte M_WRMEM_FAST (dword A,byte V)

{

 extern byte RAM[];

 RAM[A] = V;

 return V;
}


/* Get next opcode and increment program counter */

INLINE byte M_RDMEM_OPCODE (void)

{

 byte retval;

 retval=M_RDMEM_FAST(R.PC.D);

 R.PC.W.l++;

 return retval;

}





INLINE void M_ADD (byte Rg)

{

#ifdef X86_ASM

  asm (

  " movb %2,%%al        \n"

  " addb %%al,%0        \n"

  " lahf                \n"

  " seto %%al           \n"

  " shlb $2,%%al        \n"

  " andb $0xD1,%%ah     \n"

  " orb %%ah,%%al       \n"

  " movb %%al,%1        \n"

  :"=g" (R.AF.B.h),

   "=g" (R.AF.B.l)

  :"g" (Rg),

   "g" (R.AF.B.h)

  :"eax"

  );

#else

  pair J;

  J.D=R.AF.B.h+Rg;

  R.AF.B.l=

    ((~(R.AF.B.h^Rg)&(Rg^J.B.l)&0x80)>>5)|

    ZSTable[J.D]|

    ((R.AF.B.h^Rg^J.B.l)&H_FLAG);

  R.AF.B.h=J.B.l;

#endif

}



INLINE void M_SUB (byte Rg)

{

#ifdef X86_ASM

  asm (

  " movb %2,%%al        \n"

  " subb %%al,%0        \n"

  " lahf                \n"

  " seto %%al           \n"

  " shlb $2,%%al        \n"

  " andb $0xD1,%%ah     \n"

  " orb %%ah,%%al       \n"

  " orb $2,%%al         \n"

  " movb %%al,%1        \n"

  :"=g" (R.AF.B.h),

   "=g" (R.AF.B.l)

  :"g" (Rg),

   "g" (R.AF.B.h)

  :"eax"

  );

#else

  pair J;

  J.D=R.AF.B.h-Rg;

  R.AF.B.l=

    (((R.AF.B.h^Rg)&(R.AF.B.h^J.B.l)&0x80)>>5)|

    N_FLAG|-J.B.h|ZSTable[J.B.l]|

    ((R.AF.B.h^Rg^J.B.l)&H_FLAG);

  R.AF.B.h=J.B.l;

#endif

}



INLINE void M_ADC (byte Rg)

{

#ifdef X86_ASM

  asm (

  " movb %3,%%al        \n"

  " shrb $1,%%al        \n"

  " movb %2,%%al        \n"

  " adcb %%al,%0        \n"

  " lahf                \n"

  " seto %%al           \n"

  " shlb $2,%%al        \n"

  " andb $0xD1,%%ah     \n"

  " orb %%ah,%%al       \n"

  " movb %%al,%1        \n"

  :"=g" (R.AF.B.h),

   "=g" (R.AF.B.l)

  :"g" (Rg),

   "g" (R.AF.B.l),

   "g" (R.AF.B.h)

  :"eax"

  );

#else

  pair J;

  J.D=R.AF.B.h+Rg+(R.AF.B.l&C_FLAG);

  R.AF.B.l=

    ((~(R.AF.B.h^Rg)&(Rg^J.B.l)&0x80)>>5)|

    ZSTable[J.D]|

    ((R.AF.B.h^Rg^J.B.l)&H_FLAG);

  R.AF.B.h=J.B.l;

#endif

}



INLINE void M_SBC (byte Rg)

{

#ifdef X86_ASM

  asm (

  " movb %3,%%al        \n"

  " shrb $1,%%al        \n"

  " movb %2,%%al        \n"

  " sbbb %%al,%0        \n"

  " lahf                \n"

  " seto %%al           \n"

  " shlb $2,%%al        \n"

  " andb $0xD1,%%ah     \n"

  " orb %%ah,%%al       \n"

  " orb $2,%%al         \n"

  " movb %%al,%1        \n"

  :"=g" (R.AF.B.h),

   "=g" (R.AF.B.l)

  :"g" (Rg),

   "g" (R.AF.B.l),

   "g" (R.AF.B.h)

  :"eax"

  );

#else

  pair J;

  J.D=R.AF.B.h-Rg-(R.AF.B.l&C_FLAG);

  R.AF.B.l=

    (((R.AF.B.h^Rg)&(R.AF.B.h^J.B.l)&0x80)>>5)|

    N_FLAG|-J.B.h|ZSTable[J.B.l]|

    ((R.AF.B.h^Rg^J.B.l)&H_FLAG);

  R.AF.B.h=J.B.l;

#endif

}



INLINE void M_CP (byte Rg)

{

#ifdef X86_ASM

  asm (

  " movb %2,%%al        \n"

  " cmpb %%al,%0        \n"

  " lahf                \n"

  " seto %%al           \n"

  " shlb $2,%%al        \n"

  " andb $0xD1,%%ah     \n"

  " orb %%ah,%%al       \n"

  " orb $2,%%al         \n"

  " movb %%al,%1        \n"

  :"=g" (R.AF.B.h),

   "=g" (R.AF.B.l)

  :"g" (Rg),

   "g" (R.AF.B.l),

   "g" (R.AF.B.h)

  :"eax"

  );

#else

  pair J;

  J.D=R.AF.B.h-Rg;

  R.AF.B.l=

    (((R.AF.B.h^Rg)&(R.AF.B.h^J.B.l)&0x80)>>5)|

    N_FLAG|-J.B.h|ZSTable[J.B.l]|

    ((R.AF.B.h^Rg^J.B.l)&H_FLAG);

#endif

}





/* some handy macros */

INLINE unsigned M_RDMEM_WORD (dword A)

{

 int i;

 i=M_RDMEM (A);

 i+=M_RDMEM ((A+1)&0xFFFF)*256;

 return i;

}



INLINE void M_WRMEM_WORD (dword A,word V)

{

 M_WRMEM (A,V&255);

 M_WRMEM ((A+1)&0xFFFF,V>>8);

}

