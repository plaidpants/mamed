/***************************************************************************

  osdepend.c

  OS dependant stuff (display handling, keyboard scan...)
  This is the only file which should me modified in order to port the
  emulator to a different system.

***************************************************************************/

//#include <stdio.h>
//#include <taskLib.h>
//#include <memLib.h>
#include "osdepend.h"
#include "../kosh/abi/conio.h"

int osd_joy_up, osd_joy_down, osd_joy_left, osd_joy_right;
int osd_joy_b1, osd_joy_b2, osd_joy_b3, osd_joy_b4, osd_joy_b5;

int bitmap_width;
int bitmap_height;
int display_height;
int display_width;

#define MAX_PEN 256
int first_free_pen = 0;
unsigned short pens[MAX_PEN];
unsigned char * bitmap = 0;

/* Library handles */
abi_fs_t    	*fs = NULL;
abi_thread_t    *thread = NULL;
abi_video_t 	*video = NULL;
abi_maple_t 	*maple = NULL;
abi_conio_t 	*conio = NULL;
abi_thread_t 	*thd = NULL;

kbd_cond_t kcond;
cont_cond_t ccond;

/* optimal random number function. */
unsigned long seed=123;
#define RNDC 1013904223
#define RNDM 1164525

int rand() 
{
	seed = seed * RNDM + RNDC;
	return seed;
}

void osd_setup_application(void)
{
	printf("lib_open(thread)\r\n");
	thd = lib_open("thread");
	if (!thd) 
	{ 
		printf("Can't open thread library\r\n"); 
		return; 
	}

	printf("lib_open(fs)\r\n");
    fs = lib_open("fs");
    if (fs == NULL) 
    { 
    	printf("Can't open fs lib\r\n"); 
    	return; 
    }

	printf("lib_open(video)\r\n");
    video = lib_open("video");
    if (video == NULL) 
    { 
    	printf("Can't open video lib\r\n"); 
    	return; 
    }

	printf("lib_open(maple)\r\n");
    maple = lib_open("maple");
    if (video == NULL) 
    { 
    	printf("Can't open video lib\r\n"); 
    	return; 
    }

	conio = lib_open("conio");
	if (conio != NULL) 
	{
		printf("Kosh detected; freezing\r\n");
		conio->freeze();
	}

	video->set_mode(video->check_cable(), DM_320x240, PM_RGB565);
	video->clear(0,0,0);
	
}

/* put here anything you need to do when the program is started. Return 0 if */
/* initialization was successful, nonzero otherwise. */
int osd_init(void)
{
	first_free_pen = 0;

	display_width = 320;	
	display_height = 240;

	return 0;
}

/* put here cleanup routines to be executed when the program is terminated. */
void osd_exit(void)
{
	if (conio != NULL) 
	{
		video->set_mode(video->check_cable(), DM_640x480, PM_RGB565);
		video->clear(0,0,0);
		conio->thaw();
	}
}

/* Create a display screen, or window, large enough to accomodate a bitmap */
/* of the given dimensions. I don't do any test here (224x288 will just do */
/* for now) but one could e.g. open a window of the exact dimensions */
/* provided. Return a bitmap pointer or 0 in case of error. */
unsigned char *osd_create_display(int width,int height)
{
	int i;
	
	bitmap_width = width;
	bitmap_height = height;
	
	bitmap = (unsigned char *)malloc(width * height * sizeof(unsigned char));
	
	return bitmap;
}

/* shut up the display */
void osd_close_display(void)
{
	free(bitmap);
}

int osd_obtain_pen(unsigned char red, unsigned char green, unsigned char blue)
{
	if (first_free_pen < MAX_PEN)
	{
		pens[first_free_pen] = ((red >> 3) << 11) | ((green >> 2) << 5) | ((blue >> 3) << 0);
		return first_free_pen++;
	}

	return 0;
}

/* Update the display. */
void osd_update_display(void)
{
	int i;
	int j;
	int row_end, col_end;
	unsigned short * walk_display;
	unsigned char * walk_bitmap;
    unsigned short ourbuffer[640];

	osd_poll_joystick();
	
	if (bitmap_height > display_width)
	{
		row_end = display_width;
	}
	else
	{
		row_end = bitmap_height;
	}
	
	if (bitmap_width > display_height)
	{
		col_end = display_height;
	}
	else
	{
		col_end = bitmap_width;
	}
	
	for (j = 0; j < row_end; j++)
	{
		walk_display = video->vram_s + ((display_width - bitmap_width) / 2) + (j + ((display_height - bitmap_height) / 2))  * display_width;
		walk_bitmap = bitmap + j * bitmap_width;

		for (i = 0; i < col_end; i++)
		{
			*walk_display++ = pens[*walk_bitmap++];
		}
	}
}

int dc_key_pressed(int key)
{
	int i;

	osd_poll_joystick();

	for (i = 0; i < 6; i++)
	{
		if (kcond.keys[i] == key)
		{
			return 1;
		}
	}
	
	return 0;
	
}

/* check if a key is pressed. The keycode is the standard PC keyboard code, as */
/* defined in osdepend.h. Return 0 if the key is not pressed, nonzero otherwise. */
int osd_key_pressed(int keycode)
{
	int retval = 0;
	
	switch (keycode)
	{
		case OSD_KEY_1:
		{
			retval = dc_key_pressed(KBD_KEY_1);
			break;
		}
		case OSD_KEY_2:
		{
			retval = dc_key_pressed(KBD_KEY_2);
			break;
		}
		case OSD_KEY_3:
		{
			retval = dc_key_pressed(KBD_KEY_3);
			break;
		}
		case OSD_KEY_LEFT:
		{
			retval = dc_key_pressed(KBD_KEY_LEFT);
			break;
		}
		case OSD_KEY_DOWN:
		{
			retval = dc_key_pressed(KBD_KEY_DOWN);
			break;
		}
		case OSD_KEY_UP:
		{
			retval = dc_key_pressed(KBD_KEY_UP);
			break;
		}
		case OSD_KEY_RIGHT:
		{
			retval = dc_key_pressed(KBD_KEY_RIGHT);
			break;
		}
		case OSD_KEY_TAB:
		{
			retval = dc_key_pressed(KBD_KEY_TAB);
			break;
		}
		case OSD_KEY_ESC:
		{
			retval = dc_key_pressed(KBD_KEY_ESCAPE);
			break;
		}
		case OSD_KEY_P:
		{
			retval = dc_key_pressed(KBD_KEY_P);
			break;
		}
		case OSD_KEY_F1:
		{
			retval = dc_key_pressed(KBD_KEY_F1);
			break;
		}
		case OSD_KEY_F2:
		{
			retval = dc_key_pressed(KBD_KEY_F2);
			break;
		}
		
		default:
		{
			break;
		}
	}
	
	return retval;
}

/* wait for a key press and return the keycode */
int osd_read_key(void)
{
	int return_val = 0;

	// wait for all keys to be unpressed
	while (osd_key_pressed(OSD_KEY_1) || 
		osd_key_pressed(OSD_KEY_2) ||
		osd_key_pressed(OSD_KEY_3) ||
		osd_key_pressed(OSD_KEY_UP) ||
		osd_key_pressed(OSD_KEY_DOWN) ||
		osd_key_pressed(OSD_KEY_RIGHT) ||
		osd_key_pressed(OSD_KEY_LEFT) ||
		osd_key_pressed(OSD_KEY_ESC) ||
		osd_key_pressed(OSD_KEY_TAB) ||
		osd_key_pressed(OSD_KEY_P) ||
		osd_key_pressed(OSD_KEY_F1) ||
		osd_key_pressed(OSD_KEY_F2) ||
		0
		)
		;
		
	while (1)
	{
		if (osd_key_pressed(OSD_KEY_1))
			return_val = OSD_KEY_1;
		else if (osd_key_pressed(OSD_KEY_2))
			return_val = OSD_KEY_2;
		else if (osd_key_pressed(OSD_KEY_3))
			return_val = OSD_KEY_3;
		else if (osd_key_pressed(OSD_KEY_UP))
			return_val = OSD_KEY_UP;
		else if (osd_key_pressed(OSD_KEY_DOWN))
			return_val = OSD_KEY_DOWN;
		else if (osd_key_pressed(OSD_KEY_RIGHT))
			return_val = OSD_KEY_RIGHT;
		else if (osd_key_pressed(OSD_KEY_LEFT))
			return_val = OSD_KEY_LEFT;
		else if (osd_key_pressed(OSD_KEY_ESC))
			return_val = OSD_KEY_ESC;
		else if (osd_key_pressed(OSD_KEY_TAB))
			return_val = OSD_KEY_TAB;
		else if (osd_key_pressed(OSD_KEY_P))
			return_val = OSD_KEY_P;
		else if (osd_key_pressed(OSD_KEY_F1))
			return_val = OSD_KEY_F1;
		else if (osd_key_pressed(OSD_KEY_F2))
			return_val = OSD_KEY_F2;

		if (return_val)
		{
			// wait for key to be unpressed
			while (osd_key_pressed(return_val))
				;
				
			return return_val;
		}
	}
}

int uclock(void)
{
	return thd->jiffies();
}

static int last_check = -1;
void osd_poll_joystick(void)
{
	int to;
	
	if (last_check == thd->jiffies())
	{
		return;
	}
	last_check = thd->jiffies();

	to = 5;

	while (maple->kbd_get_cond(maple->first_kb(), &kcond) < 0) 
	{
		printf("Error getting keyboard status\r\n");
		if (to-- <= 0)
		{
			return;
		}
		thd->sleep(10);
	}

	to = 5;

	while (maple->cont_get_cond(maple->first_controller(), &ccond) < 0) 
	{
		printf("Error getting controller status\r\n");
		if (to-- <= 0)
		{
			return;
		}
		thd->sleep(10);
	}

	osd_joy_up = (ccond.buttons & CONT_DPAD_UP) == 0;
	osd_joy_down = (ccond.buttons & CONT_DPAD_DOWN) == 0;
	osd_joy_left = (ccond.buttons & CONT_DPAD_LEFT) == 0;
	osd_joy_right = (ccond.buttons & CONT_DPAD_RIGHT) == 0;
	osd_joy_b1 = (ccond.buttons & CONT_A) == 0;
	osd_joy_b2 = (ccond.buttons & CONT_B) == 0;
	osd_joy_b3 = (ccond.buttons & CONT_START) == 0;
	osd_joy_b4 = (ccond.buttons & CONT_X) == 0;
	osd_joy_b5 = (ccond.buttons & CONT_Y) == 0;
}

void osd_update_audio(void)
{
}

void osd_play_sample(int channel,unsigned char *data,int len,int freq,int volume,int loop)
{
}

void osd_play_streamed_sample(int channel,unsigned char *data,int len,int freq,int volume)
{
}

void osd_adjust_sample(int channel,int freq,int volume)
{
}

void osd_stop_sample(int channel)
{
}
