int init_machine(const char *gamename);
int run_machine(const char *gamename);

extern unsigned char RAM[];
