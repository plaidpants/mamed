// MAME includes
#include "osdepend.h"
#include "driver.h"
#include "dirty.h"
#include "ticker.h"

static int warming_up;

#define BACKGROUND 0


dirtygrid grid1;
dirtygrid grid2;
char *dirty_old=grid1;
char *dirty_new=grid2;

void scale_vectorgames(int gfx_width,int gfx_height,int *width,int *height);

struct osd_bitmap *scrbitmap = 0;

int frameskip = 6,autoframeskip = 1;
#define FRAMESKIP_LEVELS 12

int vsync_frame_rate;
int use_dirty = 0; /* off */
float osd_gamma_correction = 1.0;
int brightness;

static int vector_game;

int throttle = 1;       /* toggled by F10 */
static int frameskip_counter = 0;
static int frames_displayed;
static TICKER start_time,end_time;    /* to calculate fps average on exit */
#define FRAMES_TO_SKIP 20       /* skip the first few frames from the FPS calculation */
							/* to avoid counting the copyright and info screens */

unsigned long display_height = 216;
unsigned long display_width = 288;	

int display_skip_pixels;
int display_skip_column;
int bitmap_skip_pixels;
int bitmap_skip_column;
int interlaced = 0;
int doublesize = 0;
unsigned long * current_display = NULL;


unsigned long * pens823 = 0;
unsigned long * pens823right = 0;
unsigned long * pens823left = 0;
unsigned long * pensDCAM = 0;
unsigned long * pensDCAMright = 0;
unsigned long * pensDCAMleft = 0;
unsigned char * pensrgb = 0;

extern unsigned long * 		gLCD_buffer1;
extern unsigned long * 		gLCD_buffer2;
extern int 					gResolution;
extern long 				camera_type;

extern void * event_Sem;

#define kMathScaleBits  10
#define kMathScale     (1 << kMathScaleBits)
#define kMaxValue      (kMathScale * 235)
#define kMinValue      (kMathScale * 16)
#define kMaxYValue     (kMathScale * 240)
#define kMinYValue     (kMathScale * 16)

#define kYRcoeff    ((long)( 0.2990 * kMathScale))
#define kYGcoeff    ((long)( 0.5870 * kMathScale))
#define kYBcoeff    ((long)( 0.1140 * kMathScale))

#define kCbRcoeff    ((long)( 0.1687 * kMathScale))
#define kCbGcoeff    ((long)( 0.3313 * kMathScale))
#define kCbBcoeff    ((long)( 0.5000 * kMathScale))

#define kCrRcoeff    ((long)( 0.5000 * kMathScale))
#define kCrGcoeff    ((long)( 0.4187 * kMathScale))
#define kCrBcoeff    ((long)( 0.0813 * kMathScale))

#define kRYcoeff     ((long)( 1.0000 * kMathScale))
#define kRCbcoeff    ((long)( 0.0000 * kMathScale))
#define kRCrcoeff    ((long)( 1.4020 * kMathScale))

#define kGYcoeff     ((long)( 1.0000 * kMathScale))
#define kGCbcoeff    ((long)( 0.3441 * kMathScale))
#define kGCrcoeff    ((long)( 0.7141 * kMathScale))

#define kBYcoeff     ((long)( 1.0000 * kMathScale))
#define kBCbcoeff    ((long)( 1.7720 * kMathScale))
#define kBCrcoeff    ((long)( 0.0000 * kMathScale))

#define PIN(x)   	((x) > kMaxValue  ? 235 : ((x) < kMinValue  ? 16 : (x >> kMathScaleBits)))
#define PINY(x)  	((x) > kMaxYValue ? 240 : ((x) < kMinYValue ? 16 : (x >> kMathScaleBits)))
#define PIN255(x)   ((x) > 255        ? 255 : ((x) < 0          ?  0 : 255))

unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) << 24) + (PINY(v0) << 16) + (PIN(v2) << 8) + (PINY(v0) << 0));
}

unsigned long RGB2YCYC823LEFT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return (((PIN(v1) >> 1) << 24) + ((PIN(v2) >> 1) << 8) + (PINY(v0) << 0));
}

unsigned long RGB2YCYC823RIGHT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return (((PIN(v1) >> 1) << 24) + (PINY(v0) << 16)  + ((PIN(v2) >> 1) << 8));
}

unsigned long RGB2CYCYDCAM( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + (PINY(v0) << 8) + ((PIN(v2) >> 1) << 16) + (PINY(v0) << 24));
}

unsigned long RGB2CYCYDCAMRIGHT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + (PINY(v0) << 8) + ((PIN(v2) >> 1) << 16));
}

unsigned long RGB2CYCYDCAMLEFT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + ((PIN(v2) >> 1) << 16) + (PINY(v0) << 24));
}

/* Create a bitmap. Also calls osd_clearbitmap() to appropriately initialize */
/* it to the background color. */
/* VERY IMPORTANT: the function must allocate also a "safety area" 16 pixels wide all */
/* around the bitmap. This is required because, for performance reasons, some graphic */
/* routines don't clip at boundaries of the bitmap. */

const int safety = 16;
int last_event_update = 0;
int last_update = 0;

void update_screen(void)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		// don't update more than 60 times a sec, cause that's too fast
		while ((tickGet() - last_update) == 0)
		{
			;
		}
		
		last_update = tickGet();

		if (interlaced)
		{
			register unsigned char * walk_bitmap;
			register unsigned long * walk_display1;
			register unsigned long * walk_display2;
			register int i;
			register int j;
			int startRow;
			int endRow;
			int startColumn;
			int endColumn;
			int bitmapInc;
			int displayInc;
			int skipInc;
			
			startRow = bitmap_skip_column;
			endRow = scrbitmap->height - bitmap_skip_column;
			startColumn = bitmap_skip_pixels;
			endColumn = scrbitmap->width - bitmap_skip_pixels;
		
			bitmapInc = scrbitmap->width - (display_width - (2 * display_skip_pixels)) + bitmap_skip_pixels;
			displayInc = display_skip_pixels;
			skipInc = (endColumn - startColumn) / 2 + displayInc;
			
			walk_bitmap = scrbitmap->line[bitmap_skip_column] + bitmap_skip_pixels;
			walk_display1 = gLCD_buffer1 + (display_skip_pixels / 2) + (display_width * display_skip_column / 4);
			walk_display2 = gLCD_buffer2 + (display_skip_pixels / 2) + (display_width * display_skip_column / 4);
		
			if (use_dirty)
			{
				for (i = startRow; i < endRow;)
				{
					if (ISDIRTY(i))
					{
						for (j = startColumn; j < endColumn; j += 2)
						{
							*walk_display1 = pens823right[*walk_bitmap++];
							*walk_display1++ += pens823left[*walk_bitmap++];
						}
						walk_display1 += displayInc;
					}
					else
					{
						walk_display1 += skipInc;
					}
					
					i++;
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
			
					if (ISDIRTY(i))
					{
						for (j = startColumn; j < endColumn; j += 2)
						{
							*walk_display2 = pens823right[*walk_bitmap++];
							*walk_display2++ += pens823left[*walk_bitmap++];
						}
						walk_display2 += displayInc;
					}
					else
					{
						walk_display2 += skipInc;
					}
					
					i++;
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
				}
			}
			else
			{
				for (i = startRow; i < endRow;)
				{
					for (j = startColumn; j < endColumn; j += 2)
					{
						*walk_display1 = pens823right[*walk_bitmap++];
						*walk_display1++ += pens823left[*walk_bitmap++];
					}
					
					i++;
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display1 += displayInc;
			
					for (j = startColumn; j < endColumn; j += 2)
					{
						*walk_display2 = pens823right[*walk_bitmap++];
						*walk_display2++ += pens823left[*walk_bitmap++];
					}
			
					i++;
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display2 += displayInc;
				}
			}

			// force an event check 10 times a second
			{
				int current_ticks;
				current_ticks = tickGet();
				
				if ((current_ticks - last_event_update) > 10)
				{
					if (event_Sem == 0)
						event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
					semGive(event_Sem);
					last_event_update = current_ticks;
				}
			}
		}
		else
		{
			register unsigned long * walk_display;
			register unsigned char * walk_bitmap;
			register int i;
			register int j;
			int startRow;
			int endRow;
			int startColumn;
			int endColumn;
			int displayInc;
			int skipInc;
			int bitmapInc;

			if (use_dirty)
			{
				current_display = gLCD_buffer1;
			}
			else
			{
				if (current_display == gLCD_buffer1)
				{
					current_display = gLCD_buffer2;
				}
				else
				{
					current_display = gLCD_buffer1;
				}
			}

			startRow = bitmap_skip_column;
			endRow = scrbitmap->height - bitmap_skip_column;
			startColumn = bitmap_skip_pixels;
			endColumn = scrbitmap->width - bitmap_skip_pixels;
			bitmapInc = scrbitmap->width - (display_width - (2 * display_skip_pixels)) + bitmap_skip_pixels;
			displayInc = 2 * display_skip_pixels;
			skipInc = displayInc + (endColumn - startColumn);
			walk_bitmap = scrbitmap->line[bitmap_skip_column] + bitmap_skip_pixels;
			walk_display = current_display + display_skip_pixels + (display_width * display_skip_column);
			
			if (doublesize)
			{
				if (use_dirty)
				{
					for (i = startRow;i < endRow; i++)
					{
						unsigned long * save_start_display = walk_display;
						
						if (ISDIRTY(i))
						{
							for (j = startColumn; j < endColumn; j++)
							{
								int val = pens823[*walk_bitmap++];
								*walk_display++ = val;
								*walk_display++ = val;
							}
						}
						else
						{
							walk_display += 2*skipInc;
						}
						
						walk_display += (displayInc/2);
						memcpy(walk_display, save_start_display, 4*2*display_width);
						walk_display += 2*display_width;
						
						walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
						//walk_bitmap += bitmapInc;
					}
				}
				else
				{
					for (i = startRow;i < endRow; i++)
					{
						unsigned long * save_start_display = walk_display;
						
						for (j = startColumn; j < endColumn; j++)
						{
							int val = pens823[*walk_bitmap++];
							*walk_display++ = val;
							*walk_display++ = val;
						}
						
						walk_display += (displayInc/2);
						memcpy(walk_display, save_start_display, 4*2*display_width);
						walk_display += 2*display_width;
						
						walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
						//walk_bitmap += bitmapInc;
					}
				}
			}
			else
			{
				if (use_dirty)
				{
					for (i = startRow;i < endRow;i++)
					{
						if (ISDIRTY(i))
						{
							for (j = startColumn; j < endColumn; j++)
							{
								*walk_display++ = pens823[*walk_bitmap++];
							}
							
							walk_display += displayInc;
						}
						else
						{
							walk_display += skipInc;
						}
						
						walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
						//walk_bitmap += bitmapInc;
					}
				}
				else
				{
					for (i = startRow;i < endRow;i++)
					{
						for (j = startColumn; j < endColumn; j++)
						{
							*walk_display++ = pens823[*walk_bitmap++];
						}
						
						walk_display += displayInc;
						walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
						//walk_bitmap += bitmapInc;
					}
				}
			}
			
			// force an event check 10 times a second
			{
				int current_ticks;
				current_ticks = tickGet();
				
				if ((current_ticks - last_event_update) > 10)
				{
					if (event_Sem == 0)
						event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
					semGive(event_Sem);
					last_event_update = current_ticks;
				}
			}
			
			if (!use_dirty)
			{
				LMSwitchBuffer(current_display);
			}
		}
	}
	else if (camera_type == kTypeHP1)
	{
		register unsigned char * walk_bitmap;
		register unsigned long * walk_display;
		register int i;
		register int j;
		int startRow;
		int endRow;
		int startColumn;
		int endColumn;
		int bitmapInc;
		int displayInc;
		int skipInc;
		
		// don't update more than 60 times a sec, cause that's too fast
		while ((tickGet() - last_update) == 0)
		{
			;
		}
		
		last_update = tickGet();

		if (use_dirty)
		{
			current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
		}
		else
		{
			current_display = (unsigned long *)LMGetNextLiveviewFrame();
		}
		
		startRow = bitmap_skip_column;
		endRow = scrbitmap->height - bitmap_skip_column;
		startColumn = bitmap_skip_pixels;
		endColumn = scrbitmap->width - bitmap_skip_pixels;
	
		bitmapInc = scrbitmap->width - (display_width - (2 * display_skip_pixels)) + bitmap_skip_pixels;
		displayInc = display_skip_pixels;
		skipInc = displayInc + (endColumn - startColumn) / 2;
		
		walk_bitmap = scrbitmap->line[bitmap_skip_column] + bitmap_skip_pixels;
		walk_display = current_display + (display_skip_pixels / 2) + (display_width * display_skip_column / 4);
	
		if (use_dirty)
		{
			for (i = startRow;i < endRow;i++)
			{
				if (ISDIRTY(i))
				{
					for (j = startColumn; j < endColumn; j += 2)
					{
						*walk_display = pensDCAMright[*walk_bitmap++];
						*walk_display++ += pensDCAMleft[*walk_bitmap++];
					}
					
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display += displayInc;
				}
				else
				{
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display += skipInc;
				}
			}
		}
		else
		{
			for (i = startRow; i < endRow; i++)
			{
				for (j = startColumn; j < endColumn; j += 2)
				{
					*walk_display = pensDCAMright[*walk_bitmap++];
					*walk_display++ += pensDCAMleft[*walk_bitmap++];
				}
				
				walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
				walk_display += displayInc;
			}
		}
		
		if (!use_dirty)
		{
			LMSwitchToNextLiveviewFrame();
		}

		// force an event check 10 times a second
		{
			int current_ticks;
			current_ticks = tickGet();
			
			if ((current_ticks - last_event_update) > 10)
			{
				if (event_Sem == 0)
					event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
				semGive(event_Sem);
				last_event_update = current_ticks;
			}
		}
	}
	else if (camera_type == kTypeHP2)
	{
		register unsigned char * walk_bitmap;
		register unsigned long * walk_display;
		register int i;
		register int j;
		int startRow;
		int endRow;
		int startColumn;
		int endColumn;
		int bitmapInc;
		int displayInc;
		int skipInc;
		
		// don't update more than 60 times a sec, cause that's too fast
		while ((tickGet() - last_update) == 0)
		{
			;
		}
		
		last_update = tickGet();

		if (use_dirty)
		{
			current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
		}
		else
		{
			current_display = (unsigned long *)LMGetNextLiveviewFrame();
		}
		
		startRow = bitmap_skip_column;
		endRow = scrbitmap->height - bitmap_skip_column;
		startColumn = bitmap_skip_pixels;
		endColumn = scrbitmap->width - bitmap_skip_pixels;
		bitmapInc = scrbitmap->width - (display_width - (2 * display_skip_pixels)) + bitmap_skip_pixels;
		displayInc = 2 * display_skip_pixels;
		skipInc = displayInc + (endColumn - startColumn);
		walk_bitmap = scrbitmap->line[bitmap_skip_column] + bitmap_skip_pixels;
		walk_display = current_display + display_skip_pixels + (display_width * display_skip_column);
		
		if (doublesize)
		{
			if (use_dirty)
			{
				for (i = startRow;i < endRow; i++)
				{
					unsigned long * save_start_display = walk_display;
					
					if (ISDIRTY(i))
					{
						for (j = startColumn; j < endColumn; j++)
						{
							int val = pens823[*walk_bitmap++];
							*walk_display++ = val;
							*walk_display++ = val;
						}
					}
					else
					{
						walk_display += 2*skipInc;
					}
					
					walk_display += (displayInc/2);
					memcpy(walk_display, save_start_display, 4*2*display_width);
					walk_display += 2*display_width;
					
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					//walk_bitmap += bitmapInc;
				}
			}
			else
			{
				for (i = startRow;i < endRow; i++)
				{
					unsigned long * save_start_display = walk_display;
					
					for (j = startColumn; j < endColumn; j++)
					{
						int val = pens823[*walk_bitmap++];
						*walk_display++ = val;
						*walk_display++ = val;
					}
					
					walk_display += (displayInc/2);
					memcpy(walk_display, save_start_display, 4*2*display_width);
					walk_display += 2*display_width;
					
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					//walk_bitmap += bitmapInc;
				}
			}
		}
		else
		{
			if (use_dirty)
			{
				for (i = startRow;i < endRow;i++)
				{
					if (ISDIRTY(i))
					{
						for (j = startColumn; j < endColumn; j++)
						{
							*walk_display++ = pens823[*walk_bitmap++];
						}
						
						walk_display += displayInc;
					}
					else
					{
						walk_display += skipInc;
					}
					
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					//walk_bitmap += bitmapInc;
				}
			}
			else
			{
				for (i = startRow;i < endRow;i++)
				{
					for (j = startColumn; j < endColumn; j++)
					{
						*walk_display++ = pens823[*walk_bitmap++];
					}
					
					walk_display += displayInc;
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					//walk_bitmap += bitmapInc;
				}
			}
		}

		if (!use_dirty)
		{
			LMSwitchToNextLiveviewFrame();
		}

		// force an event check 10 times a second
		{
			int current_ticks;
			current_ticks = tickGet();
			
			if ((current_ticks - last_event_update) > 10)
			{
				if (event_Sem == 0)
					event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
				semGive(event_Sem);
				last_event_update = current_ticks;
			}
		}
	}
	else if (camera_type == kTypeMinolta1)
	{
		register unsigned char * walk_bitmap;
		register unsigned long * walk_display;
		register int i;
		register int j;
		int startRow;
		int endRow;
		int startColumn;
		int endColumn;
		int bitmapInc;
		int displayInc;
		int skipInc;
		
		// don't update more than 60 times a sec, cause that's too fast
		while ((tickGet() - last_update) == 0)
		{
			;
		}
		
		last_update = tickGet();

		if (use_dirty)
		{
			current_display = gLCD_buffer1;
		}
		else
		{
			if (current_display == gLCD_buffer1)
			{
				current_display = gLCD_buffer2;
			}
			else
			{
				current_display = gLCD_buffer1;
			}
		}
		
		startRow = bitmap_skip_column;
		endRow = scrbitmap->height - bitmap_skip_column;
		startColumn = bitmap_skip_pixels;
		endColumn = scrbitmap->width - bitmap_skip_pixels;
	
		bitmapInc = scrbitmap->width - (display_width - (2 * display_skip_pixels)) + bitmap_skip_pixels;
		displayInc = display_skip_pixels;
		skipInc = displayInc + (endColumn - startColumn) / 2;
		
		walk_bitmap = scrbitmap->line[bitmap_skip_column] + bitmap_skip_pixels;
		walk_display = current_display + (display_skip_pixels / 2) + (display_width * display_skip_column / 4);
	
		if (use_dirty)
		{
			for (i = startRow;i < endRow;i++)
			{
				if (ISDIRTY(i))
				{
					for (j = startColumn; j < endColumn; j += 2)
					{
						*walk_display = pensDCAMright[*walk_bitmap++];
						*walk_display++ += pensDCAMleft[*walk_bitmap++];
					}
					
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display += displayInc;
				}
				else
				{
					walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
					walk_display += skipInc;
				}
			}
		}
		else
		{
			for (i = startRow; i < endRow; i++)
			{
				for (j = startColumn; j < endColumn; j += 2)
				{
					*walk_display = pensDCAMright[*walk_bitmap++];
					*walk_display++ += pensDCAMleft[*walk_bitmap++];
				}
				
				walk_bitmap = scrbitmap->line[i] + bitmap_skip_pixels;
				walk_display += displayInc;
			}
		}

		if (!use_dirty)
		{
			LMSwitchBuffer(current_display);
		}
		
//		sysWbFlush();

		// force an event check 10 times a second
		{
			int current_ticks;
			current_ticks = tickGet();
			
			if ((current_ticks - last_event_update) > 10)
			{
				if (event_Sem == 0)
					event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
				semGive(event_Sem);
				last_event_update = current_ticks;
			}
		}
	}
}

struct osd_bitmap *osd_new_bitmap(int width,int height,int depth)       /* ASG 980209 */
{
	struct osd_bitmap *bitmap;


	if (Machine->orientation & ORIENTATION_SWAP_XY)
	{
		int temp;

		temp = width;
		width = height;
		height = temp;
	}

	if ((bitmap = malloc(sizeof(struct osd_bitmap))) != 0)
	{
		int i,rowlen,rdwidth;
		unsigned char *bm;


		if (depth != 8 && depth != 16) depth = 8;
		
		bitmap->depth = depth;
		bitmap->width = width;
		bitmap->height = height;
		
		rdwidth = (width + 7) & ~7;     /* round width to a quadword */
		if (depth == 16)
			rowlen = 2 * (rdwidth + 2 * safety) * sizeof(unsigned char);
		else
			rowlen =     (rdwidth + 2 * safety) * sizeof(unsigned char);

		if ((bm = malloc((height + 2 * safety) * rowlen)) == 0)
		{
			free(bitmap);
			return 0;
		}

		/* clear ALL bitmap, including safety area, to avoid garbage on right */
		/* side of screen is width is not a multiple of 4 */
		memset(bm,0,(height + 2 * safety) * rowlen);

		if ((bitmap->line = malloc((height + 2 * safety) * sizeof(unsigned char *))) == 0)
		{
			free(bm);
			free(bitmap);
			return 0;
		}

		for (i = 0;i < height + 2 * safety;i++)
		{
			if (depth == 16)
				bitmap->line[i] = &bm[i * rowlen + 2*safety];
			else
			bitmap->line[i] = &bm[i * rowlen + safety];
		}
		bitmap->line += safety;
		
		bitmap->_private = bm;

		osd_clearbitmap(bitmap);
	}
	
	return bitmap;
}



/* set the bitmap to black */
void osd_clearbitmap(struct osd_bitmap *bitmap)
{
	int i;


	for (i = 0;i < bitmap->height;i++)
	{
		if (bitmap->depth == 16)
			memset(bitmap->line[i],0,2*bitmap->width);
		else
			memset(bitmap->line[i],BACKGROUND,bitmap->width);
	}


	if (bitmap == scrbitmap)
	{
		extern int bitmap_dirty;        /* in mame.c */

		osd_mark_dirty (0,0,bitmap->width-1,bitmap->height-1,1);
		bitmap_dirty = 1;
	}
}



void osd_free_bitmap(struct osd_bitmap *bitmap)
{
	if (bitmap)
	{
		bitmap->line -= safety;
		free(bitmap->line);
		free(bitmap->_private);
		free(bitmap);
	}
}


void osd_mark_dirty(int _x1, int _y1, int _x2, int _y2, int ui)
{
	int y;
	
	if (_y1 < 0) _y1 = 0;
	if (_x1 < 0) _x1 = 0;

	for (y = _y1; y <= _y2 + 1; y++)
		MARKDIRTY(y);
}

static void init_dirty(char dirty)
{
	memset(dirty_new, dirty, MAX_GFX_HEIGHT);
}

INLINE void swap_dirty(void)
{
    char *tmp;

	tmp = dirty_old;
	dirty_old = dirty_new;
	dirty_new = tmp;
}


/* Create a display screen, or window, large enough to accomodate a bitmap */
/* of the given dimensions. Attributes are the ones defined in driver.h. */
/* Return a osd_bitmap pointer or 0 in case of error. */
struct osd_bitmap *osd_create_display(int width,int height,int depth,int attributes)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
	if (errorlog)
		fprintf (errorlog, "width %d, height %d\n", width,height);

	if (frameskip < 0) frameskip = 0;
	if (frameskip >= FRAMESKIP_LEVELS) frameskip = FRAMESKIP_LEVELS-1;
	
		/* Look if this is a vector game */
		if (Machine->drv->video_attributes & VIDEO_TYPE_VECTOR)
			vector_game = 1;
		else
			vector_game = 0;
	
	
		if (use_dirty == -1)	/* dirty=auto in mame.cfg? */
		{
			/* Is the game using a dirty system? */
			if ((Machine->drv->video_attributes & VIDEO_SUPPORTS_DIRTY) || vector_game)
				use_dirty = 1;
			else
				use_dirty = 0;
		}

		if (vector_game)
		{
			if (gResolution < 0)
			{
				display_width = 144;
				display_height = 108;
			}
			else if (gResolution < 0)
			{
				display_width = 576;
				display_height = 432;
			}
			else
			{
				display_width = 288;
				display_height = 216;
			}
			scale_vectorgames(display_width, display_height, &width, &height);
		}
	
	if (depth == 16)
		scrbitmap = osd_new_bitmap(width,height,16);
	else
		scrbitmap = osd_new_bitmap(width,height,8);

	if (!scrbitmap) return 0;


	if (!osd_set_display(width, height, attributes))
		return 0;

		if (Machine->orientation & ORIENTATION_SWAP_XY)
		{
			int temp;
	
			temp = width;
			width = height;
			height = temp;
		}
	
		if (gResolution > 0)
		{
			display_height = 216*2;
			display_width = 288*2;
			interlaced = 1;
			doublesize = 0;
			if (camera_type)
			{
				LMSetupBuffers(gLCD_buffer2, gLCD_buffer1, TRUE);
			}
			else
			{
				LMSetUpInterlacedMode(gLCD_buffer2, gLCD_buffer1);
			}
		}
		else if (gResolution < 0)
		{
			display_height = 108;
			display_width = 144;
			interlaced = 0;
			doublesize = 1;
			LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
		}
		else
		{
			display_height = 216;
			display_width = 288;
			interlaced = 0;
			doublesize = 0;
			LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
		}
	
		if (width < display_width)
		{
			display_skip_pixels = (display_width - width) / 2;
			bitmap_skip_pixels = 0;
		}
		else if (width > display_width)
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = (width - display_width) / 2;
		}
		else
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = 0;
		}
		
		if (height < display_height)
		{
			bitmap_skip_column = 0;
			display_skip_column = (display_height - height) / 2;
		} 
		else if (height > display_height)
		{
			bitmap_skip_column = (height - display_height) / 2;
			display_skip_column = 0;
		}
		else
		{
			bitmap_skip_column = 0;
			display_skip_column = 0;
		}
		
		set_ui_visarea (bitmap_skip_pixels, bitmap_skip_column + 1, 
			width - 1 - bitmap_skip_pixels, height - 2 - bitmap_skip_column);
	}
	else if (camera_type == kTypeHP2)
	{
	if (errorlog)
		fprintf (errorlog, "width %d, height %d\n", width,height);

	if (frameskip < 0) frameskip = 0;
	if (frameskip >= FRAMESKIP_LEVELS) frameskip = FRAMESKIP_LEVELS-1;
	
		/* Look if this is a vector game */
		if (Machine->drv->video_attributes & VIDEO_TYPE_VECTOR)
			vector_game = 1;
		else
			vector_game = 0;
	
	
		if (use_dirty == -1)	/* dirty=auto in mame.cfg? */
		{
			/* Is the game using a dirty system? */
			if ((Machine->drv->video_attributes & VIDEO_SUPPORTS_DIRTY) || vector_game)
				use_dirty = 1;
			else
				use_dirty = 0;
		}

		if (vector_game)
		{
			if (gResolution < 0)
			{
				display_width = 144;
				display_height = 108;
			}
			else if (gResolution < 0)
			{
				display_width = 576;
				display_height = 432;
			}
			else
			{
				display_width = 288;
				display_height = 216;
			}
			scale_vectorgames(display_width, display_height, &width, &height);
		}
	
	if (depth == 16)
		scrbitmap = osd_new_bitmap(width,height,16);
	else
		scrbitmap = osd_new_bitmap(width,height,8);

	if (!scrbitmap) return 0;


	if (!osd_set_display(width, height, attributes))
		return 0;

		if (Machine->orientation & ORIENTATION_SWAP_XY)
		{
			int temp;
	
			temp = width;
			width = height;
			height = temp;
		}
	
		if (gResolution > 0)
		{
			display_height = 216*2;
			display_width = 288*2;
			interlaced = 1;
			doublesize = 0;
		}
		else if (gResolution < 0)
		{
			display_height = 108;
			display_width = 144;
			interlaced = 0;
			doublesize = 1;
		}
		else
		{
			display_height = 216;
			display_width = 288;
			interlaced = 0;
			doublesize = 0;
		}
	
		LMSwitchLiveviewMode();
		
		if (width < display_width)
		{
			display_skip_pixels = (display_width - width) / 2;
			bitmap_skip_pixels = 0;
		}
		else if (width > display_width)
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = (width - display_width) / 2;
		}
		else
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = 0;
		}
		
		if (height < display_height)
		{
			bitmap_skip_column = 0;
			display_skip_column = (display_height - height) / 2;
		} 
		else if (height > display_height)
		{
			bitmap_skip_column = (height - display_height) / 2;
			display_skip_column = 0;
		}
		else
		{
			bitmap_skip_column = 0;
			display_skip_column = 0;
		}
		
		set_ui_visarea (bitmap_skip_pixels, bitmap_skip_column + 1, 
			width - 1 - bitmap_skip_pixels, height - 2 - bitmap_skip_column);
	}
	else if (camera_type == kTypeHP1)
	{
		if (frameskip < 0) frameskip = 0;
		if (frameskip >= FRAMESKIP_LEVELS) frameskip = FRAMESKIP_LEVELS-1;
	
		if (use_dirty == -1)	/* dirty=auto in mame.cfg? */
		{
			/* Is the game using a dirty system? */
			if ((Machine->drv->video_attributes & VIDEO_SUPPORTS_DIRTY) || vector_game)
				use_dirty = 1;
			else
				use_dirty = 0;
		}

		if (Machine->drv->video_attributes & VIDEO_TYPE_VECTOR)
		{
			if (gResolution < 0)
			{
				width = 180;
				height = 120;
			}
			else
			{
				width = 360;
				height = 240;
			}
			if (Machine->orientation & ORIENTATION_SWAP_XY)
			{
				int temp;
		
				temp = width;
				width = height;
				height = temp;
			}
			scale_vectorgames(width, height, &width, &height);
		}
	
		if (depth == 16)
			scrbitmap = osd_new_bitmap(width,height,16);
		else
			scrbitmap = osd_new_bitmap(width,height,8);
	
		if (!scrbitmap) return 0;
	
		if (!osd_set_display(width, height, attributes))
			return 0;
		
		if (Machine->orientation & ORIENTATION_SWAP_XY)
		{
			int temp;
	
			temp = width;
			width = height;
			height = temp;
		}
	
		if (gResolution < 0)
		{
			display_height = 120;
			display_width = 180;
			interlaced = 0;
			doublesize = 1;
//		    LMSwitchLiveviewMode();
		}
		else
		{
			display_height = 240;
			display_width = 360;
			interlaced = 0;
			doublesize = 0;
//		    LMSwitchLiveviewMode();
		}
	
		if (width < display_width)
		{
			display_skip_pixels = (display_width - width) / 2;
			bitmap_skip_pixels = 0;
		}
		else if (width > display_width)
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = (width - display_width) / 2;
		}
		else
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = 0;
		}
		
		if (height < display_height)
		{
			bitmap_skip_column = 0;
			display_skip_column = (display_height - height) / 2;
		} 
		else if (height > display_height)
		{
			bitmap_skip_column = (height - display_height) / 2;
			display_skip_column = 0;
		}
		else
		{
			bitmap_skip_column = 0;
			display_skip_column = 0;
		}
		
		set_ui_visarea (bitmap_skip_pixels, bitmap_skip_column + 1, 
			width - 1 - bitmap_skip_pixels, height - 2 - bitmap_skip_column);	
	}
	else if (camera_type == kTypeMinolta1)
	{
			if (frameskip < 0) frameskip = 0;
		if (frameskip >= FRAMESKIP_LEVELS) frameskip = FRAMESKIP_LEVELS-1;
	
		if (use_dirty == -1)	/* dirty=auto in mame.cfg? */
		{
			/* Is the game using a dirty system? */
			if ((Machine->drv->video_attributes & VIDEO_SUPPORTS_DIRTY) || vector_game)
				use_dirty = 1;
			else
				use_dirty = 0;
		}

		if (Machine->drv->video_attributes & VIDEO_TYPE_VECTOR)
		{
			if (gResolution < 0)
			{
				scale_vectorgames(180, 120, &width, &height);
				width = 180;
				height = 120;
			}
			else
			{
				width = 360;
				height = 240;
			}
			if (Machine->orientation & ORIENTATION_SWAP_XY)
			{
				int temp;
		
				temp = width;
				width = height;
				height = temp;
			}
		}
	
		if (depth == 16)
			scrbitmap = osd_new_bitmap(width,height,16);
		else
			scrbitmap = osd_new_bitmap(width,height,8);
	
		if (!scrbitmap) return 0;
	
		if (!osd_set_display(width, height, attributes))
			return 0;
		
		if (Machine->orientation & ORIENTATION_SWAP_XY)
		{
			int temp;
	
			temp = width;
			width = height;
			height = temp;
		}
	
		if (gResolution < 0)
		{
			display_height = 120;
			display_width = 180;
			interlaced = 0;
			doublesize = 1;
			LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
		}
		else
		{
			display_height = 240;
			display_width = 360;
			interlaced = 0;
			doublesize = 0;
			LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
		}
	
		if (width < display_width)
		{
			display_skip_pixels = (display_width - width) / 2;
			bitmap_skip_pixels = 0;
		}
		else if (width > display_width)
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = (width - display_width) / 2;
		}
		else
		{
			display_skip_pixels = 0;
			bitmap_skip_pixels = 0;
		}
		
		if (height < display_height)
		{
			bitmap_skip_column = 0;
			display_skip_column = (display_height - height) / 2;
		} 
		else if (height > display_height)
		{
			bitmap_skip_column = (height - display_height) / 2;
			display_skip_column = 0;
		}
		else
		{
			bitmap_skip_column = 0;
			display_skip_column = 0;
		}
		
		set_ui_visarea (bitmap_skip_pixels, bitmap_skip_column + 1, 
			width - 1 - bitmap_skip_pixels, height - 2 - bitmap_skip_column);	
	}

	return scrbitmap;
}

/* set the actual display screen but don't allocate the screen bitmap */
int osd_set_display(int width,int height, int attributes)
{


	if (Machine->orientation & ORIENTATION_SWAP_XY)
	{
		int temp;

		temp = width;
		width = height;
		height = temp;
	}
	/* Mark the dirty buffers as dirty */

	if (use_dirty)
	{
		if (vector_game)
			/* vector games only use one dirty buffer */
			init_dirty (0);
		else
			init_dirty(1);
		swap_dirty();
		init_dirty(1);
	}
	
	vsync_frame_rate = Machine->drv->frames_per_second;

	warming_up = 1;
	
	return 1;
}



/* shut up the display */
void osd_close_display(void)
{
	if (scrbitmap)
	{
		osd_free_bitmap(scrbitmap);
		scrbitmap = NULL;
	}
	
	if (pensrgb)
	{
		free(pensrgb);
		pensrgb = 0;
	}
	
	if (pens823 && (pens823 != (unsigned long *)(M_CPM_MEM1)))
	{
		free(pens823);
		pens823 = 0;
	}

	if (pens823left && (pens823left != (unsigned long *)(M_CPM_MEM2)))
	{
		free(pens823left);
		pens823left = 0;
	}
	
	if (pens823right && (pens823right != (unsigned long *)(M_CPM_MEM3)))
	{
		free(pens823right);
		pens823right = 0;
	}
	
	if (pensDCAM)
	{
		free(pensDCAM);
		pensDCAM = 0;
	}

	if (pensDCAMleft && (pensDCAMleft != (unsigned long *)(M_DPSRAM_MEM0)))
	{
		free(pensDCAMleft);
		pensDCAMleft = 0;
	}
	
	if (pensDCAMright && (pensDCAMright != (unsigned long *)(M_DPSRAM_MEM1)))
	{
		free(pensDCAMright);
		pensDCAMright = 0;
	}
	
	interlaced = 0;
	doublesize = 0;
	current_display = 0;
}



int osd_allocate_colors(unsigned int totalcolors,const unsigned char *palette,unsigned short *pens,int modifiable)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		int i;
	
		// add two for our black and white
		totalcolors += 2;
		
		if (totalcolors < 512)
		{
			// 2K of zero wait state RAM
			pens823 = (unsigned long *)(M_CPM_MEM1);
			pens823left = (unsigned long *)(M_CPM_MEM2);
			pens823right = (unsigned long *)(M_CPM_MEM3);
		}
		else
		{
			pens823 = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
			pens823left = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
			pens823right = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
		}
	
		pensrgb = (unsigned char *)malloc(3 * totalcolors * sizeof(unsigned char));
	
		// add our black first
		pens823[0] = RGB2YCYC823(0,0,0);
		pens823left[0] = RGB2YCYC823LEFT(0,0,0);
		pens823right[0] = RGB2YCYC823RIGHT(0,0,0);
	
		pensrgb[0] = 0;
		pensrgb[1] = 0;
		pensrgb[2] = 0;
	
		// add our white second
		pens823[1] = RGB2YCYC823(255,255,255);
		pens823left[1] = RGB2YCYC823LEFT(255,255,255);
		pens823right[1] = RGB2YCYC823RIGHT(255,255,255);
	
		pensrgb[3] = 255;
		pensrgb[4] = 255;
		pensrgb[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < totalcolors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			pensrgb[3*i+0] = r;
			pensrgb[3*i+1] = g;
			pensrgb[3*i+2] = b;
			
			pens[x] = i;
			pens823[i] = RGB2YCYC823(r,g,b);
			pens823left[i] = RGB2YCYC823LEFT(r,g,b);
			pens823right[i] = RGB2YCYC823RIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;
	}
	else if (camera_type == kTypeHP2)
	{
		int i;
	
		// add two for our black and white
		totalcolors += 2;
		
		pens823 = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
		pens823left = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
		pens823right = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
	
		pensrgb = (unsigned char *)malloc(3 * totalcolors * sizeof(unsigned char));
	
		// add our black first
		pens823[0] = RGB2YCYC823(0,0,0);
		pens823left[0] = RGB2YCYC823LEFT(0,0,0);
		pens823right[0] = RGB2YCYC823RIGHT(0,0,0);
	
		pensrgb[0] = 0;
		pensrgb[1] = 0;
		pensrgb[2] = 0;
	
		// add our white second
		pens823[1] = RGB2YCYC823(255,255,255);
		pens823left[1] = RGB2YCYC823LEFT(255,255,255);
		pens823right[1] = RGB2YCYC823RIGHT(255,255,255);
	
		pensrgb[3] = 255;
		pensrgb[4] = 255;
		pensrgb[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < totalcolors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			pensrgb[3*i+0] = r;
			pensrgb[3*i+1] = g;
			pensrgb[3*i+2] = b;
			
			pens[x] = i;
			pens823[i] = RGB2YCYC823(r,g,b);
			pens823left[i] = RGB2YCYC823LEFT(r,g,b);
			pens823right[i] = RGB2YCYC823RIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;
	}
	else if ((camera_type == kTypeMinolta1) || (camera_type == kTypeHP1))
	{
		int i;
	
		// add two for our black and white
		totalcolors += 2;
		
		if (totalcolors < 512)
		{
			// 2K of zero wait state RAM
			pensDCAM = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
			pensDCAMleft = (unsigned long *)(M_DPSRAM_MEM0);
			pensDCAMright = (unsigned long *)(M_DPSRAM_MEM1);
		}
		else
		{
			pensDCAM = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
			pensDCAMleft = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
			pensDCAMright = (unsigned long *)malloc(totalcolors * sizeof(unsigned long));
		}
	
		pensrgb = (unsigned char *)malloc(3 * totalcolors * sizeof(unsigned char));
	
		// add our black first
		pensDCAM[0] = RGB2CYCYDCAM(0,0,0);
		pensDCAMleft[0] = RGB2CYCYDCAMLEFT(0,0,0);
		pensDCAMright[0] = RGB2CYCYDCAMRIGHT(0,0,0);
	
		pensrgb[0] = 0;
		pensrgb[1] = 0;
		pensrgb[2] = 0;
	
		// add our white second
		pensDCAM[1] = RGB2CYCYDCAM(255,255,255);
		pensDCAMleft[1] = RGB2CYCYDCAMLEFT(255,255,255);
		pensDCAMright[1] = RGB2CYCYDCAMRIGHT(255,255,255);
	
		pensrgb[3] = 255;
		pensrgb[4] = 255;
		pensrgb[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < totalcolors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			pensrgb[3*i+0] = r;
			pensrgb[3*i+1] = g;
			pensrgb[3*i+2] = b;
			
			pens[x] = i;
			pensDCAM[1] = RGB2CYCYDCAM(r,g,b);
			pensDCAMleft[i] = RGB2CYCYDCAMLEFT(r,g,b);
			pensDCAMright[i] = RGB2CYCYDCAMRIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;	
	}
	
	return 0;
}

void osd_modify_pen(int pen,unsigned char red, unsigned char green, unsigned char blue)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2) || (camera_type == kTypeHP2))
	{
		if (pens823)
		{
			pens823[pen] = RGB2YCYC823(red,green,blue);
		}
		if (pens823left)
		{
			pens823left[pen] = RGB2YCYC823LEFT(red,green,blue);
		}
		if (pens823right)
		{
			pens823right[pen] = RGB2YCYC823RIGHT(red,green,blue);
		}
	}
	else if ((camera_type == kTypeMinolta1) || (camera_type == kTypeHP1))
	{
		if (pensDCAMleft)
		{
			pensDCAMleft[pen] = RGB2CYCYDCAMLEFT(red,green,blue);
		}
		if (pensDCAMright)
		{
			pensDCAMright[pen] = RGB2CYCYDCAMRIGHT(red,green,blue);
		}
	}
	
	// mark the whole screen dirty
	osd_mark_dirty(0, 0, scrbitmap->width-1,scrbitmap->height-1,1);
}

void osd_get_pen(int pen,unsigned char *red, unsigned char *green, unsigned char *blue)
{
	if (pensrgb)
	{
		*red = pensrgb[3*pen];
		*green = pensrgb[3*pen+1];
		*blue = pensrgb[3*pen+2];
	}
	else
	{
		*red = 0;
		*green = 0;
		*blue = 0;
	}
}




int osd_skip_this_frame(void)
{
	static const int skiptable[FRAMESKIP_LEVELS][FRAMESKIP_LEVELS] =
	{
		{ 0,0,0,0,0,0,0,0,0,0,0,0 },
		{ 0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 0,0,0,0,0,1,0,0,0,0,0,1 },
		{ 0,0,0,1,0,0,0,1,0,0,0,1 },
		{ 0,0,1,0,0,1,0,0,1,0,0,1 },
		{ 0,1,0,0,1,0,1,0,0,1,0,1 },
		{ 0,1,0,1,0,1,0,1,0,1,0,1 },
		{ 0,1,0,1,1,0,1,0,1,1,0,1 },
		{ 0,1,1,0,1,1,0,1,1,0,1,1 },
		{ 0,1,1,1,0,1,1,1,0,1,1,1 },
		{ 0,1,1,1,1,1,0,1,1,1,1,1 },
		{ 0,1,1,1,1,1,1,1,1,1,1,1 }
	};

	return skiptable[frameskip][frameskip_counter];
}

/* Update the display. */
void osd_update_video_and_audio(void)
{
	static const int waittable[FRAMESKIP_LEVELS][FRAMESKIP_LEVELS] =
	{
		{ 1,1,1,1,1,1,1,1,1,1,1,1 },
		{ 2,1,1,1,1,1,1,1,1,1,1,0 },
		{ 2,1,1,1,1,0,2,1,1,1,1,0 },
		{ 2,1,1,0,2,1,1,0,2,1,1,0 },
		{ 2,1,0,2,1,0,2,1,0,2,1,0 },
		{ 2,0,2,1,0,2,0,2,1,0,2,0 },
		{ 2,0,2,0,2,0,2,0,2,0,2,0 },
		{ 2,0,2,0,0,3,0,2,0,0,3,0 },
		{ 3,0,0,3,0,0,3,0,0,3,0,0 },
		{ 4,0,0,0,4,0,0,0,4,0,0,0 },
		{ 6,0,0,0,0,0,6,0,0,0,0,0 },
		{12,0,0,0,0,0,0,0,0,0,0,0 }
	};
	static int showfps,showfpstemp;
	TICKER curr;
	static TICKER prev_measure,this_frame_base,prev;
	static int speed = 100;
	static int vups,vfcount;
	int need_to_clear_bitmap = 0;
	int already_synced;


	if (warming_up)
	{
		/* first time through, initialize timer */
		prev_measure = ticker() - FRAMESKIP_LEVELS * TICKS_PER_SEC/Machine->drv->frames_per_second;
		warming_up = 0;
	}

	if (frameskip_counter == 0)
		this_frame_base = prev_measure + FRAMESKIP_LEVELS * TICKS_PER_SEC/Machine->drv->frames_per_second;

	if (throttle)
	{
		static TICKER last;

		/* if too much time has passed since last sound update, disable throttling */
		/* temporarily - we wouldn't be able to keep synch anyway. */
		curr = ticker();
		if ((curr - last) > 2*TICKS_PER_SEC / Machine->drv->frames_per_second)
			throttle = 0;
		last = curr;

		already_synced = 1;

		throttle = 1;
	}
	else
		already_synced = 1;


	if (osd_skip_this_frame() == 0)
	{
		if (showfpstemp)
		{
			showfpstemp--;
			if (showfps == 0 && showfpstemp == 0)
			{
				need_to_clear_bitmap = 1;
			}
		}


		if (input_ui_pressed(IPT_UI_SHOW_FPS))
		{
			if (showfpstemp)
			{
				showfpstemp = 0;
				need_to_clear_bitmap = 1;
			}
			else
			{
				showfps ^= 1;
				if (showfps == 0)
				{
					need_to_clear_bitmap = 1;
				}
			}
		}


		/* now wait until it's time to update the screen */
		if (throttle)
		{
			profiler_mark(PROFILER_IDLE);
			if (0)
			{
			}
			else
			{
				TICKER target;

				
				curr = ticker();

				if (already_synced == 0)
				{
			/* wait only if the audio update hasn't synced us already */

					target = this_frame_base +
							frameskip_counter * TICKS_PER_SEC/Machine->drv->frames_per_second;

			if (curr - target < 0)
			{
				do
				{
							curr = ticker();
				} while (curr - target < 0);
			}
				}

			}
			profiler_mark(PROFILER_END);
		}
		else curr = ticker();

		
		/* for the FPS average calculation */
		if (++frames_displayed == FRAMES_TO_SKIP)
			start_time = curr;
		else
			end_time = curr;

		
		if (frameskip_counter == 0)
		{
			int divdr;


			divdr = Machine->drv->frames_per_second * (curr - prev_measure) / (10 * FRAMESKIP_LEVELS);
			speed = (TICKS_PER_SEC + divdr/2) * 10 / divdr;

			prev_measure = curr;
		}
				
		prev = curr;

		vfcount += waittable[frameskip][frameskip_counter];
		if (vfcount >= Machine->drv->frames_per_second)
		{
			extern int vector_updates; /* avgdvg_go()'s per Mame frame, should be 1 */


			vfcount = 0;
			vups = vector_updates;
			vector_updates = 0;
		}

		if (showfps || showfpstemp)
		{
			int fps;
			char buf[30];
			int divdr;


			divdr = 100 * FRAMESKIP_LEVELS;
			fps = (Machine->drv->frames_per_second * (FRAMESKIP_LEVELS - frameskip) * speed + (divdr / 2)) / divdr;
			sprintf(buf,"%s%2d%4d%%%4d/%d fps",autoframeskip?"auto":"fskp",frameskip,speed,fps,(int)(Machine->drv->frames_per_second+0.5));
			ui_text(buf,Machine->uiwidth-strlen(buf)*Machine->uifontwidth,0);
			if (vector_game)
			{
				sprintf(buf," %d vector updates",vups);
				ui_text(buf,Machine->uiwidth-strlen(buf)*Machine->uifontwidth,Machine->uifontheight);
			}
		}

		/* copy the bitmap to screen memory */
		profiler_mark(PROFILER_BLIT);
		update_screen();
		profiler_mark(PROFILER_END);

		if (need_to_clear_bitmap)
			osd_clearbitmap(scrbitmap);

		if (use_dirty)
		{
			if (!vector_game)
				swap_dirty();
			init_dirty(0);
		}

		if (need_to_clear_bitmap)
			osd_clearbitmap(scrbitmap);


		if (throttle && autoframeskip && frameskip_counter == 0)
		{
			static int frameskipadjust;
			int adjspeed;

			/* adjust speed to video refresh rate if vsync is on */
			adjspeed = speed * Machine->drv->frames_per_second / vsync_frame_rate;

			if (adjspeed >= 100)
			{
				frameskipadjust++;
				if (frameskipadjust >= 4)
				{
					frameskipadjust = 0;
					if (frameskip > 0) frameskip--;
				}
			}
			else
			{
				if (adjspeed < 80)
					frameskipadjust -= (90 - adjspeed) / 5;
				else
				{
					/* don't push frameskip too far if we are close to 100% speed */
					if (frameskip < 8)
						frameskipadjust--;
				}

				while (frameskipadjust <= -3)
				{
					frameskipadjust += 3;
					if (frameskip < 8 /* FRAMESKIP_LEVELS-1 */) frameskip++;
				}
			}
		}
	}

	if (input_ui_pressed(IPT_UI_FRAMESKIP_INC))
	{
		if (autoframeskip)
		{
			autoframeskip = 0;
			frameskip = 0;
		}
		else
		{
			if (frameskip == FRAMESKIP_LEVELS-1)
			{
				frameskip = 0;
				autoframeskip = 1;
			}
			else
				frameskip++;
		}

		if (showfps == 0)
			showfpstemp = 2*Machine->drv->frames_per_second;

		/* reset the frame counter every time the frameskip key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}

	if (input_ui_pressed(IPT_UI_FRAMESKIP_DEC))
	{
		if (autoframeskip)
		{
			autoframeskip = 0;
			frameskip = FRAMESKIP_LEVELS-1;
		}
		else
		{
			if (frameskip == 0)
				autoframeskip = 1;
			else
				frameskip--;
		}

		if (showfps == 0)
			showfpstemp = 2*Machine->drv->frames_per_second;

		/* reset the frame counter every time the frameskip key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}

	if (input_ui_pressed(IPT_UI_THROTTLE))
	{
		throttle ^= 1;

		/* reset the frame counter every time the throttle key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}


	frameskip_counter = (frameskip_counter + 1) % FRAMESKIP_LEVELS;
}



void osd_set_gamma(float _gamma)
{
	osd_gamma_correction = _gamma;
}

float osd_get_gamma(void)
{
	return osd_gamma_correction;
}

/* brightess = percentage 0-100% */
void osd_set_brightness(int _brightness)
{
	brightness = _brightness;
}

int osd_get_brightness(void)
{
	return brightness;
}


void osd_save_snapshot(void)
{
	save_screen_snapshot();
}

void osd_pause(int paused)
{
}

void osd_mark_vector_dirty(int x, int y)
{
	MARKDIRTY(y);
}

