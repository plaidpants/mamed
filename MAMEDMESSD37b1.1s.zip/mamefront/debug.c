#include "taskLib.h"
#include "stdio.h"

void taskShowProfileReset(void);
void taskShowProfile(void);
void mySwitchHook(WIND_TCB *pOldTcb, WIND_TCB *pNewTcb);
void taskShowProfileStart(void);
void taskShowProfileStop(void);

static int startTick, stopTick;
static int extraTicks;

void taskShowProfileReset(void)
{
	int idList[100];
	int max;
	int i;
	int currentTick;
	
	taskLock();
	max = taskIdListGet(idList, 100);
	
	currentTick = tickGet();
	for (i = 0; i < max; i++)
	{
		((WIND_TCB *)(idList[i]))->spare3 = currentTick;
		((WIND_TCB *)(idList[i]))->spare4 = 0;
	}
	
	extraTicks = 0;
	taskUnlock();
}

void mySwitchHook(WIND_TCB *pOldTcb, WIND_TCB *pNewTcb)
{
	int ticks = tickGet();
	pOldTcb->spare4 = pOldTcb->spare4 + ticks - pOldTcb->spare3;
	pNewTcb->spare3 = ticks;
}

void myDeleteHook(WIND_TCB *pTcb)
{
	int totalTicks;
	int percent;
	
	totalTicks = tickGet() - startTick;

	extraTicks = extraTicks + pTcb->spare4;
/*	
	percent = (pTcb->spare4 * 100) / totalTicks;
	
	if (percent)
	{
		printf("task : %s, ticks : %d percent \n", 
			pTcb->name, 
			percent);
	}
*/
}

void myCreateHook(WIND_TCB *pTcb)
{
	pTcb->spare3 = tickGet();
	pTcb->spare4 = 0;
}

void taskShowProfileStart(void)
{
	taskShowProfileReset();
	startTick = tickGet();
	extraTicks = 0;
	taskSwitchHookAdd(mySwitchHook);
	taskDeleteHookAdd(myDeleteHook);
	taskCreateHookAdd(myCreateHook);
}

void taskShowProfileStop(void)
{
	taskSwitchHookDelete(mySwitchHook);
	taskDeleteHookDelete(myDeleteHook);
	taskCreateHookDelete(myCreateHook);
	stopTick = tickGet();
	taskShowProfile();
}

void taskShowProfile(void)
{
	int idList[100];
	int max;
	int i;
	int totalTicks;
	int percent;
	int otherTicks;
	
	taskLock();
	
	otherTicks = 0;
	
	totalTicks = stopTick - startTick;
	
	max = taskIdListGet(idList, 100);
	
	for (i = 0; i < max; i++)
	{
		percent = (((WIND_TCB *)(idList[i]))->spare4 * 100) / totalTicks;
		
		if (percent)
		{
			printf("task : %s, ticks : %d percent \n", 
				((WIND_TCB *)(idList[i]))->name, 
				percent);
		}
		else
		{
			otherTicks = otherTicks + ((WIND_TCB *)(idList[i]))->spare4;
		}
	}
	
	printf("other tasks total ticks : %d percent \n", (otherTicks * 100) / totalTicks);

	printf("deleted tasks total ticks : %d percent \n", (extraTicks * 100) / totalTicks);
	
	taskUnlock();
}
