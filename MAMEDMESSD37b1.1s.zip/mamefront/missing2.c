/* The DC290 is missing some GNU generated functions so I will force
   them to be included here. */

extern void inflate(void);
 
void * missing2[] = {
	inflate
};