Mamed Build Self Booty
------------------------
By Hyper Gamer
------------------------
Special Notice : You MUST get a mamed build from http://digita.mame.net
                 and then put it in the /data/ directory. Then you must 
                 open the boot.rc file in a text editor ( most preferably
                 Note Pad ), and then edit the part where it says 
                 "/cd/mamed1.klf"  make sure that is linking to the right
                 MAMED build you are using with this standalone MAMED 
                 building self boot tool. Also remember to have the right
                 roms that you are using on the correct MAMED build you
                 are using. Right now I heard build 15 does not play any
                 roms, so as of right now its useless.
                 If you want to have more builds on one disc, make sure
                 you get KoFFan's MAMED with KOSH ( and make sure you have
                 a keyboard ), and then add all the drivers you want and 
                 have fun.


1. Make sure you extract the files somewhere on your hard drive.

2. Put the roms in /data/roms   directory. Make sure they
   are zipped up in there. The roms do not require any folders
   for them, its suggested they stay zipped up also.

3. Run mkisofs.bat , it will make an iso out of the data directory.
   Wait for it to finish.

4. After that run the bin2boot.bat file , it will turn your data.iso into
   a data.cdi. *new* It will then also delete the old useless data.iso 
   after it finishes making the data.cdi file.

5. Now you can burn it and enjoy...


Note - if you want to convert that cdi image to another format ( Nero ),
       then I suggest you use CDI2NRG from http://www.cdirip.cjb.net

Note 2 - This download is not supported by the MAMED author from 
         http://digita.mame.net . Please do not bother him for updating
         Mamed Build (#) Self Booty programs, or asking for support on 
         it.

History of Self Booty for Mamed Build 1
-----------------------------------------

version 0.1 - First release.

version 0.2 - Dumped in a ip.bin from DreamSMS , this kit should
              now make a good working self boot image. Sorry to
              the people who made several coasters. This will most
              likely be the last batch file release, next version
              will be going Visual Basic instead.

This program was designed to aid people in making selfboots with bin2boot.
I take no credit in programing bin2boot, xeal.cjb.net is the web-site this
original tool comes from.