Mamed Build Self Booty With Hyper's MAMED Frontend
---------------------------------------------------
By Hyper Gamer
---------------------------------------------------
Note - just download all the MAMED packs and dump them 
       in the /data/ directory, or just download the 
       MAMED pack files that you want and just put it 
       in there. Also loading of programs take a few 
       moments, so don't think its a coaster because it
       takes 15 seconds to load the emulator pack.


1. Make sure you extract the files somewhere on your hard drive.

2. Put the roms in /data/roms   directory. Make sure they
   are zipped up in there. The roms do not require any folders
   for them, its suggested they stay zipped up also.

   You do not have to put roms on this disc if you do not want, 
   you may make another disc with a /roms directory if you want
   and all the roms.

3. Run mkisofs.bat , it will make an iso out of the data directory.
   Wait for it to finish.

4. After that run the bin2boot.bat file , it will turn your data.iso into
   a image.cdi. *new* It will then also delete the old useless data.iso 
   after it finishes making the data.cdi file.

5. Now you can burn it and enjoy...


Note - if you want to convert that cdi image to another format ( Nero ),
       then I suggest you use CDI2NRG from http://www.cdirip.cjb.net

Note 2 - This download is not supported by the MAMED author from 
         http://digita.mame.net . Please do not bother him for updating
         Mamed Build (#) Self Booty programs, or asking for support on 
         it.

History of Self Booty for Mamed Build 1
-----------------------------------------

version 0.1 - First release.

version 0.2 - Dumped in a ip.bin from DreamSMS , this kit should
              now make a good working self boot image. Sorry to
              the people who made several coasters. This will most
              likely be the last batch file release, next version
              will be going Visual Basic instead.

version 0.3 - This is probably the last kit, and i think we should
              call this the special edition, since it has the new
              frontend. Also fixed the error saying that image.cdi 
              was data.cdi , sorry guys for the error.

This program was designed to aid people in making selfboots with bin2boot.
I take no credit in programing bin2boot, xeal.cjb.net is the web-site this
original tool comes from.