/***************************************************************************

  osdepend.c

  OS dependant stuff (display handling, keyboard scan...)
  This is the only file which should me modified in order to port the
  emulator to a different system.

***************************************************************************/

#include <stdio.h>
#include <taskLib.h>
#include <memLib.h>
#include "osdepend.h"

/* HP C500 & Kodak DC290 button IDs */
typedef enum 
{
    kDigitaMenu,
    kDigitaOverlay,
    kDigitaPortraitLeft,
    kDigitaPortraitRight,
    kDigitaLCDStatus2,
    kDigitaLCDStatus1,
    kDigitaSpare1,
    kDigitaSpare2,
    kDigitaSoftKey2,
    kDigitaSoftKey3,
    kDigitaZoomOut,
    kDigitaZoomIn,
    kDigitaShutter1,
    kDigitaShutter2,
    kDigitaRecord,
    kDigitaInstantReview,
    kDigitaHostMode,
    kDigitaPlayMode,
    kDigitaUpArrow,
    kDigitaLeftArrow,
    kDigitaRightArrow,
    kDigitaDownArrow,
    kDigitaLCDOnOff,
    kDigitaSoftKey1,
    kDigitaPowerOnOff,
    kDigitaUnused6,
    kDigitaUnused5,
    kDigitaUnused4,
    kDigitaUnused3,
    kDigitaUnused2,
    kDigitaUnused1,
    kDigitaUnused0,
    kDigitaReviewMode,
    kDigitaCaptureMode,
    kDigitaLandscape
} TBTNDigitaButtonId;

// Kodak DC220, DC260, & DC265 button IDs */
#define kSoftkeyLeft   					14
#define kOverlayButton 					16
#define kDownArrow     					30
#define kRightArrow    					28
#define kLeftArrow     					29
#define kUpArrow       					31
#define kRecordButton  					17
#define kShutter2      					 9
#define kShutter1      					10
#define kZoomIn        					26
#define kZoomOut       					27
#define kSoftkeyRight  					12
#define kSoftkeyMid    					13
#define kMenuButton    					25
#define kPowerEvent    					11
#define kDiskEvent     					102
#define kSleepEvent   					103
#define kStatusLCDEvent    				104
#define kAVJackEvent   					105
#define kStatusLCDBatteryStatusEvent  	106
#define kStatusLCDCFAnimationEvent  	107
#define kMode0Button   					23
#define kMode1Button   					22
#define kMode2Button   					21
#define kMode3Button   					20
#define kShutterHome    				 8
#define kInstantReview  				116
#define kSpare2        					124
#define kSpare1        					125
#define kLCDStatus1    					126
#define kLCDStatus2    					127
#define kPortrait      					128
#define kLandscape     					129
#define kLCDOnOff      					130
#define kAlertEvent    					1100

/* Minolta button IDs */
const short kMinoltaLCDOnOff				=  0;
const short kMinoltaPowerEvent				=  1;
const short kMinoltaShutter2				=  2;
const short kMinoltaShutter1				=  3;
const short kMinoltaMode3Button				=  4; 
const short kMinoltaMode2Button				=  5;
const short kMinoltaMode0Button				=  6; 
const short kMinoltaMode1Button				=  7;
const short kMinoltaUpArrow					=  8;
const short kMinoltaDownArrow				=  9;
const short kMinoltaLeftArrow				= 10;
const short kMinoltaRightArrow				= 11;
const short kMinoltaSoftkeyRight			= 12;
const short kMinoltaSoftkeyMid				= 13;
const short kMinoltaSoftkeyLeft				= 14;
const short kMinoltaMenuButton				= 16;
const short kMinoltaOverlayButton			= 17;
const short kMinoltaStatusButton			= 18;
const short kMinoltaRecordButton			= 19;
const short kMinoltaMacroButton				= 21;
const short kMinoltaAVJackButton			= 22;
const short kMinoltaACJackButton			= 23;
const short kMinoltaDiskEvent    			= 102;

/* Digita Common Structures */
typedef struct {
	char fPName[4];
	long fType;
	char fStr[32];
} TPARMNameTypeValue;
typedef TPARMNameTypeValue *TPARMNameTypeValuePtr;

typedef enum {
    kButtonClassEvent = 2,
} TEMEventClass;

typedef struct {
	unsigned short		fEvClass;
	unsigned long		fEvModifiers;
	long 				fPosition;
	long    			fButtonIndex;
	long				fLength;
	void *				fDataPtr;
	void *				fDeallocProc;
} TEMEventRecord;
typedef TEMEventRecord *TEMEventRecordPtr;

/* Common Digita function prototypes */
extern void  (*GMInitGraf)(void *);
extern void  (*GMInitFonts)(void);
extern short (*AMGetSelfAppID)(char * appID);
extern short (*EMOpen)(const char appID, int signo);
extern short (*EMGetEvent)(const char appID, TEMEventRecordPtr *message);
extern short (*EMReleaseEventRecord)(TEMEventRecordPtr message);
extern short (*MMNewAlignedPtr)(unsigned long size, unsigned long alignment, char *p);
extern short (*PARMGetProductInfo) (char *tag, TPARMNameTypeValuePtr ntvp);
extern unsigned long (*PMPowerDown)(unsigned long deepSleepTime);

/* Minolta & Kodak DC220, DC260, DC265 */
extern short (*LMEnableLCDController)(void);
extern short (*LMSetupBuffers)(unsigned long *lcdBuffer, unsigned long *displayBuffer, char interlace);
extern short (*LMSwitchBuffer)(unsigned long *lcdBuffer);

/* HP C500 & Kodak DC290 */
extern void (*LMAllocateBuffers)(void);
extern void (*LMSwitchNormalMode)(void);
extern void (*LMSwitchToNextLiveviewFrame)(void);
extern void (*LMSwitchLiveviewMode)(void);
extern char * (*LMGetNextLiveviewFrame)(void);
extern short (*AMAppInit)(long appStyle);
extern void (*AMAppExit)(const char appID);

/* Kodak DC290 only */
extern unsigned long (*SUPowerDown)(unsigned long deepSleepTime);

/* HP C500 only */
extern unsigned long pmPowerDown(unsigned long deepSleepTime);

/* Minolta 1500 EX only */
extern int (*MPUSendLens)(unsigned int value);

/* Kodak DC220, DC260, DC265, & DC290 only */
#define LED_VIEWFINDER 		0x00000000
#define LED_OFF 			0x00000200
extern int (*MPUSetLED)(unsigned int ledstat);
extern int (*MPUInit)(void);
extern int smMconStat;

/* Multipac stuff */
unsigned long RGB2YCYCRight( unsigned char r, unsigned char g, unsigned char b);
unsigned long RGB2YCYCLeft( unsigned char r, unsigned char g, unsigned char b);
unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b);
void * eventHandlerTask(void * dummy);
void detect_camera_type(void);

static unsigned long * 		gLCD_buffer;
unsigned long * 			gLCD_buffer1;
unsigned long * 			gLCD_buffer2;
unsigned long * 			current_display = 0;

int bitmap_width;
int bitmap_height;
unsigned long display_height;
unsigned long display_width;

int first_free_pen = 0;

long camera_type = -1;

/* DCAM 2K sram address, use for color table lookup */
#define PHYS_M_DPSRAM_MEM0      0x1c000000
#define	PHYS_TO_K1(x)			((unsigned)(x)|0xA0000000)
#define M_DPSRAM_MEM0       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0)
#define M_DPSRAM_MEM1       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0 + 1024)

unsigned long * pensRight = (long *)M_DPSRAM_MEM0;
unsigned long * pensLeft = 	(long *)M_DPSRAM_MEM1;

/* 823 2K sram address, use for color table lookup */
unsigned long * pens823 = (unsigned long *)0xff002000;

unsigned short			lastButtonState;
unsigned short			lastButtonID;

char 		altAppID;
int			eventTaskID;		
int			multipacID;

unsigned char * bitmap = 0;

#define strKodakVendorName						"Eastman Kodak Company"
#define strKodakDC220ProductName				"KODAK DIGITAL SCIENCE DC220"
#define strKodakDC260ProductName				"KODAK DIGITAL SCIENCE DC260"
#define strKodakDC265ProductName				"KODAK DC265 ZOOM DIGITAL CAMERA"
#define strKodakDC290ProductName				"KODAK DC290 ZOOM DIGITAL CAMERA"
#define strHPVendorName							"Hewlett Packard"
#define strHPC500ProductName					"HP PhotoSmart C500"
#define strMinoltaVendorName					"Minolta Co., Ltd."
#define strMinoltaDimage1500EXProductName		"Dimage EX"

#define kTypeKodak1 		0
#define kTypeKodak2 		1
#define kTypeHP1 			2
#define kTypeMinolta1 		3

char vendor[50];
char product[50];

void detect_camera_type(void)
{
	short					err = 0;
	TPARMNameTypeValue		data;

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
}

void * eventHandlerTask(void * dummy)
{
	short result;
	
	while(TRUE)
	{
		TEMEventRecord *	event;

		// don't hog the system
		taskDelay(5);

		result = EMGetEvent(altAppID, &event);
		if (result != 0)
			continue;

		switch (event->fEvClass)
		{
			case kButtonClassEvent:
			{
				lastButtonState = event->fPosition;
				lastButtonID = event->fButtonIndex;
				
				if ((lastButtonID == kMinoltaPowerEvent) 
					&& (lastButtonState == 0) 
					&& (camera_type == kTypeMinolta1))
				{
					taskSuspend(multipacID);
					PMPowerDown(0);
					while(TRUE)
						taskDelay(10);
				}
				
				if ((lastButtonID == kPowerEvent) 
					&& (lastButtonState) 
					&& (camera_type == kTypeKodak1))
				{
					taskSuspend(multipacID);
					PMPowerDown(0);
					while(TRUE)
						taskDelay(10);
				}
				
				if ((lastButtonID == kDigitaPowerOnOff) 
					&& (lastButtonState == 0) 
					&& (camera_type == kTypeKodak2))
				{
					taskSuspend(multipacID);
					SUPowerDown(0);
					while(TRUE)
						taskDelay(10);
				}
				
				if ((lastButtonID == kDigitaPowerOnOff) 
					&& (lastButtonState) // note difference, after button down, no more buttons
					&& (camera_type == kTypeHP1))
				{
					taskSuspend(multipacID);
					/* HP's PMPowerDown() is not a function pointer, so call the function directly */
					pmPowerDown(1);
					while(TRUE)
						taskDelay(10);
				}
				break;
			}
			default:
			{
				break;
			}
		}

		result = EMReleaseEventRecord(event);
	}
}

void osd_setup_application(void)
{
	detect_camera_type();
	
	if (camera_type == kTypeMinolta1)
	{
		int i;

	    GMInitGraf(NULL);
	    GMInitFonts();
	
		// allocate 2 lcd buffers
		MMNewAlignedPtr((180 * 287 * 2 * 4), 16, (char *) &gLCD_buffer);
	
		// clear the display
		gLCD_buffer1 = gLCD_buffer;
		for (i = 0;i < 180 * 287 * 2;i++)
		{
			*gLCD_buffer1++ = 0x10801080; // this is black in the YCC LCD world
		}
		
		// set the globals
		gLCD_buffer1 = gLCD_buffer;
		gLCD_buffer2 = gLCD_buffer + 180 * 287;
		
		// display the port
	    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();
	
		MPUSendLens(1);
		
	    AMGetSelfAppID(&altAppID);
	    EMOpen(altAppID, 0);
	
		eventTaskID = taskSpawn("events", 10, 0, 4096, 
			(FUNCPTR)eventHandlerTask, NULL, 
			0, 0, 0, 0, 0, 0, 0, 0, 0);
		
		multipacID = taskIdSelf();
		taskPrioritySet(multipacID, 2);
	}
	else if (camera_type == kTypeHP1)
	{
	    GMInitGraf(NULL);
	    GMInitFonts();
	    LMAllocateBuffers();
	    LMEnableLCDController();
	    AMGetSelfAppID(&altAppID);
	    EMOpen(altAppID, 0);
	    LMSwitchLiveviewMode();
	    
		eventTaskID = taskSpawn("events", 10, 0, 4096, 
			(FUNCPTR)eventHandlerTask, NULL, 
			0, 0, 0, 0, 0, 0, 0, 0, 0);
		
		multipacID = taskIdSelf();
		taskPrioritySet(multipacID, 2);
	}
	else if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		int i;
		
		// initialized the MPU and wait for it to finish initializing
		MPUInit();
		while( !smMconStat )
			taskDelay(20);
	
		// allocate 2 lcd buffers
		MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);
	
		// clear the display
		gLCD_buffer1 = gLCD_buffer;
		for (i = 0;i < 288*216*2;i++)
		{
			*gLCD_buffer1++ = 0x80108010; // this is black in the YCC LCD world
		}
		
		// set the globals
		gLCD_buffer1 = gLCD_buffer;
		gLCD_buffer2 = gLCD_buffer + 288*216;
		
		// display the port
	    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();
	
		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
		
		AMGetSelfAppID(&altAppID);
		EMOpen(altAppID, 0);
	
		eventTaskID = taskSpawn("events", 10, 0, 4096, 
			(FUNCPTR)eventHandlerTask, NULL, 
			0, 0, 0, 0, 0, 0, 0, 0, 0);
		
		multipacID = taskIdSelf();
		
		if (camera_type == kTypeKodak1)
		{
			/* this symbols is removed on the DC290, you have to use 
			   taskSpawn() to set priority instead */
			taskPrioritySet(multipacID, 2);
		}
	}
}

/* put here anything you need to do when the program is started. Return 0 if */
/* initialization was successful, nonzero otherwise. */
int osd_init(void)
{
	first_free_pen = 0;

	if ((camera_type == kTypeHP1) || (camera_type == kTypeMinolta1))
	{	
		display_height = 240;
		display_width = 360;	
	}
	else if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		display_height = 216;
		display_width = 288;	
	}

	return 0;
}

/* put here cleanup routines to be executed when the program is terminated. */
void osd_exit(void)
{
}

/* Create a display screen, or window, large enough to accomodate a bitmap */
/* of the given dimensions. I don't do any test here (224x288 will just do */
/* for now) but one could e.g. open a window of the exact dimensions */
/* provided. Return a bitmap pointer or 0 in case of error. */
unsigned char *osd_create_display(int width,int height)
{
	bitmap_width = width;
	bitmap_height = height;
	
	bitmap = (char *)malloc(width * height * sizeof(unsigned char));
		
	return bitmap;
}

/* shut up the display */
void osd_close_display(void)
{
	free(bitmap);
}

#define kMathScaleBits  10
#define kMathScale     (1 << kMathScaleBits)
#define kMaxValue      (kMathScale * 240)
#define kMinValue      (kMathScale * 16)
#define kMaxYValue     (kMathScale * 240)
#define kMinYValue     (kMathScale * 16)

#define kYRcoeff    ((long)( 0.299 * kMathScale))
#define kYGcoeff    ((long)( 0.587 * kMathScale))
#define kYBcoeff    ((long)( 0.114 * kMathScale))

#define kCbRcoeff    ((long)( 0.1687 * kMathScale))
#define kCbGcoeff    ((long)( 0.3313 * kMathScale))
#define kCbBcoeff    ((long)( 0.5    * kMathScale))

#define kCrRcoeff    ((long)( 0.5    * kMathScale))
#define kCrGcoeff    ((long)( 0.4187 * kMathScale))
#define kCrBcoeff    ((long)( 0.0813 * kMathScale))

#define PIN(x)    ((x) > kMaxValue ? 240 : ((x) < kMinValue  ?  16 : (x >> kMathScaleBits)))
#define PINY(x)   ((x) > kMaxYValue ? 240 : ((x) < kMinYValue ? 16 : (x >> kMathScaleBits)))

#define PIN255(x) ((x) > 255 ? 255 : ((x) < 0  ?  0 : 255))

unsigned long RGB2YCYCRight( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + (PINY(v0) << 8) + ((PIN(v2) >> 1) << 16));
}

unsigned long RGB2YCYCLeft( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + ((PIN(v2) >> 1) << 16) + (PINY(v0) << 24));
}

unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) << 24) + (PINY(v0) << 16) + (PIN(v2) << 8) + (PINY(v0) << 0));
}

int osd_obtain_pen(unsigned char red, unsigned char green, unsigned char blue)
{
	if ((camera_type == kTypeMinolta1) || (camera_type == kTypeHP1))
	{
		if (first_free_pen < 256)
		{
			pensRight[first_free_pen] = RGB2YCYCRight(red,green,blue);
			pensLeft[first_free_pen] = RGB2YCYCLeft(red,green,blue);
			return first_free_pen++;
		}
	}
	else if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		if (first_free_pen < 256)
		{
			pens823[first_free_pen] = RGB2YCYC823(red,green,blue);
			return first_free_pen++;
		}
	}

	return 0;
}

/* Update the display. */
void osd_update_display(void)
{
	if (camera_type == kTypeMinolta1)
	{
		int i;
		int j;
		int row_end, col_end;
		unsigned long * walk_display;
		unsigned char * walk_bitmap;
		unsigned char * walk_bitmap2;
		
		if (current_display == gLCD_buffer1)
		{
			current_display = gLCD_buffer2;
		}
		else
		{
			current_display = gLCD_buffer1;
		}
	
		walk_display = current_display;
		walk_bitmap = bitmap;
	
		if (bitmap_height > display_width)
		{
			row_end = display_width;
		}
		else
		{
			row_end = bitmap_height;
		}
		
		if (bitmap_width > display_height)
		{
			col_end = display_height;
		}
		else
		{
			col_end = bitmap_width;
		}
		
		for (j = 0; j < row_end; j++)
		{
			walk_display = current_display + 6*(display_width/2) + ((display_width/2) - (j/2) - 18);
			walk_bitmap = bitmap + bitmap_width * j + 1;
			walk_bitmap2 = bitmap + bitmap_width * (j+1) + 1;
	
			for (i = 0; i < col_end; i++)
			{
				*walk_display = pensLeft[*walk_bitmap++];
				*walk_display += pensRight[*walk_bitmap2++];
				walk_display += (display_width/2);
			}
		}
		
		LMSwitchBuffer(current_display);
	
		taskDelay(1);
	}
	else if (camera_type == kTypeHP1)
	{
		int i;
		int j;
		int row_end, col_end;
		unsigned long * walk_display;
		unsigned char * walk_bitmap;
		unsigned char * walk_bitmap2;
		
		current_display = (unsigned long *)LMGetNextLiveviewFrame();
	
		walk_display = current_display;
		walk_bitmap = bitmap;
	
		if (bitmap_height > display_width)
		{
			row_end = display_width;
		}
		else
		{
			row_end = bitmap_height;
		}
		
		if (bitmap_width > display_height)
		{
			col_end = display_height;
		}
		else
		{
			col_end = bitmap_width;
		}
		
		for (j = 0; j < row_end; j++)
		{
			walk_display = current_display + 6*(display_width/2) + ((display_width/2) - (j/2) - 18);
			walk_bitmap = bitmap + bitmap_width * j + 1;
			walk_bitmap2 = bitmap + bitmap_width * (j+1) + 1;
	
			for (i = 0; i < col_end; i++)
			{
				*walk_display = pensLeft[*walk_bitmap++];
				*walk_display += pensRight[*walk_bitmap2++];
				walk_display += (display_width/2);
			}
		}
		
		LMSwitchToNextLiveviewFrame();
	
		taskDelay(1);
	}
	else if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		int i;
		int j;
		int row_end, col_end;
		unsigned long * walk_display;
		unsigned char * walk_bitmap;
	
		if (current_display == gLCD_buffer1)
		{
			current_display = gLCD_buffer2;
		}
		else
		{
			current_display = gLCD_buffer1;
		}
	
		walk_display = current_display + 18;
		walk_bitmap = bitmap;
	
		if (bitmap_height > display_width)
		{
			row_end = display_width;
		}
		else
		{
			row_end = bitmap_height;
		}
		
		if (bitmap_width > display_height)
		{
			col_end = display_height;
		}
		else
		{
			col_end = bitmap_width;
		}
		
		for (j = 0; j < row_end; j++)
		{
			walk_display = current_display + (display_width - j);
			walk_bitmap = bitmap + bitmap_width * j;
	
			for (i = 0; i < col_end; i++)
			{
				*walk_display = pens823[*walk_bitmap++];
				walk_display += display_width;
			}
			
		}
		
		LMSwitchBuffer(current_display);
	
		taskDelay(2);
	}
}

#if 0
/* Update the display. */
void osd_update_display3(void)
{
	int i;
	int j;
	unsigned long * display;
	unsigned long * walk_display;
	unsigned char * walk_bitmap;

	display = (unsigned long *)LMGetNextLiveviewFrame();
	
	walk_display = display + 18;
	walk_bitmap = bitmap;
	
	for (j = 0; j < bitmap_height; j++)
	{
		for (i = 0; i < bitmap_width/2; i++)
		{
			if ((i < display_width) && ( j < display_height))
			{
				*walk_display = pensRight[*walk_bitmap++];
				*walk_display += pensLeft[*walk_bitmap++];
				walk_display += 1;
				//walk_bitmap += 2;
			}
			else
			{
				walk_display += 1;
				walk_bitmap += 2;
			}
		}
		walk_display = display + 18 + display_width * j;
		walk_bitmap = bitmap + bitmap_width * j;
	}
	
	LMSwitchToNextLiveviewFrame();
}
#endif

/* check if a key is pressed. The keycode is the standard PC keyboard code, as */
/* defined in osdepend.h. Return 0 if the key is not pressed, nonzero otherwise. */
int osd_key_pressed(int keycode)
{
	int retval = 0;
	int buttonState = 0;
	
	if (camera_type == kTypeMinolta1)
	{
		switch (keycode)
		{
			case OSD_KEY_1:
			{
				if (kMinoltaSoftkeyLeft == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_2:
			{
				if (kMinoltaSoftkeyMid == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_3:
			{
				if (kMinoltaSoftkeyRight == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_LEFT:
			{
				if (kMinoltaUpArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_DOWN:
			{
				if (kMinoltaLeftArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_UP:
			{
				if (kMinoltaRightArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_RIGHT:
			{
				if (kMinoltaDownArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_TAB:
			{
				if (kMinoltaMenuButton == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}
	else if ((camera_type == kTypeHP1) || (camera_type == kTypeKodak2))
	{
		switch (keycode)
		{
			case OSD_KEY_1:
			{
				if (kDigitaSoftKey1 == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_2:
			{
				if (kDigitaSoftKey2 == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_3:
			{
				if (kDigitaSoftKey3 == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_LEFT:
			{
				if (kDigitaUpArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_DOWN:
			{
				if (kDigitaLeftArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_UP:
			{
				if (kDigitaRightArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_RIGHT:
			{
				if (kDigitaDownArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_TAB:
			{
				if (kDigitaMenu == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}
	else if (camera_type == kTypeKodak1)
	{
		switch (keycode)
		{
			case OSD_KEY_1:
			{
				if (kSoftkeyLeft == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_2:
			{
				if (kSoftkeyMid == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_3:
			{
				if (kSoftkeyRight == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_LEFT:
			{
				if (kUpArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_DOWN:
			{
				if (kLeftArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_UP:
			{
				if (kRightArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_RIGHT:
			{
				if (kDownArrow == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			case OSD_KEY_TAB:
			{
				if (kMenuButton == lastButtonID)
				{
					buttonState = lastButtonState;
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}
	
	if (buttonState)
	{
		retval = 1;
	}

	return retval;
}

/* wait for a key press and return the keycode */
int osd_read_key(void)
{
	int return_val = 0;

	while (TRUE)
	{
		if (osd_key_pressed(OSD_KEY_1))
			return_val = OSD_KEY_1;
		else if (osd_key_pressed(OSD_KEY_2))
			return_val = OSD_KEY_2;
		else if (osd_key_pressed(OSD_KEY_3))
			return_val = OSD_KEY_3;
		else if (osd_key_pressed(OSD_KEY_UP))
			return_val = OSD_KEY_UP;
		else if (osd_key_pressed(OSD_KEY_DOWN))
			return_val = OSD_KEY_DOWN;
		else if (osd_key_pressed(OSD_KEY_RIGHT))
			return_val = OSD_KEY_RIGHT;
		else if (osd_key_pressed(OSD_KEY_LEFT))
			return_val = OSD_KEY_LEFT;
		else if (osd_key_pressed(OSD_KEY_TAB))
			return_val = OSD_KEY_TAB;

		taskDelay(20);

		if (return_val)
		{
			lastButtonState = 0;
			lastButtonID = 0;
			return return_val;
		}
	}
}

void osd_poll_joystick(void)
{
}

void osd_update_audio(void)
{
}

void osd_play_sample(int channel,unsigned char *data,int len,int freq,int volume,int loop)
{
}

void osd_play_streamed_sample(int channel,unsigned char *data,int len,int freq,int volume)
{
}

void osd_adjust_sample(int channel,int freq,int volume)
{
}

void osd_stop_sample(int channel)
{
}
