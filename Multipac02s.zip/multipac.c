/***************************************************************************

  PacMan arcade machine emulator

  Usage:

  multipac [name of the game to run] [options]

  for example

  multipac mspacman    will run Ms Pac Man

  options:

  Games currently supported:
  - Pac Man
  - Ms Pac Man (bootleg version only)
  - Crush Roller (wrong colors)
  - various Pac Man variations, for example:
    - Pac Man modification (official update by Midway, harder)
    - Namco Pac Man (Pac Man with Namco copyright and different ghost names)
    - Pac Man 4x (Pac Man with speed hack)
    - Puck Man (Pac Man with different maze)
    - Hangly Man (another modified maze)
  You can run any Pac Man clone, even if it isn't directly supported. For
  example if you have six roms called foo.5e, foo.5f, foo.6e ... foo.6j,
  just create a directory named "foo", put the roms into it, and launch
  the emulator with "pacman foo".


  Z80 engine by Marat Fayzulin and Marcel de Kogel
  Emulator framework built by Allard van der Bas (avdbas@wi.leidenuniv.nl)
                          and Nicola Salmoria (MC6489@mclink.it)
  Very special thanks to Sergio Munoz for the precious information about
  the sound hardware.
  Video mode created using Tweak 1.6b by Robert Schmidt, who also wrote
  TwkUser.c.
  Thanks to Gary Walton for his help in making the Crush Roller colors better.
  Allegro library by Shawn Hargreaves, 1994/96
  SEAL Synthetic Audio Library API Interface Copyright (C) 1995, 1996
  Carlos Hasan. All Rights Reserved.


  If you find out something useful, don't hesitate to submit it to :
  The arcade emultion programming repository.

  So it will be available to everyone at :
  http://valhalla.ph.tn.tudelft.nl/emul8

  Send it by email to :
  avdbas@wi.leidenuniv.nl


  Known issues:
  - Sound is not perfect yet (music is ok, other sounds arent't). But it's a
    start.

  - Blinky and Pinky seem to be shifted one pixel to the right. This is really
    annoying, but I can't seem to be able to understand why. Maybe there is an
	additional "sprite offset" register somewhere? Or did the original just
	behave this way?
	Note that we can't fix it by just moving sprites 0 and 1 one pixel to the
	left, because when Pac Man eats a power pill the sprites order is changed
	so that Pac Man is drawn over the ghosts. It becomes sprite 0, and Blinky
	becomes sprite 4.

  - The palette of Crush Roller is hopelessly wrong. I played the game a
    couple of times some 15 years ago... can't remember anything.

***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "machine.h"
#include "osdepend.h"

#define DEFAULT_NAME "namcopac"

void entry(void)
{
	osd_setup_application();

	if(!init_machine(DEFAULT_NAME))
	{
		extern int speedcheat;


		printf("\nPLEASE DO NOT DISTRIBUTE THE SOURCE FILES OR THE EXECUTABLE WITH ROM IMAGES.\n"
			   "DOING SO WILL HARM FURTHER EMULATOR DEVELOPMENT AND WILL CONSIDERABLY ANNOY\n"
			   "THE RIGHTFUL COPYRIGHT HOLDERS OF THOSE ROM IMAGES AND CAN RESULT IN LEGAL\n"
			   "ACTION UNDERTAKEN BY EARLIER MENTIONED COPYRIGHT HOLDERS.\n"
			   "\n\n"
			   "Quick keys : 3       Insert coin\n"
			   "             1       Start 1 player game\n"
			   "             2       Start 2 player game\n"
			   "             Arrows  Move around\n"
			   "             F1      Skip level\n"
			   "             F2      Test mode\n"
			   "             Tab     Change dip switch settings\n");
		if (speedcheat)
			printf("             CTRL    Speed up cheat\n");
		printf("             P       Pause\n"
			   "             F12     Save a screen snapshot\n"
			   "             ESC     Exit emulator\n"
			   "\n\n");

		if (osd_init() == 0)
		{
			if (run_machine(DEFAULT_NAME))
				printf("Unable to start emulation\n");

		}
		else printf("Unable to initialize system\n");
	}
	else printf("Unable to initialize machine emulation\n");

	osd_exit();
	exit(0);
}
