1. How to install Multipac for Digita:

Use on a Kodak DC220, DC260, DC265 or Minolta Dimage 1500 EX or HP C500.

Put the MULTIPAC.CAM file in the system folder of the compact flash.

Put the pacman roms in a Roms Folder in the System Folder. You must unzip the roms and put them in a folder named namcopac. The roms must be named:

namcopac.5e
namcopac.5f
namcopac.6e
namcopac.6f
namcopac.6h
namcopac.6j

Some people have reported problems using the USB mounting software to put the Roms Folder inside the System Folder. You can use a card reader or laptop with a PCMCIA slot to mount the card and put the Roms Folder on the compact flash card directly or you can just put them in the System Folder with this current version. Some people have reported sucess by dragging the completed Roms Folder to the System Folder instead of creating one there. Others have reported success using a script to make a Roms Folder.

This version only supports pacman.

2. How to operate Multipac for Digita inside the camera:

Launch the MULTIPAC.CAM alternate application from the applications menu in review mode menu in the Digita UI. It's all the way to the right so you have to scroll right to see this menu.

You can also rename the MULTIPAC.CAM application DEFAULT.CAM and it will launch when the camera is powered on and this flash card is inserted.

The game should start.

Multipac Keys:
Up,Down,Left,Right:  Up, Down, Left, Right
Menu:                menu <tab>
Left Softkey:        player 1 <1>
Middle Softkey:      player 2 <1>
Right Softkey:       insert coin <3>
Power:               turns off power to the camera 
                     (CPU is very busy while game is running so
                      response may be slow, DC290 power off is still broken)

James Surine,
xevious@holonet.net