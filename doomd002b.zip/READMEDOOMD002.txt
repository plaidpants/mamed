Doom for Digita
by James Surine
xevious@holonet.net

This version of Doom runs on Digita based cameras. It is based on the Doom source code released for non-profit GPL use by John Carmack December 1997. The released source code originally only ran under Linux but many people have ported the code to many different plateforms and added many new features. I have started with the original release.

It runs the Standard Doom WAD files but I have not enabled an interface to select user WAD files yet. Just put your favorite comercial or shareware Doom WAD file in the root directory of your compact flash card and the DOOMD.CAM application in the system folder and you are ready to play. I've included the shareware Doom WAD file for your convience because the shareware version of DOOM freely distributable. I've also include all the readme files from the shareware version. Do not distribute this version of DOOM with any comercial WAD files.

Currently this runs only on the Kodak DC290. I will add support for other cameras as I have time but it should run relatively well on all the Digita based cameras. Also sound is not yet supported. You need at least version 1.0.4 of the DC290 camera firmware. You can download it from Kodak's web site if you need to.

http://www.kodak.com/global/en/service/software/dc290/navigation.shtml

I have mapped all the camera buttons to various game keys. Some buttons map to multiple keys being pressed at the same time. Hopefully everyone likes my button assignment.

Camera directional: Arrow keys
SK1: Cycles through keys 1,2,3,4,5,6,7
SK2: Shift key
SK3: Tab key
Overlay: Equals key, 'y' key, Enter key
Menu: ESC key
T: Space Bar
W: Control Key
Record: Minus key
Power: Powers off the camera
Shutter: F1
Mode Switch: F11

Here is what the keys do in the game if you are not familiar with Doom.

Arrow keys: navigate menus and move in game
1,2,3,4,5,6,7: selects weapon in game
Shift key: Run in game
Tab: Map in game
Equal key: Zoom in map and adjust display size
'y' key: used to answer yes, use ESC key to say no
Enter key: select menu item
ESC key: cancel menu operation
Space Bar: open doors and activate switches in game
Control Key: fire weapon
Minus Key: Zoom in map and adjust display size
F1: takes a screen shot, saved in root as PCX file
F11: adjust gamma setting

I AM NOT RESPONSIBLE FOR YOUR BROKEN CAMERA if you play with it too roughly, be careful with your buttons.