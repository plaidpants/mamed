#include "osd_depend.h"

#include "doomdef.h"

#include "m_argv.h"
#include "d_main.h"
#include "d_player.h"

unsigned char    			altAppID;
extern int singletics;

int lastButtonID = 0;
int lastButtonState = 0;
int doomTaskID = 0;
#ifdef SOUND
int soundTaskID = 0;
#endif
int cycle = 0;
int toggle = 0;

int event_mq = 0;
int camera_type = -1;
int play_sound = 1;

char vendor[50];
char product[50];

extern void *DigitaSoundTask(void *dummy);

extern int consoleplayer;
extern player_t players[];
unsigned char * cheat_god_seq_clear = "iddqd\0";
unsigned char * cheat_ammo_seq_clear = "idkfa\0";

void detect_camera_type(void)
{
	short					err = 0;
	TPARMNameTypeValue		data;

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
	else if (strcmp( vendor, strHP2VendorName ) == 0)
	{
		if (strcmp( product, strHPC615ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		if (strcmp( product, strHPC618ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strHPC912ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
	}
	else if (strcmp( vendor, strPENTAXVendorName ) == 0)
	{
		if (strcmp( product, strPENTAXEI200ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strPENTAXEI2000ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
	}
	else
	{
		// Unknown
		camera_type = -1;
	}
}

void EventTask(void)
{
	TEMEventRecordPtr	digita_event;
	short result;
	int buttomMsg;
	int i;
	
	while(1)
	{
		if((result = EMGetEvent( altAppID, &digita_event )) == 0)
		{
			if (digita_event->fEvClass == kButtonClassEvent)
			{
				if ((camera_type == kTypeKodak2) || (camera_type == kTypeHP2))
				{
			    	switch(digita_event->fButtonIndex)
			    	{
			    		case kDigitaUpArrow:
							lastButtonID = KEY_UPARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaLeftArrow:
							lastButtonID = KEY_LEFTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaRightArrow:
							lastButtonID = KEY_RIGHTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaDownArrow:
							lastButtonID = KEY_DOWNARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaShutter1:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_god_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							break;
						case kDigitaSoftKey1:
					    	if (digita_event->fPosition)
					    	{
					    		do 
					    		{
					    			cycle = (cycle+1)%7;
					    			
					    			if (players[consoleplayer].weaponowned[cycle])
					    				break;
					    		} while (1);
					    	
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keydown;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					taskDelay(10); // wait for doom to see the keypress
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keyup;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);			 					
		 					}
							break;
							
						case kDigitaSoftKey2:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_ammo_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							else
							{
								lastButtonID = KEY_RSHIFT;
						    	if (digita_event->fPosition)
						    	{
						    		toggle = 1 - toggle;
							    	if (toggle)
										lastButtonState = ev_keydown;
									else
										lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
				 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
				 				}
				 			}
							break;
						case kDigitaSoftKey3:
							lastButtonID = KEY_TAB;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaOverlay:
						case kDigitaLCDOnOff:
							lastButtonID = KEY_EQUALS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = 'y';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = KEY_ENTER;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaMenu:
							lastButtonID = KEY_ESCAPE;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaZoomIn:
							lastButtonID = ' ';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaZoomOut:
							lastButtonID = KEY_RCTRL;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaRecord:
							lastButtonID = KEY_MINUS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
	
						case kDigitaPowerOnOff:
							taskSuspend(doomTaskID);
							SUPowerDown(0);
							
							// Wait for power off
							while(1)
								taskDelay(10);
							break;
	
						case kDigitaShutter2:
							lastButtonID = KEY_F1;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
							
						case kDigitaReviewMode:
						case kDigitaCaptureMode:
						case kDigitaPlayMode:
						case kDigitaHostMode:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									G_ExitLevel();
								}
							}
							else
							{
						    	if (digita_event->fPosition)
						    	{
									lastButtonID = KEY_F11;
									lastButtonState = ev_keydown;
									buttomMsg = lastButtonID | (lastButtonState << 8);
									mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
									taskDelay(5);
									lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
			 						mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					}
			 				}
							break;
	
	//					case kDigitaLCDStatus1:
	//					case kDigitaLCDStatus2:
	//					case kDigitaSpare1:
	//					case kDigitaSpare2:
	//					case kDigitaShutter2:
						default:
							break;
			    	}
				}
				else if (camera_type == kTypeHP1)
				{
			    	switch(digita_event->fButtonIndex)
			    	{
			    		case kDigitaUpArrow:
							lastButtonID = KEY_UPARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaLeftArrow:
							lastButtonID = KEY_LEFTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaRightArrow:
							lastButtonID = KEY_RIGHTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaDownArrow:
							lastButtonID = KEY_DOWNARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaShutter1:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_god_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							break;
						case kDigitaSoftKey1:
					    	if (digita_event->fPosition)
					    	{
					    		do 
					    		{
					    			cycle = (cycle+1)%7;
					    			
					    			if (players[consoleplayer].weaponowned[cycle])
					    				break;
					    		} while (1);
					    	
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keydown;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					taskDelay(10); // wait for doom to see the keypress
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keyup;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);			 					
		 					}
							break;
						case kDigitaSoftKey2:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_ammo_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							else
							{
								lastButtonID = KEY_RSHIFT;
						    	if (digita_event->fPosition)
						    	{
						    		toggle = 1 - toggle;
							    	if (toggle)
										lastButtonState = ev_keydown;
									else
										lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
				 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
				 				}
				 			}
							break;
						case kDigitaSoftKey3:
							lastButtonID = KEY_TAB;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaOverlay:
							lastButtonID = KEY_EQUALS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = 'y';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = KEY_ENTER;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaMenu:
							lastButtonID = KEY_ESCAPE;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaZoomIn:
							lastButtonID = ' ';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaZoomOut:
							lastButtonID = KEY_RCTRL;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDigitaLCDOnOff:
							lastButtonID = KEY_MINUS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
	
						case kDigitaPowerOnOff:
							taskSuspend(doomTaskID);
							pmPowerDown(1);
							
							// Wait for power off
							while(1)
								taskDelay(10);
							break;
	
						case kDigitaShutter2:
							lastButtonID = KEY_F1;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
							
						case kDigitaReviewMode:
						case kDigitaCaptureMode:
						case kDigitaPlayMode:
						case kDigitaHostMode:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									G_ExitLevel();
								}
							}
							else
							{
						    	if (digita_event->fPosition)
						    	{
									lastButtonID = KEY_F11;
									lastButtonState = ev_keydown;
									buttomMsg = lastButtonID | (lastButtonState << 8);
									mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
									taskDelay(5);
									lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
			 						mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					}
			 				}
							break;
	
	//					case kDigitaLCDStatus1:
	//					case kDigitaLCDStatus2:
	//					case kDigitaSpare1:
	//					case kDigitaSpare2:
	//					case kDigitaShutter2:
						default:
							break;
			    	}
				}
				else if (camera_type == kTypeKodak1)
				{
			    	switch(digita_event->fButtonIndex)
			    	{
			    		case kUpArrow:
							lastButtonID = KEY_UPARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kLeftArrow:
							lastButtonID = KEY_LEFTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kRightArrow:
							lastButtonID = KEY_RIGHTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kDownArrow:
							lastButtonID = KEY_DOWNARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kShutter1:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_god_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							break;
						case kSoftkeyLeft:
					    	if (digita_event->fPosition)
					    	{
					    		do 
					    		{
					    			cycle = (cycle+1)%7;
					    			
					    			if (players[consoleplayer].weaponowned[cycle])
					    				break;
					    		} while (1);
					    	
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keydown;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					taskDelay(10); // wait for doom to see the keypress
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keyup;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);			 					
		 					}
							break;
						case kSoftkeyMid:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_ammo_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							else
							{
								lastButtonID = KEY_RSHIFT;
						    	if (digita_event->fPosition)
						    	{
						    		toggle = 1 - toggle;
							    	if (toggle)
										lastButtonState = ev_keydown;
									else
										lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
				 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
				 				}
				 			}
							break;
						case kSoftkeyRight:
							lastButtonID = KEY_TAB;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kOverlayButton:
							lastButtonID = KEY_EQUALS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = 'y';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = KEY_ENTER;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMenuButton:
							lastButtonID = KEY_ESCAPE;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kZoomIn:
							lastButtonID = ' ';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kZoomOut:
							lastButtonID = KEY_RCTRL;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kRecordButton:
							lastButtonID = KEY_MINUS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
	
						case kPowerEvent:
							taskSuspend(doomTaskID);
							PMPowerDown( 0 );
							
							// Wait for power off
							while(1)
								taskDelay(10);
							break;
	
						case kShutter2:
							lastButtonID = KEY_F1;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
							
						case kMode0Button:
						case kMode1Button:
						case kMode2Button:
						case kMode3Button:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									G_ExitLevel();
								}
							}
							else
							{
						    	if (digita_event->fPosition)
						    	{
									lastButtonID = KEY_F11;
									lastButtonState = ev_keydown;
									buttomMsg = lastButtonID | (lastButtonState << 8);
									mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
									taskDelay(5);
									lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
			 						mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					}
			 				}
							break;
	
	//					case kDigitaLCDStatus1:
	//					case kDigitaLCDStatus2:
	//					case kDigitaSpare1:
	//					case kDigitaSpare2:
	//					case kDigitaShutter2:
						default:
							break;
			    	}
				}
				else if (camera_type == kTypeMinolta1)
				{
			    	switch(digita_event->fButtonIndex)
			    	{
			    		case kMinoltaUpArrow:
							lastButtonID = KEY_UPARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaLeftArrow:
							lastButtonID = KEY_LEFTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaRightArrow:
							lastButtonID = KEY_RIGHTARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaDownArrow:
							lastButtonID = KEY_DOWNARROW;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaShutter1:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_god_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_god_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							break;
						case kMinoltaSoftkeyLeft:
					    	if (digita_event->fPosition)
					    	{
					    		do 
					    		{
					    			cycle = (cycle+1)%7;
					    			
					    			if (players[consoleplayer].weaponowned[cycle])
					    				break;
					    		} while (1);
					    	
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keydown;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					taskDelay(10); // wait for doom to see the keypress
								lastButtonID = '1' + cycle;
								lastButtonState = ev_keyup;
								buttomMsg = lastButtonID | (lastButtonState << 8);
			 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);			 					
		 					}
							break;
						case kMinoltaSoftkeyMid:
							lastButtonID = KEY_RSHIFT;
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									i = 0;
									while(cheat_ammo_seq_clear[i] != 0x00)
									{
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keydown;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
										lastButtonID = cheat_ammo_seq_clear[i];
										lastButtonState = ev_keyup;
										buttomMsg = lastButtonID | (lastButtonState << 8);
					 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					 					taskDelay(5); // wait for doom to see the keypress
					 					i++;
									}
								}
							}
							else
							{
								lastButtonID = KEY_RSHIFT;
						    	if (digita_event->fPosition)
						    	{
						    		toggle = 1 - toggle;
							    	if (toggle)
										lastButtonState = ev_keydown;
									else
										lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
				 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
				 				}
				 			}
							break;
						case kMinoltaSoftkeyRight:
							lastButtonID = KEY_TAB;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaOverlayButton:
							lastButtonID = KEY_EQUALS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = 'y';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = KEY_ENTER;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaMenuButton:
							lastButtonID = KEY_ESCAPE;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
						case kMinoltaStatusButton:
							lastButtonID = ' ';
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							lastButtonID = KEY_RCTRL;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
#if 0
						case xxx:
							lastButtonID = KEY_MINUS;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
#endif	
						case kMinoltaPowerEvent:
					    	if (digita_event->fPosition == 0)
					    	{
								taskSuspend(doomTaskID);
								PMPowerDown( 0 );
								
								// Wait for power off
								while(1)
									taskDelay(10);
							}
							break;
	
						case kMinoltaShutter2:
							lastButtonID = KEY_F1;
					    	if (digita_event->fPosition)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							break;
							
						case kMinoltaMode0Button:
						case kMinoltaMode1Button:
						case kMinoltaMode2Button:
						case kMinoltaMode3Button:
							if (lastButtonID == KEY_MINUS)
							{
								lastButtonID = 0;
						    	if (digita_event->fPosition)
						    	{
									G_ExitLevel();
								}
							}
							else
							{
						    	if (digita_event->fPosition)
						    	{
									lastButtonID = KEY_F11;
									lastButtonState = ev_keydown;
									buttomMsg = lastButtonID | (lastButtonState << 8);
									mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
									taskDelay(5);
									lastButtonState = ev_keyup;
									buttomMsg = lastButtonID | (lastButtonState << 8);
			 						mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
			 					}
			 				}
							break;
	
	//					case kDigitaLCDStatus1:
	//					case kDigitaLCDStatus2:
	//					case kDigitaSpare1:
	//					case kDigitaSpare2:
	//					case kDigitaShutter2:
						default:
							break;
			    	}
				}
	 		}
	 		result = EMReleaseEventRecord(digita_event);
	 	}
	}
}

void entry(void)
{
	short result;
	struct mq_attr mqa;
	int mode;

	detect_camera_type();

	if (camera_type == kTypeKodak2)
	{
		// initialized the MPU and wait for it to finish initializing
		MPUInit();
		while( !smMconStat )
			taskDelay(20);
	
		CMInit();
		HYInit();
	
		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
	}
	else if (camera_type == kTypeKodak1)
	{
		// initialized the MPU and wait for it to finish initializing
		MPUInit();
		while( !smMconStat )
			taskDelay(20);
	
		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
	}
	else if ((camera_type == kTypeHP1) || (camera_type == kTypeHP2))
	{
	    GMInitGraf(NULL);
	    GMInitFonts();
	    LMAllocateBuffers();
	    LMSwitchNormalMode();
	    LMSwitchLiveviewMode();
	    LMEnableLCDController();
	}
	else if (camera_type == kTypeMinolta1)
	{
		GMInitGraf(NULL);
	    GMInitFonts();
		MPUSendLens(1);
		taskDelay(30);
	}

	result = AMGetSelfAppID(&altAppID);
	result = EMOpen(altAppID, 0);

//	taskPrioritySet(taskIdSelf(), 3);

    myargc = 0; 
    myargv = 0; 
    
	singletics = 1;

    mqa.mq_flags = O_RDWR | O_CREAT;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	event_mq = mq_open("DOOMEVENTS",O_WRONLY | O_CREAT, mode, &mqa);
#ifdef SOUND
	soundTaskID = taskSpawn("DOOMSOUND", 3, 0, 1024*2, (void*)DigitaSoundTask, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0);
#endif
	doomTaskID = taskSpawn("DOOMD", 30, 0, 1024*16, (void*)D_DoomMain, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	
	EventTask();
}


int access(const char * fname, int permissions)
{
	int fd;
	
	fd = (int)fopen(fname,"r");
	
	if (fd)
	{
		fclose((void*)fd);
		return 0;
	}
	
	return -1;
}

#if 1
int strncasecmp(const char *inString1, const char *inString2, unsigned int length)
{
    char c1, c2;
    int walk;
    for (walk = 0; walk < length; walk++)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
    
    return 0;
}

int strcasecmp(const char *inString1, const char *inString2)
{
    char c1, c2;
    while (1)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
}
#endif

void LogText( char *message )
{
	int log;
	
	log = fopen( "/B/Log.txt", "a" );
	if (log)
	{
		fprintf( log, "%s\r\n", message );
		fclose( log );
	}
}

void __eabi(void)
{
	printf("__eabi\n");
	taskSuspend(0);
}

