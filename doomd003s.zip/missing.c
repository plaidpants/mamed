/* The DC290 is missing some GNU generated functions so I will force
   them to be included here. */

extern void __eabi(void);
extern void __divdi3(void);
extern void __divsi3(void);
extern void __modsi3(void);
extern void __muldi3(void);
extern void __udivsi3(void);
extern void powf(void);

 
void * missing[] = {
__eabi,
__divdi3,
__divsi3,
__modsi3,
__muldi3,
__udivsi3,
powf
};