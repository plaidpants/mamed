#!/bin/sh
if [ ! -e ../../../config/config.h ]
then 
	cp ../../../config/config.beos ../../../config/config.h
fi

