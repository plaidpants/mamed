/*
 #Id:#
 */
#ifndef BEOS_PRIORITY_H
#define BEOS_PRIORITY_H

#include "thread.h"

#endif // BEOS_PRIORITY_H

