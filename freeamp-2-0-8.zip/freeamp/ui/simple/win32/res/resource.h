//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by simple.rc
//
#define IDS_NAME                        1
#define IDA_PLAYLISTEDITOR              1
#define IDS_WEBLINK                     2
#define IDA_PLAYER                      2
#define IDM_PLAYER                      101
#define IDI_EXE_ICON                    101
#define IDM_PLAYLISTEDITOR              102
#define IDD_PLAYER                      103
#define IDD_ABOUT                       104
#define IDB_ABOUT8                      105
#define IDD_PLAYLISTEDITOR              107
#define IDM_TRAY                        192
#define IDD_PREF1                       193
#define IDD_PREF3                       221
#define IDD_PREF2                       223
#define IDD_PREF4                       224
#define IDC_PLAY                        1000
#define IDC_STOP                        1001
#define IDC_NEXTSONG                    1002
#define IDC_LASTSONG                    1003
#define IDC_PAUSE                       1004
#define IDC_SLIDER                      1005
#define IDC_UI                          1005
#define IDC_TOTAL_TIME                  1006
#define IDC_PMO                         1006
#define IDC_CURRENT_TIME                1007
#define IDC_PRIORITY                    1007
#define IDC_STATUS                      1008
#define IDC_INPUT                       1008
#define IDC_WEBLINK                     1009
#define IDC_LOGOUTPUT                   1009
#define IDC_LIST                        1010
#define IDC_LOG                         1010
#define IDC_OUTPUT                      1010
#define IDC_UP                          1011
#define IDC_STREAM_INTERVAL             1011
#define IDC_DOWN                        1012
#define IDC_LOGINPUT                    1012
#define IDC_LOGDECODER                  1013
#define IDC_LOGPERFORMANCE              1014
#define IDC_PREBUFFER                   1014
#define IDC_LOGMAIN                     1015
#define IDC_TRAY                        1015
#define IDC_SAVESTREAMS                 1016
#define IDC_STREAMSAVEDIR               1017
#define IDC_STAYONTOP                   1017
#define IDC_BROWSE                      1018
#define IDC_SAVELOCATION_TEXT           1019
#define IDC_PORT                        1020
#define IDC_PROXYADDRESS_TEXT           1021
#define IDC_PORT_TEXT                   1022
#define IDC_USEPROXY                    1023
#define IDC_PROXYADDRESS                1024
#define IDC_COLON_TEXT                  1025
#define IDC_USETHISIP                   1026
#define IDC_IPADDRESS1                  1027
#define IDC_IPADDRESS_TEXT              1028
#define IDC_PERIOD1                     1030
#define IDC_PERIOD2                     1031
#define IDC_IPADDRESS2                  1032
#define IDC_IPADDRESS3                  1033
#define IDC_IPADDRESS4                  1034
#define IDC_PERIOD3                     1035
#define IDC_GOTOFREEAMP                 1036
#define IDC_GOTOEMUSIC                  1037
#define IDC_FIND                        20156
#define IDC_RECENTF1                    31000
#define IDC_SELECTALL                   32901
#define IDC_DELETE                      32904
#define IDC_EXIT                        40024
#define IDC_OPEN                        40025
#define IDC_ABOUT                       40027
#define IDC_EDIT_CURRENTPLAYLIST        40031
#define IDC_EDIT_PLAYLISTFILE           40032
#define IDC_SAVE                        40033
#define IDC_NEW                         40034
#define IDC_CLOSE                       40035
#define IDC_SAVEAS                      40036
#define IDC_REDO                        40039
#define IDC_EDIT_PREFS                  40040
#define IDC_COPY                        57634
#define IDC_CUT                         57635
#define IDC_PASTE                       57637
#define IDC_UNDO                        57643

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40041
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
