//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by toolbar.rc
//
#define IDI_EXE_ICON                    101
#define IDM_TRAY                        102
#define IDC_ITEM                        40001
#define IDC_ABOUT                       40002
#define IDC_OPEN                        40003
#define IDC_SAVE                        40004
#define IDC_PREF                        40005
#define IDC_EXIT                        40006
#define IDC_PLAY                        40007
#define IDC_PAUSE                       40009
#define IDC_NEXTSONG                    40010
#define IDC_NEXTTRACK                   40010
#define IDC_LASTSONG                    40011
#define IDC_PREVIOUSTRACK               40011
#define IDC_STOP                        40012
#define IDC_MYMUSIC                     40013
#define IDS_URL                         65535
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        197
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
