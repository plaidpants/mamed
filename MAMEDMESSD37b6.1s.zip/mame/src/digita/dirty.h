#define MAX_GFX_HEIGHT 1600
#define DIRTY_V (MAX_GFX_HEIGHT)


typedef char dirtygrid[DIRTY_V];
#define ISDIRTY(y) (dirty_new[(y)] || dirty_old[(y)])
#define MARKDIRTY(y) dirty_new[(y)] = 1
