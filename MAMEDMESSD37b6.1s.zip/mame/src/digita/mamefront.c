// standard OS includes (vxWorks)
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>

// MAME includes
#include "osdepend.h"
#include "osd_depend.h"
#include "driver.h"

// local prototypes
#ifdef MESS
void * messfront(void *);
#else
void * mamefront(void *);
#endif

// external prototypes
extern void detect_camera_type(void);
extern void digitaEventTask(void);
extern void * mame (void * gamename);
extern unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b);
extern void (*update_screen)(struct osd_bitmap *bitmap);

#define kREPEAT_TIME 7

#ifdef DIGITA_SOUND
extern void *DigitaSoundTask(void *dummy);
#endif

#ifdef DIGITA_SERIAL
extern void serialPortEventTask(void);
#endif

extern void getEventTask(void);

// external globals
extern int					camera_type;
extern int					use_dirty;
extern struct snd_interface * sndintf;


// Globals
unsigned long 				*gLCD_buffer1 = 0;
unsigned long 				*gLCD_buffer2 = 0;
int 						gResolution = 0;
int 						gPadOrientation = 0;
int							mameTaskID = 0;
int 						soundTaskID = 0;
int 						eventTaskID = 0;
#ifdef DIGITA_SERIAL
int							serialTaskID = 0;
int							keyboard_type = 0;
#endif
int							play_sound = 0;
int							cpu_slices_per_frame_override = 0;
int 						auto_rotate = 1;
int 						saveUse_dirty = -1;

/* empty list that will be replaced with _drivers[] when we load the game modules */
extern const struct GameDriver *_drivers[];
const struct GameDriver **drivers = _drivers;

/* The "root" driver, defined so we can have &driver_##NAME in macros. */
struct GameDriver driver_0 =
{
	__FILE__,
	0,
	"",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	NOT_A_DRIVER
};

// locals Globals
static unsigned long 		*gLCD_buffer = 0;

void setup_application(void)
{
	int i;
	
	if (camera_type == kTypeMinolta1)
	{
	    GMInitGraf(NULL);
	    GMInitFonts();
	
		// allocate 2 lcd buffers
		MMNewAlignedPtr((180 * 287 * 2 * 4), 16, (char *) &gLCD_buffer);
	
		// clear the display
		gLCD_buffer1 = gLCD_buffer;
		for (i = 0;i < 180 * 287 * 2;i++)
		{
			*gLCD_buffer1++ = 0x10801080; // this is black in the YCC LCD world
		}
		
		// set the globals
		gLCD_buffer1 = gLCD_buffer;
		gLCD_buffer2 = gLCD_buffer + 180 * 287;
		
		// display the port
	    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();
	
		MPUSendLens(1);
	}
	else if (camera_type == kTypeHP1)
	{
	    GMInitGraf(NULL);
	    GMInitFonts();
	    LMAllocateBuffers();
	    LMSwitchNormalMode();
	    LMSwitchLiveviewMode();
	    LMEnableLCDController();
	}
	else if (camera_type == kTypeHP2)
	{
	    GMInitGraf(NULL);
	    GMInitFonts();
	    LMAllocateBuffers();
	    LMSwitchNormalMode();
	    LMSwitchLiveviewMode();
	    LMEnableLCDController();
	}
	else if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1))
	{
		// initialized the MPU and wait for it to finish initializing
		MPUInit();
		while( !smMconStat )
			taskDelay(20);

		// allocate 2 lcd buffers that are continuous so we can use them for interlaced
		// mode also
		MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);

		// clear the display
		gLCD_buffer1 = gLCD_buffer;
		for (i = 0;i < 288*216*2;i++)
		{
			*gLCD_buffer1++ = 0x80108010; // this is black in the YCC PPC 823 LCD world
		}
		
		// set the globals
		gLCD_buffer1 = gLCD_buffer;
		gLCD_buffer2 = gLCD_buffer + 288*216;
		
		// display the port
	    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();

		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
	}
	else if (camera_type == kTypeKodak2)
	{
		CMInit();
		HYInit();
		
		// allocate 2 lcd buffers that are continuous so we can use them for interlaced
		// mode also
		MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);

		// clear the display
		gLCD_buffer1 = gLCD_buffer;
		for (i = 0;i < 288*216*2;i++)
		{
			*gLCD_buffer1++ = 0x80108010; // this is black in the YCC PPC 823 LCD world
		}
		
		// set the globals
		gLCD_buffer1 = gLCD_buffer;
		gLCD_buffer2 = gLCD_buffer + 288*216;
		
		// display the port
	    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();

		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
	}
}

void fix_driver_table(void)
{
	struct GameDriver **walk_drivers_link;
	struct GameDriver **set_drivers_link;

	// remove gaps (zeros or unresolved references) in the game driver list,
	// cause MAME expects it that way.
	walk_drivers_link = drivers;
	set_drivers_link = drivers;
	while (*walk_drivers_link != (struct GameDriver *)0xFFEEDDCC)
	{
		while (*walk_drivers_link == 0)
			walk_drivers_link++;
		
		if (*walk_drivers_link != (struct GameDriver *)0xFFEEDDCC)
		{
			*set_drivers_link = *walk_drivers_link;
			set_drivers_link++;
			walk_drivers_link++;
		}
	}
	*set_drivers_link = 0;
}

void entry(void)
{
	fix_driver_table();
	
	detect_camera_type();

	setup_application();
	
#ifdef DIGITA_SERIAL
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
		// Start up serial port thread
		serialTaskID = taskSpawn("DIGITA_SERIAL", 8, 0, 4096, 
			serialPortEventTask, NULL, 
			0, 0, 0, 0, 0, 0, 0, 0, 0);
#endif

	eventTaskID = taskSpawn("EVENTS", 3, 0, 4096, 
		getEventTask, NULL, 
		0, 0, 0, 0, 0, 0, 0, 0, 0);
		
#ifdef DIGITA_SOUND
	// Start up streaming audio thread...
	// sound task must have highest priority
	soundTaskID = taskSpawn("SOUND", 2, 0, 4096, 
		DigitaSoundTask, NULL, 
		0, 0, 0, 0, 0, 0, 0, 0, 0);
#endif

	// start MAME thread
#ifdef MESS
	mameTaskID = taskSpawn("MESSD", 30, 0, 1024*64, 
		messfront, NULL, 
		0, 0, 0, 0, 0, 0, 0, 0, 0);
#else
	mameTaskID = taskSpawn("MAMED", 30, 0, 1024*64, 
		mamefront, NULL, 
		0, 0, 0, 0, 0, 0, 0, 0, 0);
#endif

	// this task now becomes the digita event task
	digitaEventTask();
}

int gEnable_Disabled = 0;

int Enable_Disable(char *enabled_dirpath, char *disabled_dirpath)
{
    DIR     		*b;
    struct dirent 	*c;
	int 			sel;
	int 			menu_total;
	char 			**menu_item;
	char 			**sub_menu_item;
	int 			visible;
	char			enabled_rename_buffer[200];
	char			disabled_rename_buffer[200];
		
	// clear the screen
	osd_clearbitmap(Machine->scrbitmap);

	// first is default selected
	sel = 0;

	visible = (Machine->uiheight / (3 * Machine->uifontheight / 2))/2 - 1;

	// count number of files in enabled directory
	menu_total = 0;

	chdir(enabled_dirpath);
    b = opendir(enabled_dirpath);
    if (b) 
    {
		while ((c = readdir(b)))
		{
			struct stat st;

			if( stat(c->d_name, &st) == 0 )
			{
				if( S_ISREG(st.st_mode))
				{
					menu_total++;
				}
			}	
		}
		closedir(b);
	}
	
	// count number of files in disabled directory
	chdir(disabled_dirpath);
    b = opendir(disabled_dirpath);
    if (b) 
    {
		while ((c = readdir(b)))
		{
			struct stat st;

			if( stat(c->d_name, &st) == 0 )
			{
				if( S_ISREG(st.st_mode))
				{
					menu_total++;
				}
			}	
		}
		closedir(b);
	}

	// allocate enough space
	menu_item = (char **)malloc(sizeof(char **) * (menu_total + 1));
	sub_menu_item = (char **)malloc(sizeof(char **) * (menu_total + 1));
	menu_total = 0;
	
	// add item from enabled directory
	chdir(enabled_dirpath);
    b = opendir(enabled_dirpath);
    if (b) 
    {
		while ((c = readdir(b))) 
		{
			struct stat st;
			
			if( stat(c->d_name, &st) == 0 )
			{
				if( S_ISREG(st.st_mode))
				{
					menu_item[menu_total] = malloc(strlen(c->d_name) + 1);
					strcpy(menu_item[menu_total], c->d_name);
					sub_menu_item[menu_total] = "Enabled";
					menu_total++;
				}
			}	
		}
		closedir(b);
	}

	// add item from disabled directory
	chdir(disabled_dirpath);
    b = opendir(disabled_dirpath);
    if (b)
    {
		while ((c = readdir(b))) 
		{
			struct stat st;

			if( stat(c->d_name, &st) == 0 )
			{
				if( S_ISREG(st.st_mode))
				{
					menu_item[menu_total] = malloc(strlen(c->d_name) + 1);
					strcpy(menu_item[menu_total], c->d_name);
					sub_menu_item[menu_total] = "Disabled";
					menu_total++;
				}
			}	
		}
		closedir(b);
	}

	// end of the list
	menu_item[menu_total] = 0;
	sub_menu_item[menu_total] = 0;

	if (menu_total != 0) // oops, nothing here, bail.
	{
		while (TRUE)
		{
			ui_displaymenu(Machine->scrbitmap, (const char **)menu_item, sub_menu_item,0,sel,0);
			update_screen(Machine->scrbitmap);

			if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
				sel = sel + 1;

			if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
				sel = sel - 1;
				
			if (input_ui_pressed_repeat(IPT_UI_RIGHT,kREPEAT_TIME))
				sel = sel + visible - 1;

			if (input_ui_pressed_repeat(IPT_UI_LEFT,kREPEAT_TIME))
				sel = sel - visible + 1;

			if (sel > menu_total - 1)
			{
				sel = 0;
			}
			else if (sel < 0)
			{
				sel = menu_total - 1;
			}
			
			if (input_ui_pressed(IPT_UI_SELECT))
			{
				if (stricmp(sub_menu_item[sel], "Disabled") == 0)
				{
					strcpy(disabled_rename_buffer, disabled_dirpath);
					strcat(disabled_rename_buffer, menu_item[sel]);
					strcpy(enabled_rename_buffer, enabled_dirpath);
					strcat(enabled_rename_buffer, menu_item[sel]);
					if (rename(disabled_rename_buffer, enabled_rename_buffer) == 0)
						sub_menu_item[sel] = "Enabled";
				}
				else
				{
					strcpy(enabled_rename_buffer, enabled_dirpath);
					strcat(enabled_rename_buffer, menu_item[sel]);
					strcpy(disabled_rename_buffer, disabled_dirpath);
					strcat(disabled_rename_buffer, menu_item[sel]);
					if (rename(enabled_rename_buffer, disabled_rename_buffer) == 0)
						sub_menu_item[sel] = "Disabled";
				}
			}
			
			if (input_ui_pressed(IPT_UI_CANCEL))
			{
				sel = -1;
				break;
			}

			if (input_ui_pressed(IPT_UI_ON_SCREEN_DISPLAY) || input_ui_pressed(IPT_START1))
			{
				sel = -2;
				gEnable_Disabled = (gEnable_Disabled + 1) % 3;
				break;
			}

			// clear the screen
			osd_clearbitmap(Machine->scrbitmap);
		}
	}
	else
	{
		sel = -1;
		gEnable_Disabled = (gEnable_Disabled + 1) % 3;
	}
	
	// free all the strings
	menu_total = 0;
	while(menu_item[menu_total])
	{
		free(menu_item[menu_total]);
		menu_total++;
	}

	// free the table
	free(menu_item);

	// clear the screen
	osd_clearbitmap(Machine->scrbitmap);
	
	return sel;
}

#define CPU_TYPE(driver_index, index) (drivers[driver_index]->drv->cpu[index].cpu_type & ~CPU_FLAGS_MASK)
#define CPU_AUDIO(driver_index, index) (drivers[driver_index]->drv->sound[index].sound_type & CPU_AUDIO_CPU)

// note: this doesn't completely verify the game will actually run, but it's a start
int Flight_Check(int driver_index)
{
	int totalcpu = 0;
	int totalsound = 0;
	
	while (totalcpu < MAX_CPU)
	{
		int cpu_type = CPU_TYPE(driver_index, totalcpu);
		
		if(cpu_type  == CPU_DUMMY ) break; // end of list
		
		if (cpuintf[cpu_type].execute == 0)
			return -1; // this cpu is not loaded, error
			
		totalcpu++;
	}
	
	while (totalsound < MAX_SOUND)
	{
		int sound_type = CPU_AUDIO(driver_index, totalsound);
		
		if(sound_type  == 0 ) break; // end of list

		if (sndintf[sound_type].start == 0)
			return -1; // this sound driver is not loaded, error

		totalsound++;
	}

	return 0; // good to go
}

int sort_func(const char **a, const char **b)
{
	return stricmp(*a, *b);
}

#include "driver.h"
#include "artwork.h"
#include "png.h"
struct artwork_info *snap_overlay = NULL;

// Taken from artwork.c and modified to load snaps
/* static */ int snap_read_bitmap(const char *file_name, struct osd_bitmap **bitmap, struct osd_bitmap **alpha, struct png_info *p)
{
	UINT8 *tmp;
	int x, y, pen;
	void *fp;
	int file_name_len;
	char file_name2[256];

	/* check for .png */
	strcpy(file_name2, file_name);
	file_name_len = strlen(file_name2);
	if ((file_name_len < 4) || stricmp(&file_name2[file_name_len - 4], ".png"))
	{
		strcat(file_name2, ".png");
	}

	if (!(fp = osd_fopen(Machine->gamedrv->name, file_name2, OSD_FILETYPE_SCREENSHOT, 0)))
	{
		printf("Unable to open PNG %s\n", file_name);
		return 0;
	}

	if (!png_read_file(fp, p))
	{
		osd_fclose (fp);
		return 0;
	}
	osd_fclose (fp);

	if (p->bit_depth > 8)
	{
		printf("Unsupported bit depth %i (8 bit max.)\n", p->bit_depth);
		return 0;
	}

	if (p->interlace_method != 0)
	{
		printf("Interlace unsupported\n");
		return 0;
	}

	if (Machine->scrbitmap->depth == 8 && p->color_type != 3)
	{
		printf("Use 8bit artwork for 8bpp modes. Artwork disabled.\n");
		return 0;
	}

	switch (p->color_type)
	{
	case 3:
		/* Convert to 8 bit */
		png_expand_buffer_8bit (p);
		png_delete_unused_colors (p);

		if ((*bitmap = bitmap_alloc(p->width,p->height)) == 0)
		{
			printf("Unable to allocate memory for artwork\n");
			return 0;
		}

		tmp = p->image;
		if ((*bitmap)->depth == 8)
		{
			for (y=0; y<p->height; y++)
				for (x=0; x<p->width; x++)
				{
					plot_pixel(*bitmap, x, y, *tmp++);
				}
		}
		else
		{
			/* convert to 15bit */
			if (p->num_trans > 0)
				if ((*alpha = bitmap_alloc(p->width,p->height)) == 0)
				{
					printf("Unable to allocate memory for artwork\n");
					return 0;
				}

			for (y=0; y<p->height; y++)
				for (x=0; x<p->width; x++)
				{
					pen = ((p->palette[*tmp * 3] & 0xf8) << 7) | ((p->palette[*tmp * 3 + 1] & 0xf8) << 2) | (p->palette[*tmp * 3 + 2] >> 3);
					plot_pixel(*bitmap, x, y, pen);

					if (p->num_trans > 0)
					{
						if (*tmp < p->num_trans)
							plot_pixel(*alpha, x, y, p->trans[*tmp]);
						else
							plot_pixel(*alpha, x, y, 255);
					}
					tmp++;
				}

			free (p->palette);

			/* create 15 bit palette */
			if ((p->palette = create_15bit_palette()) == 0)
			{
				printf("Unable to allocate memory for artwork\n");
				return 0;
			}
			p->num_palette = 32768;
		}
		break;

	case 6:
		if ((*alpha = bitmap_alloc(p->width,p->height)) == 0)
		{
			printf("Unable to allocate memory for artwork\n");
			return 0;
		}

	case 2:
		if ((*bitmap = bitmap_alloc(p->width,p->height)) == 0)
		{
			printf("Unable to allocate memory for artwork\n");
			return 0;
		}

		/* create 15 bit palette */
		if ((p->palette = create_15bit_palette()) == 0)
		{
			printf("Unable to allocate memory for artwork\n");
			return 0;
		}

		p->num_palette = 32768;
		p->trans = NULL;
		p->num_trans = 0;

		/* reduce true color to 15 bit */
		tmp = p->image;
		for (y=0; y<p->height; y++)
			for (x=0; x<p->width; x++)
			{
				pen = ((tmp[0] & 0xf8) << 7) | ((tmp[1] & 0xf8) << 2) | (tmp[2] >> 3);
				plot_pixel(*bitmap, x, y, pen);

				if (p->color_type == 6)
				{
					plot_pixel(*alpha, x, y, tmp[3]);
					tmp += 4;
				}
				else
					tmp += 3;
			}

		break;

	default:
		printf("Unsupported color type %i \n", p->color_type);
		return 0;
		break;
	}
	free (p->image);
	return 1;
}

// Taken from artwork.c and modified to load snaps
/* static */ void snap_load_size_common(const char *filename, unsigned int start_pen, unsigned int max_pens,
					   				 int width, int height, struct artwork_info **a, int * orig_width, int * orig_height)
{
	struct osd_bitmap *picture = 0, *alpha = 0;
	struct png_info p;
	int scalex, scaley;

	/* If the user turned artwork off, bail */
//	if (!options.use_artwork) return;

	allocate_artwork_mem(width, height, a);

	if (*a==NULL)
		return;

	(*a)->start_pen = start_pen;

	if (!snap_read_bitmap(filename, &picture, &alpha, &p))
	{
		artwork_free(a);
		return;
	}

	(*a)->num_pens_used = p.num_palette;
	(*a)->num_pens_trans = p.num_trans;
	(*a)->orig_palette = p.palette;
	(*a)->transparency = p.trans;

	/* Make sure we don't have too many colors */
	if ((*a)->num_pens_used > max_pens)
	{
		printf("Too many colors in artwork.\n");
		printf("Colors found: %d  Max Allowed: %d\n",
				      (*a)->num_pens_used,max_pens);
		artwork_free(a);
		bitmap_free(picture);
		return;
	}

	/* Scale the original picture to be the same size as the visible area */
	scalex = 0x10000 * picture->width  / width;
	scaley = 0x10000 * picture->height / height;
	if (Machine->orientation & ORIENTATION_SWAP_XY)
	{
		int tmp;
		tmp = scalex;
		scalex = scaley;
		scaley = tmp;
	}

	if (scalex < scaley)
		scalex = scaley;
	if (scaley < scalex)
		scaley = scalex;
	copyrozbitmap((*a)->orig_artwork, picture, 0, 0, scalex, 0, 0, scaley, 0, 0, TRANSPARENCY_NONE, 0, 0);

	*orig_width =  0x10000 * picture->width / scalex;
	*orig_height = 0x10000 * picture->height / scaley ;

	/* We don't need the original any more */
	bitmap_free(picture);

	if (alpha)
	{
		copyrozbitmap((*a)->alpha, alpha, 0, 0, scalex, 0, 0, scaley, 0, 0, TRANSPARENCY_NONE, 0, 0);
		bitmap_free(alpha);
	}

	/* If the game uses dynamic colors, we assume that it's safe
	   to init the palette and remap the colors now */
//	if (Machine->drv->video_attributes & VIDEO_MODIFIES_PALETTE)
//		backdrop_set_palette(*a,(*a)->orig_palette);
}

#define NUMBER_OF_MENU_COLORS 250
UINT8 dummy_palette[NUMBER_OF_MENU_COLORS][3];
UINT16 pens[NUMBER_OF_MENU_COLORS];

#ifdef MESS
int Validate_ROM(char * filename, const struct IODevice *dev)
{
	char extension[10];
	char * ext;
	
	/* find extension */
	ext = strrchr(filename, '.');
	if (ext)
	{
		ext++;
		strcpy(extension, ext);

		// delete spaces any from extension
		if (extension[0] == ' ')
		{
			extension[0] = 0;
		}
		else if (extension[1] == ' ')
		{
			extension[1] = 0;
		}
		else if (extension[2] == ' ')
		{
			extension[2] = 0;
		}

		while (dev->type != IO_END)
		{
			const char *dst = dev->file_extensions;
			/* scan supported extensions for this device */
			while (dst && *dst)
			{
				// assume first file type for zipped files
				if (stricmp("zip",extension) == 0)
				{
					return dev->type;
				}

				if (stricmp(dst,extension) == 0)
				{
                    return dev->type;
				}
				/* skip '\0' once in the list of extensions */
				dst += strlen(dst) + 1;
			}
			dev++;
		}
	}
	
	return -1;
}

int Select_ROM(char *dirpath, const struct IODevice *dev, char * rom_name)
{
    DIR     		*b;
    struct dirent 	*c;
	int 			sel;
	int 			menu_total;
	char 			**menu_item;
	int 			visible;
	int 			rom_type;
		
	// clear the screen
	osd_clearbitmap(Machine->scrbitmap);

	// first is default selected
	sel = 0;

	visible = (Machine->uiheight / (3 * Machine->uifontheight / 2))/2 - 1;

	// count number of files in rom directory
	menu_total = 0;
    b = opendir(dirpath);
    if (b) 
    {
		while ((c = readdir(b)))
		{
			if (Validate_ROM(c->d_name, dev) != -1)
			{
				menu_total++;
			}
		}
		closedir(b);
	}

	// allocate enough space
	menu_item = (char **)malloc(sizeof(char **) * (menu_total + 2));

	menu_total = 0;
	
	// add first one for blank selection
	menu_item[menu_total++] = "";
	
    b = opendir(dirpath);
    if (b) 
    {
		while ((c = readdir(b))) 
		{
			rom_type = Validate_ROM(c->d_name, dev);
			if (rom_type != -1)
			{
				menu_item[menu_total] = malloc(strlen(c->d_name) + 1);
				strcpy(menu_item[menu_total], c->d_name);
				menu_total++;
			}
		}
		closedir(b);
	}

	// end of the list
	menu_item[menu_total] = 0;

	while (TRUE)
	{
		ui_displaymenu(Machine->scrbitmap, (const char **)menu_item,0,0,sel,0);
		update_screen(Machine->scrbitmap);

		if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
			sel = sel + 1;

		if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
			sel = sel - 1;
			
		if (input_ui_pressed_repeat(IPT_UI_RIGHT,kREPEAT_TIME))
			sel = sel + visible - 1;

		if (input_ui_pressed_repeat(IPT_UI_LEFT,kREPEAT_TIME))
			sel = sel - visible + 1;

		if (sel > menu_total - 1)
		{
			sel = 0;
		}
		else if (sel < 0)
		{
			sel = menu_total - 1;
		}
		
		if (input_ui_pressed(IPT_UI_SELECT))
		{
			break;
		}
		
		if (input_ui_pressed(IPT_UI_CANCEL))
		{
			sel = -1;
			break;
		}
	}

	if (sel != -1)
	{
		// save a copy in return string
		strcpy(rom_name, menu_item[sel]);
	}
	
	// free all the strings
	// skip the first one since it's hard coded
	menu_total = 1;
	while(menu_item[menu_total])
	{
		free(menu_item[menu_total]);
		menu_total++;
	}

	// free the table
	free(menu_item);
	
	if (sel != -1)
	{
		return Validate_ROM(rom_name, dev);
	}
	else
	{
		return -2;
	}
}

char rom_files[MAX_IMAGES][20];

void * messfront(void * dummy)
{
	int sel;
	int visible;
	int hide_menu = 0;
	int lastone = -9999;
	int menu_total;
	char **menu_item;
	int i;
	int index;

	memset(&options, 0, sizeof(options));
	// Init default options
	options.norotate     = 0;
	options.ror          = 0;
	options.rol          = 0;
	options.flipx        = 0;
	options.flipy        = 0;
	options.use_artwork  = 1;
	options.color_depth  = 8; /* force 8-bit color */
	options.image_count  = 0;
	
	if ((camera_type == kTypeMinolta1) || 
		(camera_type == kTypeHP1) || 
		(camera_type == kTypeHP2))
	{
		options.use_samples  = 0;
		options.samplerate   = 0;
		play_sound = 0;
	}
	else
	{
		options.use_samples  = 1;
		options.samplerate   = 11025;
		play_sound = 1;
	}
	
	use_dirty = -1; 

	gResolution = 0;
	gPadOrientation = 0;
	cpu_slices_per_frame_override = 1;
	
    set_config_file ("/B/SYSTEM/MESS.CFG");

	parse_cmdline(0);
	
	// first is default selected
	sel = 0;
	
	// count drivers so we can allocate enough memory
	menu_total = 0;
	for (i = 0;drivers[i];i++)
	{
		if (drivers[i])
		{
			// check if rom exists and add it to list
			if (osd_faccess (drivers[i]->name, OSD_FILETYPE_ROM))
			{
				menu_total++;
			}
		}
	}
	menu_item = (char **)malloc(sizeof(char **) * (menu_total + 1));
	
	// reset count to start again and this time add the ones we find
	menu_total = 0;
	for (i = 0;drivers[i];i++)
	{
		if (drivers[i])
		{
			// check if rom exists and add it to list
			if (osd_faccess (drivers[i]->name, OSD_FILETYPE_ROM))
			{
				if (Flight_Check(i))
				{
					// mark file as not running by making it upper case
					int x;
					for (x = 0; x < strlen(drivers[i]->name); x++)
					{
						drivers[i]->name[x] = toupper(drivers[i]->name[x]);
					}
				}
				menu_item[menu_total++] = (char *)drivers[i]->name;
			}
		}
	}
	
	// end of the list
	menu_item[menu_total] = 0;

	qsort(menu_item, menu_total, sizeof(char **), sort_func);

	while(TRUE)
	{
		struct GameOptions saveOptions;
		int save_play_sound;
		int saveResolution;
		int savePadOrientation;
		struct MachineDriver fake_driver;
		struct GameDriver fake_gamedrv;
		struct InputPort fake_input_port;

		// reset screen to normal orientation and resolution while in main menu
		// we will restore it just before we start the game		

		memset(&fake_driver, 0, sizeof(fake_driver));
		memset(&fake_gamedrv, 0, sizeof(fake_gamedrv));
		memset(&fake_input_port, 0, sizeof(fake_input_port));
		
		saveOptions = options;
		save_play_sound = play_sound;
		saveResolution = gResolution;
		savePadOrientation = gPadOrientation;
		saveUse_dirty = use_dirty; 
		
		options.norotate    = 0;
		options.ror         = 0;
		options.rol         = 0;
		options.flipx       = 0;
		options.flipy       = 0;
		options.samplerate  = 0;
		options.use_samples = 0;
		options.use_artwork = 0;
		options.color_depth  = 8; /* force 8-bit color */
		options.image_count = 0;
		
//		play_sound = 1;
		gResolution = 0;
		gPadOrientation = 0;

		// Init enough of MAME's structures to get the user menus to work		
		
		Machine->drv = &fake_driver;
		fake_driver.frames_per_second = 60;
		fake_driver.video_attributes = VIDEO_MODIFIES_PALETTE;
		fake_driver.total_colors = NUMBER_OF_MENU_COLORS;
		if ((camera_type == kTypeHP1) || 
			(camera_type == kTypeMinolta1))
		{
			fake_driver.screen_width = 360;
			fake_driver.screen_height = 240;
		}
		else if ((camera_type == kTypeHP2)    || 
			     (camera_type == kTypeKodak0) || 
			     (camera_type == kTypeKodak1) || 
			     (camera_type == kTypeKodak2))
		{
			fake_driver.screen_width = 288;
			fake_driver.screen_height = 216;
		}

		Machine->gamedrv = &fake_gamedrv;
		
		Machine->orientation = ROT0;
		Machine->ui_orientation = ROT0;
		Machine->color_depth = 8;

		Machine->input_ports_default = &fake_input_port;
		Machine->input_ports = &fake_input_port;
		fake_input_port.type = IPT_END;

		code_init();

		Machine->scrbitmap = bitmap_alloc_depth(fake_driver.screen_width,fake_driver.screen_height,Machine->color_depth);
		osd_create_display(fake_driver.screen_width,
			fake_driver.screen_height,
			Machine->color_depth,
			fake_driver.frames_per_second,0,0);
		set_visible_area(0,fake_driver.screen_width,0,fake_driver.screen_height);		
		Machine->uifont = builduifont();

		visible = (Machine->uiheight / (3 * Machine->uifontheight / 2))/2 - 1;

		osd_allocate_colors(Machine->drv->total_colors, dummy_palette, pens, 1, 0, 0);
		
		while (TRUE)
		{
			if (menu_total == 0) // somethings wrong, nothing in the list, let the user reconfigure and then reboot
			{
				while (TRUE)
				{
					switch (gEnable_Disabled)
					{
						case 0:
						{
							Enable_Disable("/B/SYSTEM/MESS/OBJ/SYSTEM/", "/B/SYSTEM/MESS/OBJ/SYSTEM/DISABLED/");
							break;
						}
						case 1:
						{
							Enable_Disable("/B/SYSTEM/MESS/OBJ/CPU/", "/B/SYSTEM/MESS/OBJ/CPU/DISABLED/");
							break;
						}
						case 2:
						{
							Enable_Disable("/B/SYSTEM/MESS/OBJ/SOUND/", "/B/SYSTEM/MESS/OBJ/SOUND/DISABLED/");
							break;
						}
						default:
						{
							gEnable_Disabled = 0;
							break;
						}
					}
				}
			}

			if (input_ui_pressed(IPT_COIN1))
			{
				hide_menu = !hide_menu;
				lastone = -9999;
			}
			
			// draw snapshot before menu
			if (sel != lastone)
			{
				int orig_width;
				int orig_height;

				lastone = sel;
				
				// save two colors for new UI B&W
				snap_load_size_common(menu_item[sel], 0, NUMBER_OF_MENU_COLORS - 2, Machine->scrbitmap->width, Machine->scrbitmap->height, &snap_overlay, &orig_width, &orig_height);

				if (snap_overlay == NULL)
				{
					// find the driver in the list
					for (i = 0;drivers[i];i++)
					{
						if (drivers[i])
						{
							if (drivers[i]->name == menu_item[sel])
							{
								break;
							}
						}
					}

					snap_load_size_common(drivers[i]->clone_of->name, 0, NUMBER_OF_MENU_COLORS - 2, Machine->scrbitmap->width, Machine->scrbitmap->height, &snap_overlay, &orig_width, &orig_height);
				}
				
				osd_clearbitmap(Machine->scrbitmap);
				if (snap_overlay)
				{
					int offsetx;
					int offsety;
					
					for (i = 0; i < snap_overlay->num_pens_used; i++)
						osd_modify_pen(i, snap_overlay->orig_palette[i * 3], 
							snap_overlay->orig_palette[i * 3 + 1], 
							snap_overlay->orig_palette[i * 3 + 2]);

					offsetx = (Machine->scrbitmap->width - orig_width) / 2;
					offsety = (Machine->scrbitmap->height - orig_height) / 2;
					
					copybitmap(Machine->scrbitmap, snap_overlay->orig_artwork, 0, 0, offsetx, offsety, 0, TRANSPARENCY_NONE, 0);
					osd_mark_dirty(0,0,Machine->scrbitmap->width, Machine->scrbitmap->height, 0);
					
					osd_modify_pen(snap_overlay->num_pens_used, 0,0,0);
					osd_modify_pen(snap_overlay->num_pens_used + 1, 255,255,255);

					Machine->uifont->colortable[0] = snap_overlay->num_pens_used;
					Machine->uifont->colortable[1] = snap_overlay->num_pens_used + 1;
					Machine->uifont->colortable[2] = snap_overlay->num_pens_used + 1;
					Machine->uifont->colortable[3] = snap_overlay->num_pens_used;	

					artwork_free(&snap_overlay);
					snap_overlay = NULL;
				}
				else
				{
					hide_menu = 0;
				}
			}

			// draw menu
			if (!hide_menu)
			{		
				ui_displaymenu(Machine->scrbitmap, (const char **)menu_item,0,0,sel,0);
			}
			
			// get it all to the screen
			update_screen(Machine->scrbitmap);

			if (input_ui_pressed(IPT_UI_CONFIGURE))
			{
				// my little options menu
				const char *game_submenu_item[20];
				int game_submenu_total;
				const char *game_menu_item[20];
				int game_menu_total;
				int gamesel;
				
				// so we refresh the screen shot when we come back
				lastone = -9999;
				osd_clearbitmap(Machine->scrbitmap);

				gamesel = 0;
				
				while (TRUE)
				{
					game_menu_total = 0;
					game_submenu_total = 0;
					
					game_menu_item[game_menu_total++] = "Pad Orientation"; 
					if (savePadOrientation == 0) 
						game_submenu_item[game_submenu_total++] = "Up";
					else if (savePadOrientation == 1)
						game_submenu_item[game_submenu_total++] = "Right";
					else if (savePadOrientation == 2)
						game_submenu_item[game_submenu_total++] = "Down";
					else if (savePadOrientation == 3)
						game_submenu_item[game_submenu_total++] = "Left";
					else
						game_submenu_item[game_submenu_total++] = "Unknown";

					game_menu_item[game_menu_total++] = "Resolution";
					if (saveResolution == 1) 
						game_submenu_item[game_submenu_total++] = "High";
					else if (saveResolution == -1) 
						game_submenu_item[game_submenu_total++] = "Low";
					else if (saveResolution == 0) 
						game_submenu_item[game_submenu_total++] = "Med";
					else if (saveResolution == 2) 
						game_submenu_item[game_submenu_total++] = "Stretch";
					else if (saveResolution == 3) 
						game_submenu_item[game_submenu_total++] = "Expand";
					
					game_menu_item[game_menu_total++] = "No Rotation";
					if (saveOptions.norotate) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Rotation Right"; 
					if (saveOptions.ror) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Rotation Left"; 
					if (saveOptions.rol) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Flip X"; 
					if (saveOptions.flipx) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Flip Y"; 
					if (saveOptions.flipy) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					
					game_menu_item[game_menu_total++] = "Sound";
					if (saveOptions.samplerate) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Samples";
					if (saveOptions.use_samples) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Fake Sound";
					if (!save_play_sound) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
						
					game_menu_item[game_menu_total++] = "Artwork";
					if (saveOptions.use_artwork) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "CPU Slice Speedup";
					if (cpu_slices_per_frame_override) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Auto rotate";
					if (auto_rotate == 0) 
						game_submenu_item[game_submenu_total++] = "Off";
					else if (auto_rotate == 1) 
						game_submenu_item[game_submenu_total++] = "Auto Right"; 
					else if (auto_rotate == 2) 
						game_submenu_item[game_submenu_total++] = "Auto Left"; 

					game_menu_item[game_menu_total++] = "Dirty Rects";
					if (saveUse_dirty == 0) 
						game_submenu_item[game_submenu_total++] = "Off";
					else if (saveUse_dirty == 1) 
						game_submenu_item[game_submenu_total++] = "On"; 
					else if (saveUse_dirty == -1) 
						game_submenu_item[game_submenu_total++] = "Auto"; 

					{
						extern PART_ID memSysPartId;
						MEM_PART_STATS memStat;
						char memStr[50];
						
						memPartInfoGet(memSysPartId, &memStat);
						
						memStat.numBytesFree = memStat.numBytesFree / 1024;
						
						sprintf(memStr, "%dK free", memStat.numBytesFree);

						game_submenu_item[game_submenu_total++] = "\0"; 
						game_menu_item[game_menu_total++] = memStr;
					}

					game_menu_item[game_menu_total] = 0;
					game_submenu_item[game_submenu_total] = 0;
					
					ui_displaymenu(Machine->scrbitmap, (const char **)game_menu_item,(const char **)game_submenu_item,0,gamesel,0);
					update_screen(Machine->scrbitmap);

					if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
						gamesel = gamesel + 1;

					if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
						gamesel = gamesel - 1;
						
					if (gamesel > game_menu_total - 1)
					{
						gamesel = 0;
					}
					else if (gamesel < 0)
					{
						gamesel = game_menu_total - 1;
					}

					if (input_ui_pressed(IPT_UI_SELECT))
					{
						switch (gamesel)
						{
							case 0:
							{
								if (savePadOrientation == 0)
									savePadOrientation = 1;
								else if (savePadOrientation == 1)
									savePadOrientation = 2;
								else if (savePadOrientation == 2)
									savePadOrientation = 3;
								else if (savePadOrientation == 3)
									savePadOrientation = 0;
								else
									savePadOrientation = 0;
								break;
							}
							case 1:
							{
								if (saveResolution == -1)
									saveResolution = 0;
								else if (saveResolution == 0)
									saveResolution = 1;
								else if (saveResolution == 1)
									saveResolution = 2;
								else if (saveResolution == 2)
									saveResolution = 3;
								else if (saveResolution == 3)
									saveResolution = -1;
								break;
							}
							case 2:
							{
								if (saveOptions.norotate)
									saveOptions.norotate = 0;
								else
									saveOptions.norotate = 1;
								break;
							}
							case 3:
							{
								if (saveOptions.ror)
									saveOptions.ror = 0;
								else
									saveOptions.ror = 1;
								break;
							}
							case 4:
							{
								if (saveOptions.rol)
									saveOptions.rol = 0;
								else
									saveOptions.rol = 1;
								break;
							}
							case 5:
							{
								if (saveOptions.flipx)
									saveOptions.flipx = 0;
								else
									saveOptions.flipx = 1;
								break;
							}
							case 6:
							{
								if (saveOptions.flipy)
									saveOptions.flipy = 0;
								else
									saveOptions.flipy = 1;
								break;
							}
							case 7:
							{
								if (saveOptions.samplerate)
									saveOptions.samplerate = 0;
								else
									saveOptions.samplerate = 11025;
								break;
							}
							case 8:
							{
								if (saveOptions.use_samples)
									saveOptions.use_samples = 0;
								else
									saveOptions.use_samples = 1;
								break;
							}
							case 9:
							{
								
								if (save_play_sound)
									save_play_sound = 0;
								else
									if ((camera_type == kTypeMinolta1) || 
										(camera_type == kTypeHP1) || 
										(camera_type == kTypeHP2))
										save_play_sound = 0;
									else
										save_play_sound = 1;
								break;
							}
							case 10:
							{
								if (saveOptions.use_artwork)
									saveOptions.use_artwork = 0;
								else
									saveOptions.use_artwork = 1;
								break;
							}
							
							case 11:
							{
								if (cpu_slices_per_frame_override)
									cpu_slices_per_frame_override = 0;
								else
									cpu_slices_per_frame_override = 1;
								break;
							}
							
							case 12:
							{
								if (auto_rotate == 0)
									auto_rotate = 1;
								else if (auto_rotate == 1)
									auto_rotate = 2;
								else if (auto_rotate == 2)
									auto_rotate = 0;
								break;
							}
							
							case 13:
							{
								if (saveUse_dirty == 0)
									saveUse_dirty = 1;
								else if (saveUse_dirty == 1)
									saveUse_dirty = -1;
								else if (saveUse_dirty == -1)
									saveUse_dirty = 0;
								break;
							}
							
							default:
							{
								break;
							}
						}
						osd_clearbitmap(Machine->scrbitmap);
					}
					
					if (input_ui_pressed(IPT_UI_CANCEL) 
						|| input_ui_pressed(IPT_UI_CONFIGURE))
					{
						osd_clearbitmap(Machine->scrbitmap);
						break;
					}
				}
			}
			
			if (input_ui_pressed(IPT_UI_ON_SCREEN_DISPLAY) || input_ui_pressed(IPT_START1))
			{
				int temp_sel = 0;
				
				// so we refresh the screen shot when we come back
				lastone = -9999;
				
				do
				{
					switch (gEnable_Disabled)
					{
						case 0:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MESS/OBJ/SYSTEM/", "/B/SYSTEM/MESS/OBJ/SYSTEM/DISABLED/");
							break;
						}
						case 1:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MESS/OBJ/CPU/", "/B/SYSTEM/MESS/OBJ/CPU/DISABLED/");
							break;
						}
						case 2:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MESS/OBJ/SOUND/", "/B/SYSTEM/MESS/OBJ/SOUND/DISABLED/");
							break;
						}
						default:
						{
							gEnable_Disabled = 0;
							break;
						}
					}
				} while (temp_sel == -2);
			}

			if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
				sel = sel + 1;

			if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
				sel = sel - 1;
				
			if (input_ui_pressed_repeat(IPT_UI_RIGHT,kREPEAT_TIME))
				sel = sel + visible - 1;

			if (input_ui_pressed_repeat(IPT_UI_LEFT,kREPEAT_TIME))
				sel = sel - visible + 1;

			if (sel > menu_total - 1)
			{
				sel = menu_total - 1;
			}
			else if (sel < 0)
			{
				sel = 0;
			}
			
			if (input_ui_pressed(IPT_UI_SELECT))
			{
				break;
			}
		}

		// find the driver in the list
		for (i = 0;drivers[i];i++)
		{
			if (drivers[i])
			{
				if (drivers[i]->name == menu_item[sel])
				{
					break;
				}
			}
		}

		if (auto_rotate != 0)
		{
			if (drivers[i]->flags & ORIENTATION_SWAP_XY)
			{
				if (auto_rotate == 1)
				{
					savePadOrientation = 1;
					saveOptions.ror = 1;
					saveOptions.norotate = 0;
					saveOptions.rol = 0;
				}
				else if (auto_rotate == 2)
				{
					savePadOrientation = 3;
					saveOptions.ror = 0;
					saveOptions.norotate = 0;
					saveOptions.rol = 1;
				}
			}
			else
			{
				savePadOrientation = 0;
				saveOptions.ror = 0;
				saveOptions.norotate = 0;
				saveOptions.rol = 0;
			}
		}
		
		// add roms until user selects blank item from menu
		saveOptions.image_count = 0;
		for (index = 0; index < MAX_IMAGES; index++)
		{
			saveOptions.image_files[index].name = 0;
			saveOptions.image_files[index].type = IO_END;
		}
		
		while(saveOptions.image_count < MAX_IMAGES)
		{
			char directory[255];
			char * ext;
				
			strcpy(directory, "/B/SYSTEM/SOFTWARE/");
			strcat(directory, drivers[i]->name);
			
			saveOptions.image_files[saveOptions.image_count].type 
				= Select_ROM(directory, 
					drivers[i]->dev,
					rom_files[saveOptions.image_count]);
			saveOptions.image_files[saveOptions.image_count].name 
				= rom_files[saveOptions.image_count];
				
			/* cut off extension */
			ext = strrchr(saveOptions.image_files[saveOptions.image_count].name , '.');
			if (ext)
			{
				*ext = 0;
			}
			if (stricmp(saveOptions.image_files[saveOptions.image_count].name,"") != 0)
			{
				saveOptions.image_count++;
			}
			else
			{
				saveOptions.image_files[saveOptions.image_count].name = 0;
				saveOptions.image_files[saveOptions.image_count].type = 0;
				break;
			}
		}

		// clear the screen
		osd_clearbitmap(Machine->scrbitmap);
		update_screen(Machine->scrbitmap);
		update_screen(Machine->scrbitmap); /* clear both buffers in case we use interlaced mode */

		osd_close_display();
		Machine->scrbitmap = 0;
		
		bitmap_free(Machine->scrbitmap);
		Machine->scrbitmap = 0;
		
		freegfx(Machine->uifont);
		Machine->uifont = 0;

		Machine->gamedrv = 0;
		Machine->drv = 0;
		
		// restore current selected option settings
		gResolution = saveResolution;
		gPadOrientation = savePadOrientation;
		options = saveOptions;
		play_sound = save_play_sound;
		use_dirty = saveUse_dirty; 

		code_close();

		if (Flight_Check(i) == 0)
		{
			// start the game
			mame( drivers[i]->name );
		}

		// so we refresh the screen shot when we come back
		lastone = -9999;
		hide_menu = 0;
		
		for (i = 0; i < 4; i++)
			osd_led_w(i, 0);
			
		// restore
		use_dirty = saveUse_dirty;
	}
	
	free(menu_item);
	
	return 0;
}

#else

void * mamefront(void * dummy)
{
	int sel;
	int visible;
	int hide_menu = 0;
	int lastone = -9999;
	int menu_total;
	char **menu_item;
	int i;

	memset(&options, 0, sizeof(options));
	// Init default options
	options.norotate     = 0;
	options.ror          = 0;
	options.rol          = 0;
	options.flipx        = 0;
	options.flipy        = 0;
	options.use_artwork  = 1;
	options.color_depth  = 8; /* force 8-bit color */
	
	if ((camera_type == kTypeMinolta1) || 
		(camera_type == kTypeHP1) || 
		(camera_type == kTypeHP2))
	{
		options.use_samples  = 0;
		options.samplerate   = 0;
		play_sound = 0;
	}
	else
	{
		options.use_samples  = 1;
		options.samplerate   = 11025;
		play_sound = 1;
	}
	
	use_dirty = -1; // auto

	gResolution = 0;
	gPadOrientation = 0;
	cpu_slices_per_frame_override = 1;

    set_config_file ("/B/SYSTEM/MAME.CFG");

	parse_cmdline(0);
	
	// first is default selected
	sel = 0;
	
	// count drivers so we can allocate enough memory
	menu_total = 0;
	for (i = 0;drivers[i];i++)
	{
		if (drivers[i])
		{
			// check if rom exists and add it to list
			if (osd_faccess (drivers[i]->name, OSD_FILETYPE_ROM))
			{
				menu_total++;
			}
		}
	}
	menu_item = (char **)malloc(sizeof(char **) * (menu_total + 1));
	
	// reset count to start again and this time add the ones we find
	menu_total = 0;
	for (i = 0;drivers[i];i++)
	{
		if (drivers[i])
		{
			// check if rom exists and add it to list
			if (osd_faccess (drivers[i]->name, OSD_FILETYPE_ROM))
			{
				if (Flight_Check(i))
				{
					// mark file as not running by making it upper case
					int x;
					for (x = 0; x < strlen(drivers[i]->name); x++)
					{
						drivers[i]->name[x] = toupper(drivers[i]->name[x]);
					}
				}
				menu_item[menu_total++] = (char *)drivers[i]->name;
			}
		}
	}
	
	// end of the list
	menu_item[menu_total] = 0;

	qsort(menu_item, menu_total, sizeof(char **), sort_func);

	while(TRUE)
	{
		struct GameOptions saveOptions;
		int save_play_sound;
		int saveResolution;
		int savePadOrientation;
		struct MachineDriver fake_driver;
		struct GameDriver fake_gamedrv;
		struct InputPort fake_input_port;

		// reset screen to normal orientation and resolution while in main menu
		// we will restore it just before we start the game		

		memset(&fake_driver, 0, sizeof(fake_driver));
		memset(&fake_gamedrv, 0, sizeof(fake_gamedrv));
		memset(&fake_input_port, 0, sizeof(fake_input_port));
		
		saveOptions = options;
		save_play_sound = play_sound;
		saveResolution = gResolution;
		savePadOrientation = gPadOrientation;
		saveUse_dirty = use_dirty; 
		
		options.norotate    = 0;
		options.ror         = 0;
		options.rol         = 0;
		options.flipx       = 0;
		options.flipy       = 0;
		options.samplerate  = 0;
		options.use_samples = 0;
		options.use_artwork = 0;
		options.color_depth  = 8; /* force 8-bit color */

//		play_sound = 1;
		gResolution = 0;
		gPadOrientation = 0;

		// Init enough of MAME's structures to get the user menus to work		
		
		Machine->drv = &fake_driver;
		fake_driver.frames_per_second = 60;
		fake_driver.video_attributes = VIDEO_MODIFIES_PALETTE;
		fake_driver.total_colors = NUMBER_OF_MENU_COLORS;
		if ((camera_type == kTypeHP1) || 
			(camera_type == kTypeMinolta1))
		{
			fake_driver.screen_width = 360;
			fake_driver.screen_height = 240;
		}
		else if ((camera_type == kTypeHP2)    || 
			     (camera_type == kTypeKodak0) || 
			     (camera_type == kTypeKodak1) || 
			     (camera_type == kTypeKodak2))
		{
			fake_driver.screen_width = 288;
			fake_driver.screen_height = 216;
		}

		Machine->gamedrv = &fake_gamedrv;
		
		Machine->orientation = ROT0;
		Machine->ui_orientation = ROT0;
		Machine->color_depth = 8;
		
		Machine->input_ports_default = &fake_input_port;
		Machine->input_ports = &fake_input_port;
		Machine->debug_bitmap = 0;
		fake_input_port.type = IPT_END;
		
		code_init();
		
		Machine->scrbitmap = bitmap_alloc_depth(fake_driver.screen_width,fake_driver.screen_height,Machine->color_depth);
		osd_create_display(fake_driver.screen_width,
			fake_driver.screen_height,
			Machine->color_depth,
			fake_driver.frames_per_second,0,0);
		set_visible_area(0,fake_driver.screen_width,0,fake_driver.screen_height);		
		Machine->uifont = builduifont();
		
		visible = (Machine->uiheight / (3 * Machine->uifontheight / 2))/2 - 1;

		osd_allocate_colors(Machine->drv->total_colors, dummy_palette, pens, 1, 0, 0);

		while (TRUE)
		{
			if (menu_total == 0) // somethings wrong, nothing in the list, let the user reconfigure and then reboot
			{
				while (TRUE)
				{
					switch (gEnable_Disabled)
					{
						case 0:
						{
							Enable_Disable("/B/SYSTEM/MAME/OBJ/DRIVER/", "/B/SYSTEM/MAME/OBJ/DRIVER/DISABLED/");
							break;
						}
						case 1:
						{
							Enable_Disable("/B/SYSTEM/MAME/OBJ/CPU/", "/B/SYSTEM/MAME/OBJ/CPU/DISABLED/");
							break;
						}
						case 2:
						{
							Enable_Disable("/B/SYSTEM/MAME/OBJ/SOUND/", "/B/SYSTEM/MAME/OBJ/SOUND/DISABLED/");
							break;
						}
						default:
						{
							gEnable_Disabled = 0;
							break;
						}
					}
				}
			}

			if (input_ui_pressed(IPT_COIN1))
			{
				hide_menu = !hide_menu;
				lastone = -9999;
			}
			
			// draw snapshot before menu
			if (sel != lastone)
			{
				int orig_width;
				int orig_height;

				lastone = sel;
				
				// save two colors for new UI B&W
				snap_load_size_common(menu_item[sel], 0, NUMBER_OF_MENU_COLORS - 2, Machine->scrbitmap->width, Machine->scrbitmap->height, &snap_overlay, &orig_width, &orig_height);
				if (snap_overlay == NULL)
				{
					// find the driver in the list
					for (i = 0;drivers[i];i++)
					{
						if (drivers[i])
						{
							if (drivers[i]->name == menu_item[sel])
							{
								break;
							}
						}
					}

					snap_load_size_common(drivers[i]->clone_of->name, 0, NUMBER_OF_MENU_COLORS - 2, Machine->scrbitmap->width, Machine->scrbitmap->height, &snap_overlay, &orig_width, &orig_height);
				}

				osd_clearbitmap(Machine->scrbitmap);
				if (snap_overlay)
				{
					int offsetx;
					int offsety;
					
					for (i = 0; i < snap_overlay->num_pens_used; i++)
						osd_modify_pen(i, snap_overlay->orig_palette[i * 3], 
							snap_overlay->orig_palette[i * 3 + 1], 
							snap_overlay->orig_palette[i * 3 + 2]);

					offsetx = (Machine->scrbitmap->width - orig_width) / 2;
					offsety = (Machine->scrbitmap->height - orig_height) / 2;
					
					copybitmap(Machine->scrbitmap, snap_overlay->orig_artwork, 0, 0, offsetx, offsety, 0, TRANSPARENCY_NONE, 0);
					osd_mark_dirty(0,0,Machine->scrbitmap->width, Machine->scrbitmap->height, 0);
					
					osd_modify_pen(snap_overlay->num_pens_used, 0,0,0);
					osd_modify_pen(snap_overlay->num_pens_used + 1, 255,255,255);

					Machine->uifont->colortable[0] = snap_overlay->num_pens_used;
					Machine->uifont->colortable[1] = snap_overlay->num_pens_used + 1;
					Machine->uifont->colortable[2] = snap_overlay->num_pens_used + 1;
					Machine->uifont->colortable[3] = snap_overlay->num_pens_used;	

					artwork_free(&snap_overlay);
					snap_overlay = NULL;
				}
				else
				{
					hide_menu = 0;
				}
			}

			// draw menu
			if (!hide_menu)
			{		
				ui_displaymenu(Machine->scrbitmap, (const char **)menu_item,0,0,sel,0);
			}
			
			// get it all to the screen
			update_screen(Machine->scrbitmap);

			if (input_ui_pressed(IPT_UI_CONFIGURE))
			{
				// my little options menu
				const char *game_submenu_item[20];
				int game_submenu_total;
				const char *game_menu_item[20];
				int game_menu_total;
				int gamesel;
				
				// so we refresh the screen shot when we come back
				lastone = -9999;
				osd_clearbitmap(Machine->scrbitmap);

				gamesel = 0;
				
				while (TRUE)
				{
					game_menu_total = 0;
					game_submenu_total = 0;
					
					game_menu_item[game_menu_total++] = "Pad Orientation"; 
					if (savePadOrientation == 0) 
						game_submenu_item[game_submenu_total++] = "Up";
					else if (savePadOrientation == 1)
						game_submenu_item[game_submenu_total++] = "Right";
					else if (savePadOrientation == 2)
						game_submenu_item[game_submenu_total++] = "Down";
					else if (savePadOrientation == 3)
						game_submenu_item[game_submenu_total++] = "Left";
					else
						game_submenu_item[game_submenu_total++] = "Unknown";

					game_menu_item[game_menu_total++] = "Resolution";
					if (saveResolution == 1) 
						game_submenu_item[game_submenu_total++] = "High";
					else if (saveResolution == -1) 
						game_submenu_item[game_submenu_total++] = "Low";
					else if (saveResolution == 0) 
						game_submenu_item[game_submenu_total++] = "Med";
					else if (saveResolution == 2) 
						game_submenu_item[game_submenu_total++] = "Stretch";
					else if (saveResolution == 3) 
						game_submenu_item[game_submenu_total++] = "Expand";
					
					game_menu_item[game_menu_total++] = "No Rotation";
					if (saveOptions.norotate) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Rotation Right"; 
					if (saveOptions.ror) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Rotation Left"; 
					if (saveOptions.rol) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Flip X"; 
					if (saveOptions.flipx) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					game_menu_item[game_menu_total++] = "Flip Y"; 
					if (saveOptions.flipy) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
					
					game_menu_item[game_menu_total++] = "Sound";
					if (saveOptions.samplerate) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Samples";
					if (saveOptions.use_samples) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Fake Sound";
					if (!save_play_sound) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 
						
					game_menu_item[game_menu_total++] = "Artwork";
					if (saveOptions.use_artwork) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "CPU Slice Speedup";
					if (cpu_slices_per_frame_override) 
						game_submenu_item[game_submenu_total++] = "Yes";
					else 
						game_submenu_item[game_submenu_total++] = "No"; 

					game_menu_item[game_menu_total++] = "Auto rotate";
					if (auto_rotate == 0) 
						game_submenu_item[game_submenu_total++] = "Off";
					else if (auto_rotate == 1) 
						game_submenu_item[game_submenu_total++] = "Auto Right"; 
					else if (auto_rotate == 2) 
						game_submenu_item[game_submenu_total++] = "Auto Left"; 

					game_menu_item[game_menu_total++] = "Dirty Rects";
					if (saveUse_dirty == 0) 
						game_submenu_item[game_submenu_total++] = "Off";
					else if (saveUse_dirty == 1) 
						game_submenu_item[game_submenu_total++] = "On"; 
					else if (saveUse_dirty == -1) 
						game_submenu_item[game_submenu_total++] = "Auto"; 

					{
						extern PART_ID memSysPartId;
						MEM_PART_STATS memStat;
						char memStr[50];
						
						memPartInfoGet(memSysPartId, &memStat);
						
						memStat.numBytesFree = memStat.numBytesFree / 1024;
						
						sprintf(memStr, "%dK free", memStat.numBytesFree);

						game_submenu_item[game_submenu_total++] = "\0"; 
						game_menu_item[game_menu_total++] = memStr;
					}
					
					game_menu_item[game_menu_total] = 0;
					game_submenu_item[game_submenu_total] = 0;
					
					ui_displaymenu(Machine->scrbitmap, (const char **)game_menu_item,(const char **)game_submenu_item,0,gamesel,0);
					update_screen(Machine->scrbitmap);

					if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
						gamesel = gamesel + 1;

					if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
						gamesel = gamesel - 1;
						
					if (gamesel > game_menu_total - 1)
					{
						gamesel = 0;
					}
					else if (gamesel < 0)
					{
						gamesel = game_menu_total - 1;
					}

					if (input_ui_pressed(IPT_UI_SELECT))
					{
						switch (gamesel)
						{
							case 0:
							{
								if (savePadOrientation == 0)
									savePadOrientation = 1;
								else if (savePadOrientation == 1)
									savePadOrientation = 2;
								else if (savePadOrientation == 2)
									savePadOrientation = 3;
								else if (savePadOrientation == 3)
									savePadOrientation = 0;
								else
									savePadOrientation = 0;
								break;
							}
							case 1:
							{
								if (saveResolution == -1)
									saveResolution = 0;
								else if (saveResolution == 0)
									saveResolution = 1;
								else if (saveResolution == 1)
									saveResolution = 2;
								else if (saveResolution == 2)
									saveResolution = 3;
								else if (saveResolution == 3)
									saveResolution = -1;
								break;
							}
							case 2:
							{
								if (saveOptions.norotate)
									saveOptions.norotate = 0;
								else
									saveOptions.norotate = 1;
								break;
							}
							case 3:
							{
								if (saveOptions.ror)
									saveOptions.ror = 0;
								else
									saveOptions.ror = 1;
								break;
							}
							case 4:
							{
								if (saveOptions.rol)
									saveOptions.rol = 0;
								else
									saveOptions.rol = 1;
								break;
							}
							case 5:
							{
								if (saveOptions.flipx)
									saveOptions.flipx = 0;
								else
									saveOptions.flipx = 1;
								break;
							}
							case 6:
							{
								if (saveOptions.flipy)
									saveOptions.flipy = 0;
								else
									saveOptions.flipy = 1;
								break;
							}
							case 7:
							{
								if (saveOptions.samplerate)
									saveOptions.samplerate = 0;
								else
									saveOptions.samplerate = 11025;
								break;
							}
							case 8:
							{
								if (saveOptions.use_samples)
									saveOptions.use_samples = 0;
								else
									saveOptions.use_samples = 1;
								break;
							}
							case 9:
							{
								if (save_play_sound)
									save_play_sound = 0;
								else
									if ((camera_type == kTypeMinolta1) || 
										(camera_type == kTypeHP1) || 
										(camera_type == kTypeHP2))
										save_play_sound = 0;
									else
										save_play_sound = 1;
								break;
							}
							case 10:
							{
								if (saveOptions.use_artwork)
									saveOptions.use_artwork = 0;
								else
									saveOptions.use_artwork = 1;
								break;
							}
							
							case 11:
							{
								if (cpu_slices_per_frame_override)
									cpu_slices_per_frame_override = 0;
								else
									cpu_slices_per_frame_override = 1;
								break;
							}
							
							case 12:
							{
								if (auto_rotate == 0)
									auto_rotate = 1;
								else if (auto_rotate == 1)
									auto_rotate = 2;
								else if (auto_rotate == 2)
									auto_rotate = 0;
								break;
							}
														
							case 13:
							{
								if (saveUse_dirty == 0)
									saveUse_dirty = 1;
								else if (saveUse_dirty == 1)
									saveUse_dirty = -1;
								else if (saveUse_dirty == -1)
									saveUse_dirty = 0;
								break;
							}
							
							default:
							{
								break;
							}
						}
						osd_clearbitmap(Machine->scrbitmap);
					}
					
					if (input_ui_pressed(IPT_UI_CANCEL) 
						|| input_ui_pressed(IPT_UI_CONFIGURE))
					{
						osd_clearbitmap(Machine->scrbitmap);
						break;
					}
				}
			}
			
			if (input_ui_pressed(IPT_UI_ON_SCREEN_DISPLAY) || input_ui_pressed(IPT_START1))
			{
				int temp_sel = 0;

				// so we refresh the screen shot when we come back
				lastone = -9999;
				
				do
				{
					switch (gEnable_Disabled)
					{
						case 0:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MAME/OBJ/DRIVER/", "/B/SYSTEM/MAME/OBJ/DRIVER/DISABLED/");
							break;
						}
						case 1:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MAME/OBJ/CPU/", "/B/SYSTEM/MAME/OBJ/CPU/DISABLED/");
							break;
						}
						case 2:
						{
							temp_sel = Enable_Disable("/B/SYSTEM/MAME/OBJ/SOUND/", "/B/SYSTEM/MAME/OBJ/SOUND/DISABLED/");
							break;
						}
						default:
						{
							gEnable_Disabled = 0;
							break;
						}
					}
				} while (temp_sel == -2);
			}
			
			if (input_ui_pressed_repeat(IPT_UI_DOWN,kREPEAT_TIME))
				sel = sel + 1;

			if (input_ui_pressed_repeat(IPT_UI_UP,kREPEAT_TIME))
				sel = sel - 1;
				
			if (input_ui_pressed_repeat(IPT_UI_RIGHT,kREPEAT_TIME))
				sel = sel + visible - 1;

			if (input_ui_pressed_repeat(IPT_UI_LEFT,kREPEAT_TIME))
				sel = sel - visible + 1;

			if (sel > menu_total - 1)
			{
				sel = 0;
			}
			else if (sel < 0)
			{
				sel = menu_total - 1;
			}

			if (input_ui_pressed(IPT_UI_SELECT))
			{
				break;
			}
		}

		// find the driver in the list
		for (i = 0;drivers[i];i++)
		{
			if (drivers[i])
			{
				if (drivers[i]->name == menu_item[sel])
				{
					break;
				}
			}
		}

		if (auto_rotate != 0)
		{
			if (drivers[i]->flags & ORIENTATION_SWAP_XY)
			{
				if (auto_rotate == 1)
				{
					savePadOrientation = 1;
					saveOptions.ror = 1;
					saveOptions.norotate = 0;
					saveOptions.rol = 0;
				}
				else if (auto_rotate == 2)
				{
					savePadOrientation = 3;
					saveOptions.ror = 0;
					saveOptions.norotate = 0;
					saveOptions.rol = 1;
				}
			}
			else
			{
				savePadOrientation = 0;
				saveOptions.ror = 0;
				saveOptions.norotate = 0;
				saveOptions.rol = 0;
			}
		}
		
		// clear the screen
		osd_clearbitmap(Machine->scrbitmap);
		update_screen(Machine->scrbitmap);
		update_screen(Machine->scrbitmap); /* clear both buffers in case we use interlaced mode */
	
		osd_close_display();
		
		bitmap_free(Machine->scrbitmap);
		Machine->scrbitmap = 0;

		freegfx(Machine->uifont);
		Machine->uifont = 0;

		Machine->gamedrv = 0;
		Machine->drv = 0;
		
		// restore current selected option settings
		gResolution = saveResolution;
		gPadOrientation = savePadOrientation;
		options = saveOptions;
		play_sound = save_play_sound;
		use_dirty = saveUse_dirty;
		
		code_close();
		
		if (Flight_Check(i) == 0)
		{
			// start the game
			mame( drivers[i]->name );
		}

		// so we refresh the screen shot when we come back
		lastone = -9999;
		hide_menu = 0;
		
		for (i = 0; i < 4; i++)
			osd_led_w(i, 0);
			
		// restore
		use_dirty = saveUse_dirty;
	}
	
	free(menu_item);

	return 0;
}
#endif

/* update and display message log */
#define strLogFileName			"/B/MAME.LOG"
char *gStrLogFileName = NULL;

/* message to be added to the displayed log */
void LogText( char *message	)
{
	FILE *log;
	if (gStrLogFileName == NULL)
	{
		gStrLogFileName = strLogFileName;
	}
	log = fopen(gStrLogFileName, "a");
	if( log ) 
	{
		fprintf(log, "%s\r\n", message);
		fclose(log);
	}
} /* end of LogText() */

/* not a standard ANSI function but MAME uses it so stick it here */
int stricmp(const char *inString1, const char *inString2)
{
    char c1, c2;
    while (1)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
}

/* not a standard ANSI function but MAME uses it so stick it here */
int strnicmp(const char *inString1, const char *inString2, int len)
{
    char c1, c2;
    int i;
    
    for (i = 0; i < len; i++)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
    
    return 0;
}
