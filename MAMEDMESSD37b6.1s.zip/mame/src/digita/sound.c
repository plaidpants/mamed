#include "driver.h"

int attenuation = 0;

void sysdep_audio_init(void);
void sysdep_audio_close(void);
int sysdep_audio_play(INT16 *buf, int bufsize);

/* global sample tracking */
static int samples_per_frame;
static int samples_per_frame_remainder;
static int samples_left_over;
static int samples_this_frame;

int osd_start_audio_stream(int stereo)
{
	if (Machine->sample_rate == 0) return 0;

	/* determine the number of samples per frame */
	samples_per_frame = Machine->sample_rate / Machine->drv->frames_per_second;
	samples_per_frame_remainder = Machine->sample_rate % (int)Machine->drv->frames_per_second;
	samples_left_over = samples_per_frame_remainder;
	samples_this_frame = samples_per_frame;

	sysdep_audio_init();

	return samples_this_frame;
}

void osd_stop_audio_stream(void)
{
	if (Machine->sample_rate == 0) return;
	
	sysdep_audio_close();
}

int osd_update_audio_stream(INT16 *buffer)
{
	sysdep_audio_play(buffer, samples_this_frame);

	samples_left_over = samples_left_over + samples_per_frame_remainder;
	samples_this_frame = samples_per_frame +  samples_left_over / (int)Machine->drv->frames_per_second;
	samples_left_over =  samples_left_over % (int)Machine->drv->frames_per_second;

	return samples_this_frame;
}

/* attenuation in dB */
void osd_set_mastervolume(int _attenuation)
{
	if (_attenuation > 0) _attenuation = 0;
	if (_attenuation < -32) _attenuation = -32;

	attenuation = _attenuation;
}

int osd_get_mastervolume(void)
{
	return attenuation;
}

void osd_sound_enable(int enable_it)
{
}

void osd_opl_control(int chip,int reg)
{
}

void osd_opl_write(int chip,int data)
{
}
