
#ifndef __OSINLINE__
#define __OSINLINE__

/* What goes herein depends heavily on the OS. */

#include "osdepend.h"

extern char *dirty_new;
#define osd_mark_vector_dirty(x,y) dirty_new[(y)] = 1

#define osd_cycles tickGet

#endif /* __OSINLINE__ */
