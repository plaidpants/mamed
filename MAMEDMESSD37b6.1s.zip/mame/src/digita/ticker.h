#include "osd_cpu.h"


#define TICKER unsigned long
#define TICKS_PER_SEC sysClkRateGet()
#define ticker tickGet
