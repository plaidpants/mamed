#ifdef WIND_RIVER
/* vxWorks includes */
#include <vxWorks.h>
#include <symLib.h>
#include <sysSymTbl.h>
#include <loadLib.h>
#include <unldLib.h>
#include <ioLib.h>
#include <strLib.h>
#endif

/* GCC includes */
#include <dirent.h>
#include <stdio.h>

/* MAME includes */
#include "driver.h"

/* Digita includes */
#include "osd_depend.h"

static long camera_type = -1;

static void detect_camera_type(void)
{
	short					err = 0;
	TPARMNameTypeValue		data;
	char vendor[50];
	char product[50];

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak0;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak0;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
}

void Load_Directory(char *dirpath)
{
    DIR     		*b;
    struct dirent 	*c;
	char    		fname[100];
	int 			fid;
	
    b = opendir(dirpath);
    if (b) 
    {
		while ((c = readdir(b))) 
		{
			strcpy(fname, dirpath);
			strcat(fname, c->d_name);
			fid = open(fname, O_RDONLY, 0 );
			loadModule(fid, LOAD_ALL_SYMBOLS);
			close(fid);
		}
		closedir(b);
	}
}

#define P_STANDTBL_SIZE_ADDR 0xFFE00004
#define P_STANDTBL_ADDR      0xFFE00008
#define P_COMPTBL_SIZE_ADDR  0xFFE0000C

#define standTblSize (*((ULONG *)(P_STANDTBL_SIZE_ADDR)))
#define compTblSize  (*((ULONG *)(P_COMPTBL_SIZE_ADDR)))
#define standTblPtr  (*((SYMBOL **)(P_STANDTBL_ADDR)))

extern STATUS MyCreateSymtblA(void);
extern STATUS MyCreateSymtbl(void);
extern int inflate(char *, char *, int);
extern SYMTAB_ID sysSymTbl;

SYMBOL *vxSymTblPtr;
char *symTblPtr = NULL;

STATUS MyCreateSymtblA(void)
{
	STATUS status = ERROR;
    ULONG i;
    SYMBOL *ptrSymbol;
    ULONG numSymbol = standTblSize;
	ULONG bytes = numSymbol*sizeof(SYMBOL);

	if (!symTblPtr)
	{
		symTblPtr = malloc(1024*400);
		if (!symTblPtr)
		{
			symTblPtr = 0x800000;
		}
	}
	   
	inflate(((char *) standTblPtr) + 4, symTblPtr, compTblSize);

	vxSymTblPtr = symTblPtr + *((long *) standTblPtr);

	for (i = 0, ptrSymbol = vxSymTblPtr; i < numSymbol; i++)
	{	
		// adjust pointer to match actual memory location, this is a bug I am correcting here in the DC290 1.0.4 firmware
		ptrSymbol->name = (unsigned long)(ptrSymbol->name) - (unsigned long)(0x800000UL) + (unsigned long)(symTblPtr);
		status = symTblAdd (sysSymTbl, ptrSymbol++);
		if(status == ERROR)
		{
			break;
		}
	}

	return status;

}

STATUS MyCreateSymtbl(void)
{
	STATUS status = ERROR;	// return code

	sysSymTbl = symTblCreate(8, TRUE, memSysPartId);
	if (sysSymTbl)
	{
		status = MyCreateSymtblA();
	}

	return status;
}

STATUS MyEmptySymtbl(void)
{
	STATUS status = ERROR;	// return code

	status = symTblDelete(sysSymTbl);
	sysSymTbl = NULL;
	
	if ((symTblPtr) && (symTblPtr != 0x8000000))
	{
		free(symTblPtr);
		symTblPtr = NULL;
	}
	
	return status;
}


void entry(void)
{
	struct GameDriver **drivers_link;
	struct GameDriver *_drivers_link;
	struct snd_interface **sndintf_link;
	struct snd_interface *_sndintf_link;
	struct cpu_interface **cpuintf_link;
	struct cpu_interface *_cpuintf_link;

	void * entry_link;

	int fid;
	SYM_TYPE type;

	// Digita deleted the system symbol table at boot to save RAM 
	// so we have to recreate it here
	// so we can use it to link our stuff together at runtime.
	// of course all symbols in this part of the application will not
	// be in the symbol table so we cannot link anything here with
	// the rest of the code unless we do it manually.

	detect_camera_type();
	
	if (CreateSymtbl)
	{
		if (camera_type == kTypeKodak2)
			MyCreateSymtbl();
		else
			CreateSymtbl();
	}

	// Load the main application including all CPU and SOUND emulators
	fid = open("/B/SYSTEM/MESS/MESS.O", O_RDONLY, 0 );
	loadModule(fid, LOAD_ALL_SYMBOLS);
	close(fid);

	// load sound drivers
	Load_Directory("/B/SYSTEM/MESS/OBJ/SOUND/");

	// load cpu drivers
	Load_Directory("/B/SYSTEM/MESS/OBJ/CPU/");

	// load sound driver table
	fid = open("/B/SYSTEM/MESS/OBJ/SNDINTRF.O", O_RDONLY, 0 );
	loadModule(fid, LOAD_ALL_SYMBOLS);
	close(fid);	
	
	// Update sound drivers table pointer
	// to point to actual sound driver table that is now fully linked
	// symbol table will return the most recent value
	symFindByName(sysSymTbl, "sndintf", (char **)&sndintf_link, &type);
	symFindByName(sysSymTbl, "xsndintf", (char **)&_sndintf_link, &type);
	*sndintf_link = _sndintf_link;

	// load cpu drivers table
	fid = open("/B/SYSTEM/MESS/OBJ/CPUTBL.O", O_RDONLY, 0 );
	loadModule(fid, LOAD_ALL_SYMBOLS);
	close(fid);

	// Update sound drivers table pointer
	// to point to actual sound driver table that is now fully linked
	// symbol table will return the most recent value
	symFindByName(sysSymTbl, "cpuintf", (char **)&cpuintf_link, &type);
	symFindByName(sysSymTbl, "_cpuintf", (char **)&_cpuintf_link, &type);
	*cpuintf_link = _cpuintf_link;

	// Load the game drivers, it will link with CPU and SOUND emulators
	Load_Directory("/B/SYSTEM/MESS/OBJ/SYSTEM/");

	// Load the game driver table, it will link with the drivers 
	// and CPU and SOUND emulators
	fid = open("/B/SYSTEM/MESS/OBJ/SYSTEM.O", O_RDONLY, 0 );
	loadModule(fid, LOAD_ALL_SYMBOLS);
	close(fid);

	// Update drivers table pointer
	// to point to actual driver table that is now fully linked
	// symbol table will return the most recent value
	symFindByName(sysSymTbl, "drivers", (char **)&drivers_link, &type);
	symFindByName(sysSymTbl, "_drivers", (char **)&_drivers_link, &type);
	*drivers_link = _drivers_link;

	// Find the entry point of the main program
	symFindByName(sysSymTbl, "entry", (char **)&entry_link, &type);

	// We are done with the system symbol table now 
	// so we can delete it and free up a bit more RAM for MAME games
	if (EmptySymtbl)
	{
		if (camera_type == kTypeKodak2)
			MyEmptySymtbl();
		else
			EmptySymtbl();
	}
	
	// OK call the main program
	(*((void (*)(void))(entry_link)))();
}
