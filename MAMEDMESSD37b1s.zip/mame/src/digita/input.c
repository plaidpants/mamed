// MAME includes
#include "driver.h"

//#define DIGITA_DEBUG
#ifdef DIGITA_DEBUG
static char	__message[256];
extern void DisplayText(char *);
void LogText( char *message	);

#define DEBUG_OUT(format, args...) \
( \
	sprintf(__message, format, ##args), \
	LogText(__message) \
)
#else
#define DEBUG_OUT(format, args...) 
#endif

// external globals
extern unsigned short		lastButtonState;
extern unsigned short		lastButtonID;
extern unsigned short		buttonStates[];
extern int 					gPadOrientation;
extern int					mameTaskID;

#ifdef SOUND
extern int 					soundTaskID;
#endif
// local globals
long camera_type = -1;
SEM_ID event_Sem;

// these are the buttons for the DC220, DC260, & DC265
static struct KeyboardInfo keylistKodak[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kSoftkeyLeft,				KEYCODE_1 },
	{ "Middle SK",	kSoftkeyMid,				KEYCODE_ESC },
	{ "Right SK",	kSoftkeyRight,				KEYCODE_5 },
	{ "Up",			kUpArrow,					KEYCODE_UP },
	{ "Left",		kLeftArrow,					KEYCODE_LEFT },
	{ "Right",		kRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kDownArrow,					KEYCODE_DOWN },
	{ "Menu",		kMenuButton,				KEYCODE_TAB },
	{ "Zoom In",	kZoomIn,					KEYCODE_LALT },
	{ "Zoom Out",	kZoomOut,					KEYCODE_LCONTROL },
	{ "Display",	kOverlayButton,				KEYCODE_ENTER },
	{ "Record",		kRecordButton,				KEYCODE_TILDE },
	{ "Shutter 1",	kShutter1,					KEYCODE_E },
	{ "Shutter 2",	kShutter2,					KEYCODE_F12 },

/* these buttons are not avalible */
	{ "LCD 1",		kLCDStatus1,				KEYCODE_G },
	{ "LCD 2",		kLCDStatus2,				KEYCODE_H },
	{ "Connect",	kMode0Button,				KEYCODE_I },
	{ "Capture",	kMode1Button,				KEYCODE_J },
	{ "Review",		kMode2Button,				KEYCODE_K },
	{ "Info",		kMode3Button,				KEYCODE_L },
	{ "Spare 1",	kSpare1,					KEYCODE_M },
	{ "Spare 2",	kSpare2,					KEYCODE_N },
	{ 0, 0, 0 }	/* end of table */
};

// these are the buttons for the Minolta 1500 EX
static struct KeyboardInfo keylistMinolta[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kMinoltaSoftkeyLeft,			KEYCODE_1 },
	{ "Middle SK",	kMinoltaSoftkeyMid,				KEYCODE_ESC },
	{ "Right SK",	kMinoltaSoftkeyRight,			KEYCODE_5 },
	{ "Up",			kMinoltaUpArrow,				KEYCODE_UP },
	{ "Left",		kMinoltaLeftArrow,				KEYCODE_LEFT },
	{ "Right",		kMinoltaRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kMinoltaDownArrow,				KEYCODE_DOWN },
	{ "Menu",		kMinoltaMenuButton,				KEYCODE_TAB },
	{ "Overlay",	kMinoltaOverlayButton,			KEYCODE_ENTER },
	{ "Status",		kMinoltaStatusButton,			KEYCODE_LCONTROL },
	{ "Shutter 1",	kMinoltaShutter1,				KEYCODE_E },
	{ "Shutter 2",	kMinoltaShutter2,				KEYCODE_F12 },
/* these buttons are not avalible */
	{ "Connect",	kMinoltaMode0Button,			KEYCODE_I },
	{ "Capture",	kMinoltaMode1Button,			KEYCODE_J },
	{ "Review",		kMinoltaMode2Button,			KEYCODE_K },
	{ "Info",		kMinoltaMode3Button,			KEYCODE_L },
	{ 0, 0, 0 }	/* end of table */
};

// these are the buttons for the DC290 & HP C500
static struct KeyboardInfo keylistDigita[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kDigitaSoftKey1,				KEYCODE_1 },
	{ "Middle SK",	kDigitaSoftKey2,				KEYCODE_ESC },
	{ "Right SK",	kDigitaSoftKey3,				KEYCODE_5 },
	{ "Up",			kDigitaUpArrow,					KEYCODE_UP },
	{ "Left",		kDigitaLeftArrow,				KEYCODE_LEFT },
	{ "Right",		kDigitaRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kDigitaDownArrow,				KEYCODE_DOWN },
	{ "Menu",		kDigitaMenu,					KEYCODE_TAB },
	{ "Zoom In",	kDigitaZoomIn,					KEYCODE_LALT },
	{ "Zoom Out",	kDigitaZoomOut,					KEYCODE_LCONTROL },
	{ "Display",	kDigitaOverlay,					KEYCODE_ENTER },

/* these buttons are not avalible */
	{ "Record",		kDigitaRecord,					KEYCODE_TILDE },
	{ "Shutter 1",	kDigitaShutter1,				KEYCODE_E },
	{ "Shutter 2",	kDigitaShutter2,				KEYCODE_F12 },
	{ "LCD 1",		kDigitaLCDStatus1,				KEYCODE_G },
	{ "LCD 2",		kDigitaLCDStatus2,				KEYCODE_H },
	{ "Connect",	kDigitaHostMode,				KEYCODE_I },
	{ "Capture",	kDigitaCaptureMode,				KEYCODE_J },
	{ "Review",		kDigitaReviewMode,				KEYCODE_K },
	{ "Info",		kDigitaPlayMode,				KEYCODE_L },
	{ "Spare 1",	kDigitaSpare1,					KEYCODE_M },
	{ "Spare 2",	kDigitaSpare2,					KEYCODE_N },
	{ 0, 0, 0 }	/* end of table */
};

// Constants
#define 			MAX_BUTTONS 200

// Globals
unsigned short		buttonStates[MAX_BUTTONS];
unsigned short		lastButtonState;
unsigned short		lastButtonID;

unsigned char    	altAppID;

char vendor[50];
char product[50];

void detect_camera_type(void)
{
	short					err = 0;
	TPARMNameTypeValue		data;

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
}

void eventHandlerTask(void)
{
	short			result;
	int 			i;
	
    // Event loop setup
    result = AMGetSelfAppID(&altAppID);
    result = EMOpen(altAppID, 0);
    
	taskPrioritySet(taskIdSelf(), 3);
	
	// init button states
	for (i = 0; i < MAX_BUTTONS; i++)
	{
		buttonStates[i] = 0;
	}
	
	while(TRUE)
	{
		TEMEventRecordPtr	event;
		
		// don't hog the system

		if (event_Sem == 0)
			event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
		semTake(event_Sem, WAIT_FOREVER);

		while (TRUE)
		{
			if ((result = EMGetEvent( altAppID, &event )) != 0)
			{
				// event queue is empty
				break;
			}
	
			printf("Event %d", event->fButtonIndex);
			
			switch (event->fEvClass)
			{
				case kButtonClassEvent:
				{
					if ((camera_type == kTypeKodak2) || (camera_type == kTypeHP1))
					{
						switch (event->fButtonIndex)
						{
							case kDigitaUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kDigitaUpArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kDigitaLeftArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kDigitaDownArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kDigitaRightArrow;
										break;
									}
									default:
									{
										lastButtonID = kDigitaUpArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kDigitaLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kDigitaLeftArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kDigitaDownArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kDigitaRightArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kDigitaUpArrow;
										break;
									}
									default:
									{
										lastButtonID = kDigitaLeftArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kDigitaRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kDigitaRightArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kDigitaUpArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kDigitaLeftArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kDigitaDownArrow;
										break;
									}
									default:
									{
										lastButtonID = kDigitaRightArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kDigitaDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kDigitaDownArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kDigitaRightArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kDigitaUpArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kDigitaLeftArrow;
										break;
									}
									default:
									{
										lastButtonID = kDigitaDownArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
	
							case kDigitaSoftKey1:
							case kDigitaSoftKey2:
							case kDigitaSoftKey3:
							case kDigitaOverlay:
							case kDigitaMenu:
							case kDigitaZoomIn:
							case kDigitaZoomOut:
							case kDigitaLCDStatus1:
							case kDigitaLCDStatus2:
	//						case kDigitaReviewMode:
	//						case kDigitaCaptureMode:
							case kDigitaSpare1:
							case kDigitaSpare2:
							case kDigitaRecord:
							case kDigitaShutter1:
							case kDigitaShutter2:
//							case kDigitaPlayMode:
//							case kDigitaHostMode:
							{
								lastButtonState = event->fPosition;
								lastButtonID = event->fButtonIndex;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							default:
							{
								break;
							}
						}
	
						if (camera_type == kTypeHP1)
						{
							if ((event->fButtonIndex == kDigitaPowerOnOff) 
								&& event->fPosition) // note the difference with below, after button down no more events
							{
								// Stop the MAME task so we can shutdown
								taskSuspend(mameTaskID);
#ifdef SOUND
								taskSuspend(soundTaskID);
#endif
								pmPowerDown(1);
								
								// Wait for power off
								while(TRUE)
									taskDelay(10);
							}
						}
						else if (camera_type == kTypeKodak2)
						{
							if ((event->fButtonIndex == kDigitaPowerOnOff) 
								&& (event->fPosition == 0)) // note the difference with above
							{
								// Stop the MAME task so we can shutdown
								taskSuspend(mameTaskID);
#ifdef SOUND
								taskSuspend(soundTaskID);
#endif
								// this now works correctly becaue of correct init code
								SUPowerDown(0);
								
								// Wait for power off
								while(TRUE)
									taskDelay(10);
							}
						}
					}
					else if (camera_type == kTypeKodak1)
					{
						switch (event->fButtonIndex)
						{
							case kUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kUpArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kLeftArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kDownArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kRightArrow;
										break;
									}
									default:
									{
										lastButtonID = kUpArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kLeftArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kDownArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kRightArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kUpArrow;
										break;
									}
									default:
									{
										lastButtonID = kLeftArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kRightArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kUpArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kLeftArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kDownArrow;
										break;
									}
									default:
									{
										lastButtonID = kRightArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kDownArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kRightArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kUpArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kLeftArrow;
										break;
									}
									default:
									{
										lastButtonID = kDownArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
	
							case kSoftkeyLeft:
							case kSoftkeyMid:
							case kSoftkeyRight:
							case kOverlayButton:
							case kMenuButton:
							case kZoomIn:
							case kZoomOut:
							case kRecordButton:
							case kShutter1:
							case kShutter2:
							case kLCDStatus1:
							case kLCDStatus2:
	//						case kMode0Button:
	//						case kMode1Button:
	//						case kMode2Button:
	//						case kMode3Button:
							case kSpare1:
							case kSpare2:
							{
								lastButtonState = event->fPosition;
								lastButtonID = event->fButtonIndex;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							default:
							{
								break;
							}
						}
						
						if ((event->fButtonIndex == kPowerEvent) 
							&& (event->fPosition == 0))
						{
							// Stop the MAME task so we can shutdown
							taskSuspend(mameTaskID);
#ifdef SOUND
							taskSuspend(soundTaskID);
#endif
// this one works great for DC220, DC260, & DC265
							PMPowerDown( 0 );
							// Wait for power off					
							while(TRUE)
								taskDelay(10);
						}
					}
					else if (camera_type == kTypeMinolta1)
					{
						switch (event->fButtonIndex)
						{
							case kMinoltaUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kMinoltaUpArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kMinoltaLeftArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kMinoltaDownArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kMinoltaRightArrow;
										break;
									}
									default:
									{
										lastButtonID = kMinoltaUpArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kMinoltaLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kMinoltaLeftArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kMinoltaDownArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kMinoltaRightArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kMinoltaUpArrow;
										break;
									}
									default:
									{
										lastButtonID = kMinoltaLeftArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kMinoltaRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kMinoltaRightArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kMinoltaUpArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kMinoltaLeftArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kMinoltaDownArrow;
										break;
									}
									default:
									{
										lastButtonID = kMinoltaRightArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							case kMinoltaDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastButtonID = kMinoltaDownArrow;
										break;
									}
									case 1:
									{
										lastButtonID = kMinoltaRightArrow;
										break;
									}
									case 2:
									{
										lastButtonID = kMinoltaUpArrow;
										break;
									}
									case 3:
									{
										lastButtonID = kMinoltaLeftArrow;
										break;
									}
									default:
									{
										lastButtonID = kMinoltaDownArrow;
										break;
									}
								}
								lastButtonState = event->fPosition;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
	
							case kMinoltaSoftkeyLeft:
							case kMinoltaSoftkeyMid:
							case kMinoltaSoftkeyRight:
							case kMinoltaStatusButton:
							case kMinoltaOverlayButton:
							case kMinoltaMenuButton:
							case kMinoltaShutter1:
							case kMinoltaShutter2:
	//						case kMode0Button:
	//						case kMode1Button:
	//						case kMode2Button:
	//						case kMode3Button:
							{
								lastButtonState = event->fPosition;
								lastButtonID = event->fButtonIndex;
								buttonStates[lastButtonID] = lastButtonState;
								break;
							}
							default:
							{
								break;
							}
						}
						
						if ((event->fButtonIndex == kMinoltaPowerEvent) 
							&& (event->fPosition == 0))
						{
							// Stop the MAME task so we can shutdown
							taskSuspend(mameTaskID);
	#ifdef SOUND
							taskSuspend(soundTaskID);
	#endif
							PMPowerDown( 0 );
							// Wait for power off					
							while(TRUE)
								taskDelay(10);
						}
					}
					break;
				}
				default:
				{
					break;
				}
			}
	
			result = EMReleaseEventRecord(event);
		}
	}
}

/* return a list of all available keys */
const struct KeyboardInfo *osd_get_key_list(void)
{
	if ((camera_type == kTypeKodak2) || (camera_type == kTypeHP1))
	{
		return keylistDigita;
	}	
	else if (camera_type == kTypeKodak1)
	{
		return keylistKodak;
	}
	else if (camera_type == kTypeMinolta1)
	{
		return keylistMinolta;
	}
	
	return keylistDigita;
}

void osd_led_w(int led, int on)
{

}

/* check if a key is pressed. The keycode is the standard PC keyboard code, as */
/* defined in osdepend.h. Return 0 if the key is not pressed, nonzero otherwise. */
int osd_is_key_pressed(int keycode)
{
	if (buttonStates[keycode])
	{
		return 1;
	}
	
	return 0;
}

/* wait for a key press and return the keycode */
int osd_wait_keypress(void)
{
	while (lastButtonState == 0)
		taskDelay(5);
	
	return lastButtonID;
}

#define MAX_JOY 1

static struct JoystickInfo joylist[MAX_JOY] =
{
	{ 0, 0, 0 }	/* end of table */
};

/* return a list of all available joys */
const struct JoystickInfo *osd_get_joy_list(void)
{
	return joylist;
}


int osd_is_joy_pressed(int joycode)
{
	return 0;
}

void osd_poll_joysticks(void)
{
}

/* return a value in the range -128 .. 128 (yes, 128, not 127) */
void osd_analogjoy_read(int player,int *analog_x, int *analog_y)
{
	*analog_x = 0;
	*analog_y = 0;
}

int osd_joystick_needs_calibration (void)
{
	return 0;
}

void osd_joystick_start_calibration (void)
{
}

char *osd_joystick_calibrate_next (void)
{
	return 0;
}

void osd_joystick_calibrate (void)
{
}

void osd_joystick_end_calibration (void)
{
}

void osd_trak_read(int player,int *deltax,int *deltay)
{
	*deltax = 0;
	*deltay = 0;
}

void osd_customize_inputport_defaults(struct ipd *defaults)
{
}