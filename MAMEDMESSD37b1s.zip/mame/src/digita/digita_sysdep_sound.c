// MAME includes
#include "driver.h"
#include "sound.h"

// vxWorks includes
#ifdef SOUND
#include <taskLib.h>
#include <semLib.h>
#include <intLib.h>
#include <rngLib.h>
#include <arch/ppc/vxPpcLib.h>
#include <arch/ppc/ivPpc.h>
#include <drv/sio/ppc860Sio.h>
#include <drv/multi/ppc860Siu.h>
#include <drv/multi/ppc860Cpm.h>
#include <drv/intrCtl/ppc860Intr.h>

// make this a bit bigger for us, seems to sound better
#undef kSNDDefaultBDLength
#define kSNDDefaultBDLength 400
//typedef void * SEM_ID;

// structures
typedef struct cache
{
	SEM_ID soundPlaying;
	unsigned char data[2*kSNDDefaultBDLength];
	int length;
	int best_repeat_offset;
} cache_data;

// extern globals
extern long camera_type;
extern int play_sound;

// local globals
#define kNumStreams 4

cache_data stream_cache[kNumStreams];

int curStream;
int nextStream;
cache_data * cur_cache_data = 0;

SEM_ID new_audio;
SEM_ID sound_isr;
SEM_ID * current_sound_playing = 0;
SEM_ID sound_init;

static unsigned long base;
static TAUDBufferDescriptor 	*pBD_DPRAM;

void sysInterruptHandler(void)
{
	unsigned char					event;
	unsigned char					processedEvent;

	/* let's handle the interrupt */
	*CISR(base) = CISR_SMC2_PIP;

	event = (unsigned char)*SMCE2(base);

	if (event & kSMCEventReceiveBufferIsClosed)
	{
		processedEvent = kSMCEventReceiveBufferIsClosed; 
	}
	else if (event & kSMCEventBufferIsTransmitted)  	
	{
		processedEvent = kSMCEventBufferIsTransmitted; 
	}
	else if (event & kSMCEventUnderrun)
	{
		*SMCM2(base) &= ~kSMCEventUnderrun;
		processedEvent = kSMCEventUnderrun;
	} 
	else if (event & kSMCEventBusy)
	{
		*SMCM2(base) &= ~kSMCEventBusy;
		processedEvent = kSMCEventBusy;
	}
	else
	{
		processedEvent = event;
	}

	*SMCE2(base) = processedEvent;

	/* done playing sound */
	semGive(sound_isr);

	if (current_sound_playing != 0)
	{
		/* done playing this sound buffer */
		semGive(*current_sound_playing);
		current_sound_playing = 0;
	}
}
#endif

void sysdep_audio_init(void)
{
#ifdef SOUND
	int i;

	if (play_sound)
	{
		if (camera_type == kTypeKodak1)
		{
			/* Open up the codec */
			sndOpenCodec();
			sndConfigureCodec(kSNDConfigureCodecOutput);
			taskDelay(1);
			sndHWSetBilevelVolume(2);
			sndHWPowerCodec(2);
			taskDelay(7);
			sndMuteAudio(0);
			sndInitCodecTransmit();

			/* take over the isr so we can add a sem */
			intConnect(IV_SMC2_PIP, (VOIDFUNCPTR)sysInterruptHandler, 0);

			/* init my stuff */
			nextStream = 0;
			curStream = 0;

			/* Clear out stream cache */
			for (i = 0; i < kNumStreams; i++)
			{
				stream_cache[i].length = kSNDDefaultBDLength;
				memset(stream_cache[i].data,0,2*kSNDDefaultBDLength);
				stream_cache[i].soundPlaying = semBCreate(SEM_Q_PRIORITY, SEM_FULL);
			}
			
			/* setup globals so we don't have to call these functions later */
			base = vxImmrGet();
			pBD_DPRAM = (TAUDBufferDescriptor*)(kSMC2TxBD(MPC860_DPRAM_BASE(base)));
		}
		else if (camera_type == kTypeKodak2)
		{
			AUDOpenCodec();
			AUDConfigureCodec(kSNDConfigureCodecOutput);
			taskDelay(1);
			AUDHWSetBilevelVolume(2);
			AUDPowerCodec(2);
			taskDelay(7);
			AUDMuteAudio(0);
			AUDInitCodecTransmit();	

			/* take over the isr so we can add a sem */
			intConnect(IV_SMC2_PIP, (VOIDFUNCPTR)sysInterruptHandler, 0);

			/* init my stuff */
			nextStream = 0;
			curStream = 0;

			/* Clear out stream cache */
			for (i = 0; i < kNumStreams; i++)
			{
				stream_cache[i].length = kSNDDefaultBDLength;
				memset(stream_cache[i].data,0,2*kSNDDefaultBDLength);
      			stream_cache[i].soundPlaying = semBCreate(SEM_Q_PRIORITY, SEM_FULL);
			}

			/* setup globals so we don't have to call these functions later */
			base = vxImmrGet();
			pBD_DPRAM = (TAUDBufferDescriptor*)(kSMC2TxBD(MPC860_DPRAM_BASE(base)));
		}
		
		new_audio = semCCreate(SEM_Q_PRIORITY, 0);
		sound_isr =  semBCreate(SEM_Q_PRIORITY, SEM_FULL);

		// Done initializing
		semGive(sound_init);
	}
#endif
}

void sysdep_audio_close(void)
{
#ifdef SOUND
	int i;
	
	if (play_sound)
	{
		// stop everything
		semTake(sound_init, WAIT_FOREVER);
		cur_cache_data = 0;
		current_sound_playing = 0;

		semDelete(sound_isr);
		sound_isr = 0;
		
		semDelete(new_audio);
		new_audio = 0;

		if (camera_type == kTypeKodak1)
		{
			/* close up the codec */
			sndCloseCodecTransmit();
			sndMuteAudio(1);
			sndCloseCodec();
			
			/* do our stuff now */
			nextStream = 0;
			curStream = 0;
			
			/* Clear out stream cache */
			for (i = 0; i < kNumStreams; i++)
			{
				stream_cache[i].length = kSNDDefaultBDLength;
				memset(stream_cache[i].data, 0, 2*kSNDDefaultBDLength);
				semDelete(stream_cache[i].soundPlaying);
				stream_cache[i].soundPlaying = 0;
			}
		}
		else if (camera_type == kTypeKodak2)
		{
			AUDCloseCodecTransmit();
			AUDMuteAudio(1);
			AUDCloseCodec();

			/* do our stuff now */
			nextStream = 0;
			curStream = 0;
			
			/* Clear out stream cache */
			for (i = 0; i < kNumStreams; i++)
			{
				stream_cache[i].length = kSNDDefaultBDLength;
				memset(stream_cache[i].data, 0, 2*kSNDDefaultBDLength);
				semDelete(stream_cache[i].soundPlaying);
				stream_cache[i].soundPlaying = 0;
			}
		}
	}
#endif
}

int sysdep_audio_play(INT16 *buf, int bufsize)
{
#ifdef SOUND
	if (play_sound)
	{
		if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
		{
			int i;
			unsigned short  *tmp = (short  *)buf;
			unsigned short temp;
			cache_data * next_cache_data;
			
			/* Convert 16 bit to 15 bit first since we have time now */
			for (i = 0; i < bufsize; i++)
			{
				temp = *tmp;
				*tmp++ = temp >> 1;
			}

			next_cache_data = &stream_cache[nextStream];
			
			/* make sure the buffer is not in use */
			semTake(next_cache_data->soundPlaying, WAIT_FOREVER);
			
			/* copy the data into the buffer */
			memcpy(next_cache_data->data, buf, 2*bufsize);
			next_cache_data->length = 2*bufsize;
			/* go to next buffer */
			nextStream++;
			if (nextStream == kNumStreams)
				nextStream = 0;

			{
		    	int last_diff;
		    	int last_offset;
		    	int end_offset;
		    	int diff;
		    	int i,j;
		    	short * data_ptr;
		    	
		    	/* Find a match in the waveform to match the end of the wave form segment */
		    	last_diff = 32000;
		    	last_offset = 0;
		    	data_ptr = (short *)next_cache_data->data;
		    	for (i = 0; i < bufsize / 4; i += 1)
		    	{
		    		end_offset = bufsize - 1 - 40;
		    		diff = 0;
		    		
		    		for (j = 0; j < 40; j += 3)
		    		{
		    			diff = diff + abs(data_ptr[end_offset + j] - data_ptr[i + j]);
		    		}
		    		
		    		if (diff < last_diff)
		    		{
		    			last_diff = diff;
		    			last_offset = i + 40 + 1; /* go to next sample */
		    			
		    			if (diff < (40/3))
		    			{
		    				/* good enough */
		    				break;
		    			}
		    		}
		    	}
				next_cache_data->best_repeat_offset = last_offset * 2;
			}

			/* signal the sound task we have new buffers to play */
	  		semGive(new_audio);
		}
	}
#endif

	return bufsize;
}

#ifdef SOUND
void PlaySound(void)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
    {
		cur_cache_data = &stream_cache[curStream];
		
		/* setup current sound buffer sem */
		current_sound_playing = &cur_cache_data->soundPlaying;

		pBD_DPRAM->fDataLength = cur_cache_data->length - kSNDBDSyncOffset;
		pBD_DPRAM->fBufferPointer = (unsigned char *)cur_cache_data->data + kSNDBDSyncOffset;
		pBD_DPRAM->fStatus = (kSMCBDInitTransparent
			| kSMCBDInterrupt
			| kSMCBDReady
			| kSMCBDLastByteInMessage
			| kSMCBDLastBDInTable);

		*SMCE2(base) = 0xff;
		*SMCM2(base) = kSMCEventBufferIsTransmitted | kSMCEventUnderrun;
		*SMCMR2(base) = kSMC16BitTransparentNormal | kSMCEnableTransmitter;

	 	/* go to next sound buffer */
		curStream++;
		if (curStream == kNumStreams)
			curStream = 0;
   }
}

void RepeatSound(void)
{
	// need to add front to back sound matching
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
    {    	
		/* setup current sound buffer sem */
		current_sound_playing = &cur_cache_data->soundPlaying;
		
		pBD_DPRAM->fDataLength = cur_cache_data->length - cur_cache_data->best_repeat_offset - kSNDBDSyncOffset;
		pBD_DPRAM->fBufferPointer = (unsigned char *)cur_cache_data->data + cur_cache_data->best_repeat_offset + kSNDBDSyncOffset;
		pBD_DPRAM->fStatus = (kSMCBDInitTransparent
			| kSMCBDInterrupt
			| kSMCBDReady
			| kSMCBDLastByteInMessage
			| kSMCBDLastBDInTable);

		*SMCE2(base) = 0xff;
		*SMCM2(base) = kSMCEventBufferIsTransmitted | kSMCEventUnderrun;
		*SMCMR2(base) = kSMC16BitTransparentNormal | kSMCEnableTransmitter;
   }
}
#endif

#ifdef SOUND
void *DigitaSoundTask(void *dummy)
{
	if ((camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
    {
		while (TRUE)
		{
			// check if we are suppose to stop
			semTake(sound_init, WAIT_FOREVER);
			
			if (play_sound)
			{
				// wait for current sound to finish
				semTake(sound_isr, WAIT_FOREVER);
				
				// play new sound if availible
				if (semTake(new_audio, NO_WAIT) == OK)
				{
					PlaySound();
				}
				else
				{
					// try to get the last buffer played back otherwise try again
					if (cur_cache_data)
					{
						if (semTake(cur_cache_data->soundPlaying, NO_WAIT) == OK)
						{
							RepeatSound();
						}
						else
						{
							// can't get buffer, maybe we have new sound, pretend to play sound
							taskDelay(1);
							semGive(sound_isr);
						}
					}
					else
					{
						// no sound played yet, pretend to play sound
						taskDelay(1);
						semGive(sound_isr);
					}
				}
			}
			else
			{
				// not playing sound right now, don't do much
				taskDelay(10);
			}
			
			// allow someone to stop us
			semGive(sound_init);
		}

		/* these sems are never really destroyed */
		semDelete(sound_init);
		sound_init = 0;
	}
	
	return 0;
}
#endif