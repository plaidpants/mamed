/***************************************************************************

  osdepend.c

  OS dependant stuff (display handling, keyboard scan...)
  This is the only file which should me modified in order to port the
  emulator to a different system.

***************************************************************************/

#include "driver.h"
#include <time.h>
#include <ctype.h>
#include "ticker.h"

#ifdef MESS
#include "mess/msdos.h"
/* from msdos/config.c */
extern char *crcdir;
static char crcfilename[256] = "";
const char *crcfile = crcfilename;
extern char *pcrcdir;
static char pcrcfilename[256] = "";
const char *pcrcfile = pcrcfilename;
#endif

int  digita_init_sound(void);
void digita_shutdown_sound(void);

extern char * cheatfile;
extern char * history_filename;
extern char * mameinfo_filename;
extern char * nvdir;
extern char * hidir;
extern char * cfgdir;
extern char * screenshotdir;
extern char * memcarddir;
extern char * stadir;
extern char * artworkdir;
extern char * crcdir;
extern char * alternate_name;

extern long 				camera_type;
extern int					play_sound;

extern void decompose_rom_sample_path (char *rompath, char *samplepath);

void parse_cmdline (void)
{
	/* read graphic configuration */
//	options.use_artwork  = 0;

	options.antialias    = 1;
	options.translucency = 0;
	options.beam = 0x00010000;
	options.flicker = 0;

#if 0
	options.norotate  = 0;
	options.ror       = 0;
	options.rol       = 0;
	options.flipx     = 0;
	options.flipy     = 0;
	options.use_samples  = 0;
#endif

//	errorlog = 	fopen("/B/MAME.LOG", "a");
	options.errorlog = 0;
		

	options.record = 0;
	options.playback = 0;
	options.mame_debug = 0;
//	options.no_fm = 0;
	options.use_emulated_ym3812 = 0;

	/* read sound configuration *
	options.samplerate = 11025;
	options.samplebits = 16;
	*/	

	/*
	options.samplerate = 0;
	options.samplebits = 0;
	*/

	/* misc configuration */
	options.cheat      = 0;
	options.mame_debug = 0;
}

/* put here anything you need to do when the program is started. Return 0 if */
/* initialization was successful, nonzero otherwise. */
int osd_init(void)
{
	cheatfile = "/B/SYSTEM/CHEAT.DAT"; 
 
 	#ifndef MESS
	history_filename = "/B/SYSTEM/HISTORY.DAT";
 	#else
 	history_filename = "/B/SYSTEM/SYSINFO.DAT";
	#endif

	mameinfo_filename = "/B/SYSTEM/MAMEINFO.DAT";
	
	nvdir = "/B/SYSTEM/NVRAM/";
	hidir = "/B/SYSTEM/HI/";
	cfgdir = "/B/SYSTEM/CFG/";
	screenshotdir = "/B/SYSTEM/SNAP/";
	memcarddir = "/B/SYSTEM/MEMCARD/";
	stadir = "/B/SYSTEM/STA/";
	artworkdir = "/B/SYSTEM/ARTWORK/";
 	#ifdef MESS
 		crcdir = "/B/SYSTEM/CRC/";
 	#endif
	alternate_name = 0;
	
	decompose_rom_sample_path("/B/SYSTEM/ROMS;/B/SYSTEM/", "/B/SYSTEM/SAMPLES;/B/SYSTEM/");

	return 0;
}



/* put here cleanup routines to be executed when the program is terminated. */
void osd_exit(void)
{
}

void * mame (char * gamename)
{
	int i, res, game_index;

	game_index = -1;

	/* If not playing back a new .inp file */
    if (game_index == -1)
    {
        /* do we have a driver for this? */
        {
            for (i = 0; (drivers[i] != 0) && (game_index == -1); i++)
            {
            	if (drivers[i])
            	{
	                if (strcmp(gamename, drivers[i]->name) == 0)
	                {
	                    game_index = i;
	                    break;
	                }
	            }
            }
        }

        if (game_index == -1)
        {
            printf("Game \"%s\" not supported\n", gamename);
            return 0;
        }
        else
        {
            printf("Running Game \"%s\"\n", gamename);
        }
    }

	#ifdef MESS
	/* This function has been added to MESS.C as load_image() */
//	load_image(argc, argv, j, game_index);
	#endif

	/* parse generic (os-independent) options */
	parse_cmdline();

	/* Minolta, HP, & DC290 don't support sound, so turn it off */
	if ((camera_type == kTypeMinolta1) || 
		(camera_type == kTypeHP1) || 
		((camera_type == kTypeKodak2) && (AUDOpenCodec == 0)))
	{
		play_sound = 0;
	}

	/* go for it */
	res = run_game (game_index);

	/* close open files */
	if (options.errorlog) fclose (options.errorlog);
	if (options.playback) osd_fclose (options.playback);
	if (options.record)   osd_fclose (options.record);

	osd_exit();
	
	return 0;
}
