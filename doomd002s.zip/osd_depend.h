#ifndef OSD_DEPEND_H
#define OSD_DEPEND_H

#include "SoundPrivate.h"

#define TRUE 1
#define FALSE 0
#define SEM_Q_PRIORITY 1
#define WAIT_FOREVER -1
#define NO_WAIT 0
#define SEM_FULL 1
#define SEM_EMPTY 0
#define OK 0
#define O_RDONLY 0
#define	O_WRONLY 1
#define	O_RDWR 2
#define	O_CREAT 0x0200
#define	O_NONBLOCK 0x4000
#define O_BINARY 0
#define LOAD_ALL_SYMBOLS 12

typedef void * SEM_ID;
typedef signed char SYM_TYPE;

struct mq_attr
{
	int mq_maxmsg;
	int mq_msgsize;
	unsigned mq_flags;
	int mq_curmsgs;
};

struct	stat
{
	unsigned long st_dev;
	unsigned long st_ino;
	unsigned short st_mode;
	short st_nlink;
	short st_uid;
	short st_gid;
	unsigned long st_rdev;
	unsigned long st_size;
	int st_atime;
	int st_mtime;
	int st_ctime;
	long st_blksize;
	long st_blocks;
	unsigned char st_attrib;
	int reserved1;
	int reserved2;
	int reserved3;
	int reserved4;
	int reserved5;
	int reserved6;
};

/* HP C500 & Kodak DC290 button IDs */
typedef enum 
{
    kDigitaMenu,
    kDigitaOverlay,
    kDigitaPortraitLeft,
    kDigitaPortraitRight,
    kDigitaLCDStatus2,
    kDigitaLCDStatus1,
    kDigitaSpare1,
    kDigitaSpare2,
    kDigitaSoftKey2,
    kDigitaSoftKey3,
    kDigitaZoomOut,
    kDigitaZoomIn,
    kDigitaShutter1,
    kDigitaShutter2,
    kDigitaRecord,
    kDigitaInstantReview,
    kDigitaHostMode,
    kDigitaPlayMode,
    kDigitaUpArrow,
    kDigitaLeftArrow,
    kDigitaRightArrow,
    kDigitaDownArrow,
    kDigitaLCDOnOff,
    kDigitaSoftKey1,
    kDigitaPowerOnOff,
    kDigitaUnused6,
    kDigitaUnused5,
    kDigitaUnused4,
    kDigitaUnused3,
    kDigitaUnused2,
    kDigitaUnused1,
    kDigitaUnused0,
    kDigitaReviewMode,
    kDigitaCaptureMode,
    kDigitaLandscape
} TBTNDigitaButtonId;

// Kodak DC220, DC260, & DC265 button IDs */
#define kSoftkeyLeft   					14
#define kOverlayButton 					16
#define kDownArrow     					30
#define kRightArrow    					28
#define kLeftArrow     					29
#define kUpArrow       					31
#define kRecordButton  					17
#define kShutter2      					 9
#define kShutter1      					10
#define kZoomIn        					26
#define kZoomOut       					27
#define kSoftkeyRight  					12
#define kSoftkeyMid    					13
#define kMenuButton    					25
#define kPowerEvent    					11
#define kDiskEvent     					102
#define kSleepEvent   					103
#define kStatusLCDEvent    				104
#define kAVJackEvent   					105
#define kStatusLCDBatteryStatusEvent  	106
#define kStatusLCDCFAnimationEvent  	107
#define kMode0Button   					23
#define kMode1Button   					22
#define kMode2Button   					21
#define kMode3Button   					20
#define kShutterHome    				 8
#define kInstantReview  				116
#define kSpare2        					124
#define kSpare1        					125
#define kLCDStatus1    					126
#define kLCDStatus2    					127
#define kPortrait      					128
#define kLandscape     					129
#define kLCDOnOff      					130
#define kAlertEvent    					1100

/* Minolta button IDs */
#define kMinoltaLCDOnOff				  0
#define kMinoltaPowerEvent				  1
#define kMinoltaShutter2				  2
#define kMinoltaShutter1				  3
#define kMinoltaMode3Button				  4 
#define kMinoltaMode2Button				  5
#define kMinoltaMode0Button				  6 
#define kMinoltaMode1Button				  7
#define kMinoltaUpArrow					  8
#define kMinoltaDownArrow				  9
#define kMinoltaLeftArrow				 10
#define kMinoltaRightArrow				 11
#define kMinoltaSoftkeyRight			 12
#define kMinoltaSoftkeyMid				 13
#define kMinoltaSoftkeyLeft				 14
#define kMinoltaMenuButton				 16
#define kMinoltaOverlayButton			 17
#define kMinoltaStatusButton			 18
#define kMinoltaRecordButton			 19
#define kMinoltaMacroButton				 21
#define kMinoltaAVJackButton			 22
#define kMinoltaACJackButton			 23
#define kMinoltaDiskEvent    			102

/* Digita Common Structures */
typedef struct {
	char fPName[4];
	long fType;
	char fStr[32];
} TPARMNameTypeValue;
typedef TPARMNameTypeValue *TPARMNameTypeValuePtr;

typedef enum {
    kButtonClassEvent = 2,
} TEMEventClass;

typedef struct {
	unsigned short		fEvClass;
	unsigned long		fEvModifiers;
	long 				fPosition;
	long    			fButtonIndex;
	long				fLength;
	void *				fDataPtr;
	void *				fDeallocProc;
} TEMEventRecord;
typedef TEMEventRecord *TEMEventRecordPtr;

/* Common Digita function prototypes */
extern void  (*GMInitGraf)(void *);
extern void  (*GMInitFonts)(void);
extern short (*AMGetSelfAppID)(char * appID);
extern short (*EMOpen)(const char appID, int signo);
extern short (*EMGetEvent)(const char appID, TEMEventRecordPtr *message);
extern short (*EMReleaseEventRecord)(TEMEventRecordPtr message);
extern short (*MMNewAlignedPtr)(unsigned long size, unsigned long alignment, char *p);
extern short (*MMDisposePtr)(char * p);
extern short (*PARMGetProductInfo) (char *tag, TPARMNameTypeValuePtr ntvp);
extern unsigned long (*PMPowerDown)(unsigned long deepSleepTime);

/* Minolta & Kodak DC220, DC260, DC265 */
extern short (*LMEnableLCDController)(void);
extern short (*LMSetupBuffers)(unsigned long *lcdBuffer, unsigned long *displayBuffer, char interlace);
extern short (*LMSwitchBuffer)(unsigned long *lcdBuffer);

/* Kodak DC290 */
extern void (*LMSetUpInterlacedMode)(unsigned long *lcdPtr, unsigned long *displayPtr);

/* HP C500 & Kodak DC290 */
extern void (*LMAllocateBuffers)(void);
extern void (*LMSwitchNormalMode)(void);
extern void (*LMSwitchToNextLiveviewFrame)(void);
extern void (*LMSwitchLiveviewMode)(void);
extern char * (*LMGetNextLiveviewFrame)(void);
extern char * (*LMGetCurrentLiveviewFrame)(void);
extern short (*AMAppInit)(long appStyle);
extern void (*AMAppExit)(const char appID);

/* Kodak DC290 only */
extern unsigned long (*SUPowerDown)(unsigned long deepSleepTime);
extern long CreateSymtbl(void *);
extern long EmptySymtbl(void);
extern void HYInit(void);
extern short (*CMInit) (void);

/* HP C500 only */
extern unsigned long pmPowerDown(unsigned long deepSleepTime);

extern unsigned long (*CAPowerDown)(unsigned long deepSleepTime);

/* Minolta 1500 EX only */
extern int (*MPUSendLens)(unsigned int value);

/* Kodak DC220, DC260, DC265, & DC290 only */
#define LED_VIEWFINDER 		0x00000000
#define LED_OFF 			0x00000200
extern int (*MPUSetLED)(unsigned int ledstat);
extern int (*MPUInit)(void);
extern int smMconStat;

/* DCAM 2K sram address, use for color table lookup */
#define PHYS_M_DPSRAM_MEM0      0x1c000000
#define	PHYS_TO_K1(x)			((unsigned)(x)|0xA0000000)
#define M_DPSRAM_MEM0       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0)
#define M_DPSRAM_MEM1       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0 + 1024)

#define M_CPM_MEM1       	0xff002000
#define M_CPM_MEM2       	0xff002400
#define M_CPM_MEM3       	0xff002800

#define strKodakVendorName						"Eastman Kodak Company"
#define strKodakDC220ProductName				"KODAK DIGITAL SCIENCE DC220"
#define strKodakDC260ProductName				"KODAK DIGITAL SCIENCE DC260"
#define strKodakDC265ProductName				"KODAK DC265 ZOOM DIGITAL CAMERA"
#define strKodakDC290ProductName				"KODAK DC290 ZOOM DIGITAL CAMERA"
#define strHPVendorName							"Hewlett Packard"
#define strHP2VendorName						"Hewlett-Packard"
#define strHPC500ProductName					"HP PhotoSmart C500"
#define strHPC618ProductName					"HP PhotoSmart C618"
#define strHPC615ProductName					"HP PhotoSmart C615"
#define strHPC912ProductName					"HP PhotoSmart C912"
#define strPENTAXVendorName						"PENTAX"
#define strPENTAXEI200ProductName				"PENTAX EI-200"
#define strPENTAXEI2000ProductName				"PENTAX EI-2000"
#define strMinoltaVendorName					"Minolta Co., Ltd."
#define strMinoltaDimage1500EXProductName		"Dimage EX"

#define kTypeKodak1 		0
#define kTypeKodak2 		1
#define kTypeHP1 			2
#define kTypeHP2 			4
#define kTypeMinolta1 		3

#endif	/* defined OSD_DEPEND_H */