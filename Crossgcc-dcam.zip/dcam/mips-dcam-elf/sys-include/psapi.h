#ifndef _WTYPES_H
#define _WTYPES_H

typedef struct _MODULEINFO {
    LPVOID lpBaseOfDll;
    DWORD SizeOfImage;
    LPVOID EntryPoint;
} MODULEINFO, *LPMODULEINFO;

#endif /*_WTYPES_H*/
