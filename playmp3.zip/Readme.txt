Playmp3 for Digita Readme
by James Surine 12/3/2000

Supported cameras:
Kodak DC220, DC260, DC265, and DC290.
No other cameras are currently supported

Installation:
To install playmp3 just copy the playmp3.cam file to the system folder on the compact flash card. If no system folder exists, create on the root or top directory of the compact flash card. Next, copy your mp3 files to the root directory of the compact flash card. The application will cycle through all .mp3 files it finds in the root directory. I would suggest using a compact flash card reader to access the compact flash because the Kodak USB & serial port mounting software is reliable for transfering non-picture files to non-photo directories.

Using playmp3:
To run the application power on the camera in review mode and select the playmp3.cam file in the right most menu (it's not initially visisible and you have to scroll over to see it). The camera will power off and you have to power the camera back on to launch the application. The application will begin playing music immeadiately. The program currently has no graphic UI so the display will be off. This is to preserve battery life and allow you to play music longer. I may add more of a UI later.

Only three buttons are active. The left softkey under the LCD display will advance to the next song. The right most softkey will pause and un-pause music. Finally the power button will turn off the camera and exit the application. The next time you power up the camera it will run the normal camera application inside the camera.

You can rename playmp3.cam to default.cam and the camera will start the playmp3 application when ever that compact flash card is inserted in the camera and when the camera is first powered on.

Known Issues:
The sound quality could be improved some, I think I am overdriving the speaker some. If you give it an invalid MP3 file it could hang the program.

That's all, hope you enjoy it.

-James Surine
xevious@holonet.net