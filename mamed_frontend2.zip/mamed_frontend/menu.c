/* Original Code by Dan */
/* Code revised by Stephen B. for MAMED */
/* This menu.c is for editing the Menu on which programs to load, have fun */
//#include <math.h>
#include "launcher.h"
#include "pcx.h"
#include "pvrutils.h"
#include "3dutils.h"

static int count;
static int state;

typedef struct {
	const char	*name;
	const char	*path;
	const char	*executable;
	const char	*text;
} menuoption_t;

#define DEBUG "/cd/"
/* #define DEBUG "/rd/" */

static const menuoption_t options[] = {
	{ "", "", "", "" },
	
	{ "MAMED Pack 1",
	  "",       /* normally where the directory is you put it for example as "directory" if it was cd/directory */
	  DEBUG"mamed1.klf",             /* this should tell it to load this klf file */
	  "Play : pacman, namco, nintendo, orca and nichibut" },       /* not really sure what to describe the MAMED pack 1 so all of them 
	                                           will be like this, James you may describe what it is if you want ;) */
	{ "MAMED Pack 2",
	  "",
	  DEBUG"mamed2.klf",
	  "Play : konami, thepit, vsystem" },
	  
	{ "MAMED Pack 3",
	  "",
	  DEBUG"mamed3.klf",
	  "Play : atari and other" },
	  
	{ "MAMED Pack 4",
	  "",
	  DEBUG"mamed4.klf",
	  "Play : sega and taito" },
	  
	{ "MAMED Pack 5",
	  "",
	  DEBUG"mamed5.klf",
	  "Play : technos and dataeast" },
	  
	{ "MAMED Pack 6",
	  "",
	  DEBUG"mamed6.klf",
	  "Play : midway, gottlieb, williams and tms" },
	  
	{ "MAMED Pack 7",
	  "",
	  DEBUG"mamed7.klf",
	  "Play : seibu and tad" },

	{ "MAMED Pack 8",
	  "",
	  DEBUG"mamed8.klf",
	  "Play : alpha and kaneko" },

    { "MAMED Pack 9",
	  "",
	  DEBUG"mamed9.klf",
	  "Play : snk and toaplan" },

    { "MAMED Pack 10",
	  "",
	  DEBUG"mamed10.klf",
	  "Play : deniam and nmk" },

    { "MAMED Pack 11",
	  "",
	  DEBUG"mamed11.klf",
	  "Play : stratvox and univers" },

    { "MAMED Pack 12",
	  "",
	  DEBUG"mamed12.klf",
	  "Play : atlus, dooyong and tong" },
	  
    { "MAMED Pack 13",
	  "",
	  DEBUG"mamed13.klf",
	  "Play : kyugo" },

    { "MAMED Pack 14",
	  "",
	  DEBUG"mamed14.klf",
	  "Play : sun, upl, berzerk, exidy, leland, suna, valadon, gaelco, meadows and vicdual" },

    { "MAMED Pack 15",
	  "",
	  DEBUG"mamed15.klf",
	  "Play : capcom, itech, gameplan, midw8080, phoenix, cave, psikyo, cinemar and gremlin" },

    { "MAMED Pack 16",
	  "",
	  DEBUG"mamed16.klf",
	  "Play : tehkan, zaccaria, cinemav, irem, comad, playmark, jaleco, seta, metro, venture, yunsung, zilec, epos and fuuki" },

    { "NEOMAMED",
	  "",
	  DEBUG"neomamed.klf",
	  "Play : neogeo" },

	{ "", "", "", "" }
};
static const int min_option = 1, max_option = 17;
static int cur_option = 1;

enum states { 
	STATE_WAITING,
	STATE_FADING,
	STATE_WRITING,
	STATE_CLEARING };

int menu_reload() {
	state = STATE_WAITING;
	popup_set_text_now(options[cur_option].text);

	
	return 0;
}

int menu_init() { return 0; }

void menu_shutdown() { }

static void menu_update() {
	popup_set_text(options[cur_option].text);
	popup_clear();
}

void menu_up() {
	if (cur_option > min_option)
		cur_option--;
	else
		cur_option = max_option;
	menu_update();
}

void menu_dn() {
	if (cur_option < max_option)
		cur_option++;
	else
		cur_option = min_option;
	menu_update();
}

void menu_prelaunch() {
}

static void set_path(const char *path) {
	char wd[256];
	int i;

	/* Get old working dir */
	strcpy(wd, fs->getwd());

	/* Find the second '/' */
	for (i=0; wd[i]; i++) {
		if (wd[i] == '/' && i > 0) {
			i++;
			strcpy(wd+i, path);
			break;
		}
	}
	if (wd[i] == 0) {
		printf("launcher: error, can't find real path from '%s'\r\n", fs->getwd());
		return;
	}

	printf("Setting new dir '%s'\r\n", wd);
	fs->chdir(wd);
}

void menu_launch() {
//	char wd[256];
//	strcpy(wd, fs->getwd());
//	set_path(options[cur_option].path);
	{
		uint32 hnd;
		
		/* Force a rescan of the CD, boot CD must have a roms directory for this to work */
		hnd = fs->open("/cd/", O_RDONLY | O_DIR);
		if (hnd) 
		{
			fs->ioctl(hnd, NULL, 0);
			fs->close(hnd);
		}
		
	    hnd = fs->open("/cd", O_RDONLY | O_DIR);
	    fs->close(hnd);
	}
	proc->load_and_exec(options[cur_option].executable, 0, NULL);
//	fs->chdir(wd);
}

void menu_frame() {
	float w, h, x1, y1, by;
	int i;

	h = 25*3+1;
	w = 12*25+2;
	x1 = 320.0f - w/2;
	y1 = 240.0f - h/2;
	draw_box(x1, y1, 1024.0f, w, h, 0.7f, 0.2f, 0.0f, 0.7f);

	x1 += 1; y1 += 1;
	for (i=cur_option-1; i<=cur_option+1; i++) {
		if (i == cur_option) by = y1;
		draw_string(x1, y1, 1025.0f, 1.0f, 1.0f, 1.0f, 1.0f,
			options[i].name, strlen(options[i].name));
		y1 += 25;
	}

	draw_box(x1-1, by-1, 1024.5f, w, 26.0f, 0.7f, 0.7f, 0.0f, 0.2f);
}


