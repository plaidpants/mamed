/* original code from Dan */
#ifndef __FONT_H
#define __FONT_H

#include "launcher.h"


int font_init();
void font_shutdown();

extern uint32 txr_font;

#define FONT_WIDTH 12
#define FONT_HEIGHT 24

/* Initialize the font texture */
int font_reload();

/* Draw one font character (6x12) */
void draw_char(float x1, float y1, float z1, float a, float r,
		float g, float b, int c);

/* draw len chars at string */
void draw_string(float x, float y, float z, float a, float r, float g,
		float b, char *str, int len);

/* draw a box (used by cursor and border, etc) (at 1.0f z coord) */
void draw_box(float x, float y, float z, float w, float h, float a, float r, float g, float b);

/* draw the cursor */
void draw_cursor(float x, float y, float z, float r, float g, float b);

/* send a header suitable for drawing text polygons */
void draw_text_header();

#endif	/* __FONT_H */
