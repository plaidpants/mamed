/* Original Code by Dan */
/* Revised for MAMED by Stephen B.*/
/* Took out sound code in main.c */
#include "launcher.h"

abi_fs_t *fs;
abi_ta_t *ta;
abi_thread_t *thd;
abi_maple_t *maple;
abi_process_t *proc;
abi_video_t *vid;

static int count = 0;
static float tube_bright = 0.0f;
int reload_volatile(int);

void main_frame() {
	ta->begin_render();

	/* Opaque list */
	if (count >= 60) {
		tube_frame(tube_bright);
		if (tube_bright < 1.0f)
			tube_bright+=1.0f/30.0f;
	} else {
		pvr_dummy_poly(TA_OPAQUE);
	}
	ta->commit_eol();

	/* Translucent list */
	particle_frame();
	if (count < 120) {
		logo_frame(1.0f, 1.0f);
		count++;
	} else {
		logo_frame(0.5f, 1.0f);
		menu_frame();
	}
	header_frame();
	popup_frame();
	ta->commit_eol();

	/* Render the frame */
	ta->finish_frame();
}

/************************************************************************/
void launch_frame(float zoom, float bright) {
	ta->begin_render();
	pvr_dummy_poly(TA_OPAQUE);
	ta->commit_eol();
	logo_draw(1.0f, bright, zoom);
	ta->commit_eol();
	ta->finish_frame();
}

void launch_go() {
	float zoom, bright;
	int vol;

	menu_prelaunch();
	
	/* Zoom us out */	
	zoom = 1.0f;
	bright = 1.0f;
	while (zoom < 32.0f) {
		launch_frame(zoom, bright);
		zoom += 32.0f / 30.0f;
		bright -= 1.0f / 30.0f;
		vol = (int)(bright * 255.0f); /*if anything doesn't work delete this line of code */
	}

	/* Blank the screen */
	pvr_blank_frame();
	pvr_blank_frame();
	pvr_blank_frame();

	/* Launch the program */
	menu_launch();

	/* Clear the screen again */
	pvr_blank_frame();
	pvr_blank_frame();
	pvr_blank_frame();

	/* Reload any volatile data (textures, etc) */
	reload_volatile(1);
}

/************************************************************************/

void mainloop() {
	uint8 mcont;
	cont_cond_t cond;
	int j, ncheck, nvmu, debounce;

	ncheck = thd->jiffies();
	nvmu = thd->jiffies() + 2;
	mcont = maple->first_controller();
	debounce = 0;
	while(1) {
		j = thd->jiffies();
		if (j > nvmu) {
			nvmu = j + 3;
			vmu_frame();

			if (j > ncheck) {
				ncheck = j + 2;
			}
		} else if (j > ncheck) {
			ncheck = j + 5;
			
			if (maple->cont_get_cond(mcont, &cond) < 0) {
				printf("error reading controller\r\n");
				continue;
			}

			if (debounce > 0) {
				debounce--; continue;
			}

			/* if (!(cond.buttons & CONT_START))
				break; */

			if (!(cond.buttons & CONT_A)) {
				launch_go();
				debounce = 2;
			}

			if (!(cond.buttons & CONT_DPAD_UP)) {
				menu_up();
				debounce = 2;
			}

			if (!(cond.buttons & CONT_DPAD_DOWN)) {
				menu_dn();
				debounce = 2;
			}
		}
		main_frame();
	}
}

/************************************************************************/

int reload_volatile(int re) {
	ta->txr_release_all();

	if (font_reload() < 0) return -1;
	thd->pass();
	if (particle_reload() < 0) return -1;
	thd->pass();
	if (logo_reload() < 0) return -1;
	thd->pass();
	if (tube_reload() < 0) return -1;
	thd->pass();
	if (header_reload() < 0) return -1;
	thd->pass();
	if (popup_reload() < 0) return -1;
	thd->pass();
	if (menu_reload() < 0) return -1;

	return 0;
}

int main(int argc, char **argv) {
	printf("Launcher main entered\r\n");

	OPEN_LIB(ta, "ta");
	OPEN_LIB(fs, "fs");
	OPEN_LIB(thd, "thread");
	OPEN_LIB(maple, "maple");
	OPEN_LIB(proc, "process");
	OPEN_LIB(vid, "video");

	if (font_init() < 0) return -1;
	if (particle_init() < 0) return -1;
	if (logo_init() < 0) return -1;
	if (tube_init() < 0) return -1;
	if (header_init() < 0) return -1;
	if (popup_init() < 0) return -1;
	if (menu_init() < 0) return -1;
	if (reload_volatile(0) < 0) return -1;
	vmu_init();

	mainloop();

	menu_shutdown();
	popup_shutdown();
	header_shutdown();
	tube_shutdown();
	logo_shutdown();
	particle_shutdown();
	font_shutdown();

	/* printf("launcher: shutting down sound server\r\n");
	sndsrv->shutdown();
	do {
		sndsrv = lib_open("sndsrv");
		if (sndsrv) thd->pass();
	} while (sndsrv != NULL); */

	printf("launcher: finished\r\n");
	
	return 0;
}

