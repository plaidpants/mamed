/* Original Code By Dan */
//#include <math.h>
#include "launcher.h"
#include "pcx.h"
#include "pvrutils.h"
#include "3dutils.h"

static uint32 txr_title;

static float title_x;

/* void img_to_alpha(uint16 *img, int w, int h) {
	register uint32 r, g, b, a, i;
	
	for (i=0; i<w*h; i++) {
		a = ((img[i] & 0x07e0) >> 5) >> 2;
		if (a > 15) a = 15;
		img[i] = (a<<12) | 0xfff;
	}
} */

int header_init() { return 0; }

int header_reload() {
	Image *img;
	int i;

	txr_title = ta->txr_allocate(256*64*2);

	img = pcx_load("title.pcx");
	if (img == NULL) {
		printf("can't load title image\r\n");
		return -1;
	}
	ta->txr_load(txr_title, img->pixel_data, 256*64*2);
	pcx_free(img);
	img_to_alpha(ta->txr_map(txr_title), 256, 64);

	title_x = 640.0f;

	return 0;
}

void header_shutdown() { }

static void draw_one(float x, float y, float z, float a, float r, float g, float b) {
	vertex_ot_t v;
	float x1, y1, x2, y2, w, h;

	w = 256.0f;
	h = 64.0f;

	x1 = x; y1 = y;
	x2 = x1+w; y2 = y+h;

	v.flags = TA_VERTEX_NORMAL;
	v.x = x1;
	v.y = y2;
	v.z = z;
	v.u = 0.0f; v.v = 1.0f;
	v.a = a; v.r = r; v.g = g; v.b = b;
	v.oa = v.or = v.og = v.ob = 0.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.x = x1;
	v.y = y1;
	v.v = 0.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.x = x2;
	v.y = y2;
	v.u = v.v = 1.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.flags = TA_VERTEX_EOL;
	v.x = x2;
	v.y = y1;
	v.v = 0.0f;
	ta->commit_vertex(&v, sizeof(v));
}

void header_frame() {
	int i;
	poly_hdr_t poly;

	ta->poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444,
		256, 64, txr_title, TA_NO_FILTER);
	ta->commit_poly_hdr(&poly);

	draw_one(title_x, 24.0f, 512.0f, 1.0f - (title_x / 640.0f),
		1.0f, 1.0f, 1.0f);

	if (title_x > 24.0f) {
		title_x -= 4.0f;
	}
}


