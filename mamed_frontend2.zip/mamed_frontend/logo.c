/* Original Code by Dan */
/* Revised for MAMED by Stephen B. */
//#include <math.h>
#include "launcher.h"
#include "pcx.h"
#include "pvrutils.h"
#include "3dutils.h"

static uint32 txr_c, txr_a;

static float scale, svel, rvel;
static int rot, pause, paused;

/* void img_to_alpha(uint16 *img, int w, int h) {
	register uint32 r, g, b, a, i;
	
	for (i=0; i<w*h; i++) {
		a = ((img[i] & 0x07e0) >> 5) >> 2;
		if (a > 15) a = 15;
		img[i] = (a<<12) | 0xfff;
	}
} */

int logo_reload() {
	Image *img;
	int i;

	txr_c = ta->txr_allocate(256*256*2);
	txr_a = ta->txr_allocate(256*256*2);

	img = pcx_load("calogo_c.pcx");
	if (img == NULL) {
		printf("can't load calogo_c image\r\n");
		return -1;
	}
	txr_twiddle_copy(img->pixel_data, img->width, img->height, txr_c,
		256, 256, 0);
	pcx_free(img);
	img_to_alpha(ta->txr_map(txr_c), 256, 256);

	img = pcx_load("calogo_a.pcx");
	if (img == NULL) {
		printf("can't load calogo_a image\r\n");
		return -1;
	}
	txr_twiddle_copy(img->pixel_data, img->width, img->height, txr_a,
		256, 256, 0);
	pcx_free(img);
	img_to_alpha(ta->txr_map(txr_a), 256, 256);

	return 0;
}

int logo_init() {
	scale = 5.0f;
	svel = 0.01f;
	rot = 0;
	rvel = 1.0f;
	paused = 0;

	return 0;
}

void logo_shutdown() { }

static void rotate2d(float *x, float *y, int rot) {
	float tx, ty;

	tx = (fcos(rot) * *x - fsin(rot) * *y);
	ty = (fcos(rot) * *y + fsin(rot) * *x);

	*x = tx; *y = ty;
}

static void draw_one(float x, float y, float z, float scale, float a, float r, float g, float b, int rot) {
	vertex_ot_t v;
	float tx, ty, x1, y1, x2, y2, x3, y3, x4, y4, w, h;

	w = 256.0f * scale / 2.0f;
	h = 256.0f * scale / 2.0f;

	x1 = - w; y1 = + h;
	x2 = - w; y2 = - h;
	x3 = + w; y3 = + h;
	x4 = + w; y4 = - h;

	rotate2d(&x1, &y1, rot);
	rotate2d(&x2, &y2, rot);
	rotate2d(&x3, &y3, rot);
	rotate2d(&x4, &y4, rot);

	x1 += x; y1 += y;
	x2 += x; y2 += y;
	x3 += x; y3 += y;
	x4 += x; y4 += y;

	v.flags = TA_VERTEX_NORMAL;
	v.x = x1;
	v.y = y1;
	v.z = z;
	v.u = 0.0f; v.v = 1.0f;
	v.a = a; v.r = r; v.g = g; v.b = b;
	v.oa = v.or = v.og = v.ob = 0.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.x = x2;
	v.y = y2;
	v.v = 0.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.x = x3;
	v.y = y3;
	v.u = v.v = 1.0f;
	ta->commit_vertex(&v, sizeof(v));

	v.flags = TA_VERTEX_EOL;
	v.x = x4;
	v.y = y4;
	v.v = 0.0f;
	ta->commit_vertex(&v, sizeof(v));
}

void logo_draw(float alpha, float bright, float sc) {
	int i;
	poly_hdr_t poly;

	ta->poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444_TWID,
		256, 256, txr_c, TA_BILINEAR_FILTER);
	ta->commit_poly_hdr(&poly);

	/* draw_one(320.0f, 240.0f, 1.2f, 
		scale,
		scale * 0.95f, 0.44f, 0.57f, 0.8f, rot); */
	draw_one(320.0f, 240.0f, 512.0f + 1.2f, 
		sc,
		alpha * 0.95f, bright*1.0f, 0.0f, 0.0f, rot);

	ta->poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444_TWID,
		256, 256, txr_a, TA_BILINEAR_FILTER);
	ta->commit_poly_hdr(&poly);

	/* draw_one(320.0f, 240.0f, 1.2f, 
		scale,
		scale * 0.95f, 0.0f, 0.0f, 0.8f, 1024 - rot); */
	draw_one(320.0f, 240.0f, 512.0f + 1.2f, 
		sc,
		alpha * 0.95f, 0.0f, 0.0f, bright*1.0f, 1024 - rot);
}

void logo_frame(float a, float b) {
	logo_draw(a, b, scale);
	if (scale > 1.0f) { scale -= svel; svel += 0.005f; }
	if (scale <= 1.0f) {
		if (!paused) {
			pause = 120;
			paused = 1;
		}
		if (pause <= 0 && paused) {
			rot = (rot + ((int)rvel)) % 1024;
			if (rvel < 4.0f)
				rvel += 0.1f;
		} else pause--;
	}
}

