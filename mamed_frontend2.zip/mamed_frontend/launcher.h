/*Original Code by Dan */
/* Revised for MAMED by Stephen B. */
#ifndef __LAUNCHER_H
#define __LAUNCHER_H

//#include <stdio.h>		/* Global */
//#include <malloc.h>
//#include <math.h>

#include <kallisti/stdtypes.h>
#include <kallisti/fs.h>
#include <kallisti/libk.h>

#include <kallisti/abi/fs.h>
#include <kallisti/abi/thread.h>
#include <kallisti/abi/ta.h>
#include <kallisti/abi/maple.h>
#include <kallisti/abi/process.h>
#include <kallisti/abi/video.h>

#include "font.h"		/* Local */

#include "pcx.h"		/* Files from lib.zip */
#include "pvrutils.h"   /* Files from lib.zip */
#include "3dutils.h"    /* Files from lib.zip */

extern abi_fs_t *fs;
extern abi_thread_t *thd;
extern abi_ta_t *ta;
extern abi_maple_t *maple;
extern abi_process_t *proc;
extern abi_video_t *vid;

#endif	/* __LAUNCHER_H */

