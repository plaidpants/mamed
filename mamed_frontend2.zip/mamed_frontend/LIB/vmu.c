#include <kallisti/abi/maple.h>

extern abi_maple_t *maple;

void vmu_icon_init(const char *vmu_icon) {
	int x, y, xi, xb;
	uint8 bitmap[48*32/8];
	uint8 addr;

	addr = maple->first_vmu();
	if (!addr) return;

	memset(bitmap, 0, 48*32/8);
	for (y=0; y<32; y++)
		for (x=0; x<48; x++) {
			xi = x / 8;
			xb = 0x80 >> (x % 8);
			if (vmu_icon[(31-y)*48+(47-x)] == '.')
				bitmap[y*(48/8)+xi] |= xb;
		}
	
	maple->vmu_draw_lcd(addr, bitmap);
}
