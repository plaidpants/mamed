/* E3 Demo CD

   rand.c
   (c)2000-2001 Dan Potter

   Optimal random number function
*/

static char id[] = "E3CD $Id: rand.c,v 1.1 2000/12/29 03:37:20 bard Exp $";


static unsigned long seed=123;
#define RNDC 1013904223
#define RNDM 1164525

int rand() {
	seed = seed * RNDM + RNDC;
	return seed;
}

int randnum(int limit) {
	int shift, i;
	
	for (i=0, shift=1; limit < shift; shift<<=1, i++)
		;
		
	return ((rand() >> shift) & 0x7fffffff) % limit;
}

