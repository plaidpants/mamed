/* Tryptonite

   3dutils.h
   (c)2000 Dan Potter and Jordan DeLong

   $Id: 3dutils.h,v 1.1 2000/12/29 03:37:20 bard Exp $

*/

#ifndef __3DUTILS_H
#define __3DUTILS_H

#include "matrix.h"

/* Sin/Cos, angles 0..1023, values (-1.0,1.0) */
extern float sintab[];
#define fsin(angle) sintab[(angle) % 1024]
#define fcos(angle) sintab[((angle)+256) % 1024]


/* Perspective transform constants */
#define ZNEAR		1.0f
#define ZFAR		100.0f

void td_reset();
void td_rotate_x(int r);
void td_rotate_y(int r);
void td_rotate_z(int r);
void td_rotate(int xr, int yr, int zr);
void td_translate(float x, float y, float z);
void td_scale(float x, float y, float z);
void td_project();
void td_transform_vectors(vector_t *vi, vector_t *vo, int veccnt, int skip);

#endif	/* __3DUTILS_H */
