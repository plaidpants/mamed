/* E3 Demo CD

   pcx.h
   (c)2000-2001 Dan Potter

   $Id$

*/

#ifndef __PCX_H
#define __PCX_H

#include <kallisti/stdtypes.h>

typedef struct {
	int	width, height;
	uint16	*pixel_data;
} Image;

Image *pcx_load(const char *fn);
void pcx_free(Image *pcx);

#endif	/* __PCX_H */
