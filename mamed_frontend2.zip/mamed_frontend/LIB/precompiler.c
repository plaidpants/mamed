/* Tryptonite

   precompiler.c
   (c)2000 Dan Potter

   Precompiler: this collects verteces for a scene or an object and then
   performs matrix operations on the whole thing, and optionally submits them
   to the TA.

*/

static char id[] = "TRYP $Id: precompiler.c,v 1.1 2001/01/02 06:22:10 bard Exp $";


#include <string.h>
#include "precompiler.h"
#include "3dutils.h"

#include <kallisti/abi/ta.h>
extern abi_ta_t *ta;

static uint8 *pc_buf = NULL;
static int pc_out = 0;
static int pc_size = 0;

/* Resets the precompiler for another scene/object */
void pc_reset(int size) {
	pc_out = 0;
	pc_size = size;
}

/* Appends a vertex to the scene buffer */
void pc_append(const void *data) {
	memcpy(pc_buf + pc_out, data, pc_size);
	pc_out += pc_size;
}

/* Transforms all verteces in the scene buffer */
void pc_transform_all() {
	/* This will cause a failure in the asm routine */
	if ((pc_out / pc_size) == 0)
		return;
	td_transform_vectors((vector_t *)(pc_buf + 4),
		(vector_t *)(pc_buf + 4), pc_out / pc_size, pc_size);
}

/* Submits all verteces in the scene buffer to the TA */
void pc_submit_all() {
	int i;

	for (i=0; i<(pc_out / pc_size); i++) {
		ta->commit_vertex((void*)(pc_buf + i*pc_size), pc_size);
	}
}

/* Init */
void pc_init() {
	if (pc_buf == NULL)
		pc_buf = malloc(512*1024);
	pc_out = 0;
}

/* Shutdown */
void pc_shutdown() {
	if (pc_buf != NULL) {
		free(pc_buf);
		pc_buf = NULL;
	}
}

