/* Original Code from Dan */
#include "launcher.h"

int font_init() { return 0; }
void font_shutdown() { }

uint32 txr_font;

#define FONT_WIDTH 12
#define FONT_HEIGHT 24

/* Initialize the font texture */
int font_reload() {
	uint16	*vram;
	int	x,y;
	Image	*img;

	txr_font = ta->txr_allocate(256*256*2);
	vram = (uint16*)ta->txr_map(txr_font);

/*	for (x=0; x<256*256; x++) {
		vram[x] = 0;
	}
	for (y=0; y<8; y++) {
		for (x=0; x<16; x++) {
			vid->bfont_draw(vram, 256, 0, y*16 + x);
			vram += 16;
		}
		vram += 23*256;
	} */

	img = pcx_load("font.pcx");
	if (img == NULL) {
		printf("can't load font image\r\n");
		return -1;
	}
	txr_twiddle_copy(img->pixel_data, img->width, img->height, txr_font,
		256, 256, 0);
	pcx_free(img);
	img_to_alpha(vram, 256, 256);
	
	return 0;
}

/* Draw one font character (6x12) */
void draw_char(float x1, float y1, float z1, float a, float r,
		float g, float b, int c) {
	vertex_ot_t	vert;
	int ix, iy;
	float u1, v1, u2, v2;

	if (c == ' ')
		return;
	
	ix = (c % 16) * 12;
	iy = (c / 16) * 24;
	u1 = ix * 1.0f / 256.0f;
	v1 = iy * 1.0f / 256.0f;
	u2 = (ix+12) * 1.0f / 256.0f;
	v2 = (iy+24) * 1.0f / 256.0f;

	vert.flags = TA_VERTEX_NORMAL;
	vert.x = x1;
	//vert.y = y1 + 16.0f;
	vert.y = y1 + FONT_HEIGHT;
	vert.z = z1;
	vert.u = u1;
	vert.v = v2;
	vert.dummy1 = vert.dummy2 = 0;
	vert.a = a;
	vert.r = r;
	vert.g = g;
	vert.b = b;
	vert.oa = vert.or = vert.og = vert.ob = 0.0f;
	ta->commit_vertex(&vert, sizeof(vert));
	
	vert.x = x1;
	vert.y = y1;
	vert.u = u1;
	vert.v = v1;
	ta->commit_vertex(&vert, sizeof(vert));
	
	vert.x = x1 + FONT_WIDTH;
	//vert.y = y1 + 16.0f;
	vert.y = y1 + FONT_HEIGHT;
	vert.u = u2;
	vert.v = v2;
	ta->commit_vertex(&vert, sizeof(vert));

	vert.flags = TA_VERTEX_EOL;
	vert.x = x1 + FONT_WIDTH;
	vert.y = y1;
	vert.u = u2;
	vert.v = v1;
	ta->commit_vertex(&vert, sizeof(vert));
}

/* draw len chars at string */
void draw_string(float x, float y, float z, float a, float r, float g,
		float b, char *str, int len) {
	int i;
	poly_hdr_t poly;
	
	ta->poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444_TWID, 256, 256, txr_font, 0 /* TA_BILINEAR_FILTER */);
	ta->commit_poly_hdr(&poly);

	for (i = 0; i < len; i++) {
		draw_char(x, y, z, a, r, g, b, str[i]);
		x += FONT_WIDTH;
	}
}

/* draw a box (used by cursor and border, etc) (at 1.0f z coord) */
void draw_box(float x, float y, float z, float w, float h, float a, float r, float g, float b) {
	poly_hdr_t poly;
	vertex_oc_t vert;

	ta->poly_hdr_col(&poly, TA_TRANSLUCENT);
	ta->commit_poly_hdr(&poly);

	vert.flags = TA_VERTEX_NORMAL;
	vert.x = x;
	vert.y = y+h-1;
	vert.z = z;
	vert.a = a;
	vert.r = r; vert.g = g; vert.b = b;
	ta->commit_vertex(&vert, sizeof(vert));

	vert.y = y;
	ta->commit_vertex(&vert, sizeof(vert));

	vert.x += w-1;
	vert.y += h-1;
	ta->commit_vertex(&vert, sizeof(vert));

	vert.flags = TA_VERTEX_EOL;
	vert.y -= h-1;
	ta->commit_vertex(&vert, sizeof(vert));
}

/* draw the cursor */
void draw_cursor(float x, float y, float z, float r, float g, float b) {
	poly_hdr_t poly;
	vertex_oc_t vert;
	static float alpha = 1.0f, dalpha = 0.05f;

	/* modify our alpha to give a little fading effect */
	alpha += dalpha;
	if (alpha >= 1.0f || alpha <= 0.0f)
		dalpha = -dalpha;

	draw_box(x, y, z, FONT_WIDTH, FONT_HEIGHT, alpha, r, g, b);
}

/* send a header suitable for drawing text polygons */
void draw_text_header() {
	poly_hdr_t poly;
	ta->poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444_TWID, 256, 256, txr_font, 0 /* TA_BILINEAR_FILTER */);
	ta->commit_poly_hdr(&poly);
}

