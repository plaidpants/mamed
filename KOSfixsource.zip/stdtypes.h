/* KallistiOS 1.0.0

   stdtypes.h
   (c)2000 Dan Potter
   
   $Id: stdtypes.h,v 1.5 2000/12/02 03:52:26 bard Exp $
*/

#ifndef __KALLISTI_STDTYPES_H
#define __KALLISTI_STDTYPES_H

#include <stddef.h>

/* Generic types */
typedef unsigned long long uint64;
typedef unsigned long uint32;
typedef unsigned short uint16;
typedef unsigned char uint8;
typedef signed long long int64;
typedef signed long int32;
typedef signed short int16;
typedef signed char int8;

/* Volatile types */
typedef volatile uint64 vuint64;
typedef volatile uint32 vuint32;
typedef volatile uint16 vuint16;
typedef volatile uint8 vuint8;
typedef volatile int64 vint64;
typedef volatile int32 vint32;
typedef volatile int16 vint16;
typedef volatile int8 vint8;

/* another format for type names */
typedef unsigned char	u_char;
typedef unsigned short	u_short;
typedef unsigned int	u_int;
typedef unsigned long	u_long;
typedef unsigned short	ushort;
typedef unsigned int	uint;

/* File-specific types */
typedef size_t ssize_t;
typedef size_t off_t;

#define NULL 0
#endif	/* __KALLISTI_STDTYPES_H */

