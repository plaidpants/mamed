#include "osd_depend.h"

#include "doomdef.h"

#include "m_argv.h"
#include "d_main.h"
#include "mqueue.h"
#include "ctype.h"
#include "sys/fcntlcom.h"

unsigned char    			altAppID;
extern int singletics;

int lastButtonID = 0;
int lastButtonState = 0;
int doomTaskID = 0;
int cycle = 0;
int toggle = 0;

mqd_t event_mq = 0;

void EventTask(void)
{
	TEMEventRecordPtr	digita_event;
	short result;
	int buttomMsg;
	
	while(1)
	{
		if((result = EMGetEvent( altAppID, &digita_event )) == 0)
		{
			if (digita_event->fEvClass == kButtonClassEvent)
			{
		    	switch(digita_event->fButtonIndex)
		    	{
		    		case kDigitaUpArrow:
						lastButtonID = KEY_UPARROW;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaLeftArrow:
						lastButtonID = KEY_LEFTARROW;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaRightArrow:
						lastButtonID = KEY_RIGHTARROW;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaDownArrow:
						lastButtonID = KEY_DOWNARROW;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaSoftKey1:
				    	if (digita_event->fPosition)
				    	{
							lastButtonID = '1' + cycle;
							lastButtonState = ev_keydown;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
		 					taskDelay(1);
							lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
		 					cycle = (cycle+1)%7;
	 					}
						break;
					case kDigitaSoftKey2:
						lastButtonID = KEY_RSHIFT;
				    	if (digita_event->fPosition)
				    	{
				    		toggle = 1 - toggle;
					    	if (toggle)
								lastButtonState = ev_keydown;
							else
								lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
		 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
		 				}
						break;
					case kDigitaSoftKey3:
						lastButtonID = KEY_TAB;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaOverlay:
					case kDigitaLCDOnOff:
						lastButtonID = KEY_EQUALS;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						lastButtonID = 'y';
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						lastButtonID = KEY_ENTER;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaMenu:
						lastButtonID = KEY_ESCAPE;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaZoomIn:
						lastButtonID = ' ';
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaZoomOut:
						lastButtonID = KEY_RCTRL;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
					case kDigitaRecord:
						lastButtonID = KEY_MINUS;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;

					case kDigitaPowerOnOff:
						taskSuspend(doomTaskID);
						SUPowerDown(0);
						
						// Wait for power off
						while(1)
							taskDelay(10);
						break;

					case kDigitaShutter2:
						lastButtonID = KEY_F1;
				    	if (digita_event->fPosition)
							lastButtonState = ev_keydown;
						else
							lastButtonState = ev_keyup;
						buttomMsg = lastButtonID | (lastButtonState << 8);
	 					mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
						break;
						
					case kDigitaReviewMode:
					case kDigitaCaptureMode:
					case kDigitaPlayMode:
					case kDigitaHostMode:
				    	if (digita_event->fPosition)
				    	{
							lastButtonID = KEY_F11;
							lastButtonState = ev_keydown;
							buttomMsg = lastButtonID | (lastButtonState << 8);
							mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
							taskDelay(1);
							lastButtonState = ev_keyup;
							buttomMsg = lastButtonID | (lastButtonState << 8);
	 						mq_send(event_mq, &buttomMsg, sizeof(buttomMsg), 0);
	 					}
						break;

//					case kDigitaLCDStatus1:
//					case kDigitaLCDStatus2:
//					case kDigitaSpare1:
//					case kDigitaSpare2:
//					case kDigitaShutter2:
					default:
						break;
		    	}
	 		}
	 		result = EMReleaseEventRecord(digita_event);
	 	}
	}
}

void entry(void)
{
	short result;
	struct mq_attr mqa;
	mode_t mode;

	// initialized the MPU and wait for it to finish initializing
	MPUInit();
	while( !smMconStat )
		taskDelay(20);

	CMInit();
	HYInit();

	// Disable the blinking green viewfinder LED.
	MPUSetLED( LED_VIEWFINDER | LED_OFF );

	result = AMGetSelfAppID(&altAppID);
    result = EMOpen(altAppID, 0);

    myargc = 0; 
    myargv = 0; 
    
	singletics = 1;

    mqa.mq_flags = O_RDWR | O_CREAT;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	event_mq = mq_open("DOOMEVENTS",O_WRONLY | O_CREAT, mode, &mqa);
	
	doomTaskID = taskSpawn("DOOMD", 30, 0, 1024*16, (void*)D_DoomMain, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0);

	EventTask();
}


int access(const char * fname, int permissions)
{
	int fd;
	
	fd = (int)fopen(fname,"r");
	
	if (fd)
	{
		fclose((void*)fd);
		return 0;
	}
	
	return -1;
}

int strncasecmp(const char *inString1, const char *inString2, unsigned int length)
{
    char c1, c2;
    int walk;
    for (walk = 0; walk < length; walk++)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
    
    return 0;
}

int strcasecmp(const char *inString1, const char *inString2)
{
    char c1, c2;
    while (1)
    {
    	if (isupper(*inString1))
			c1 = tolower(*inString1);
		else
			c1 = *inString1;
		inString1++;
    	if (isupper(*inString2))
    		c2 = tolower(*inString2);
    	else
    		c2 = *inString2;
    	inString2++;
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (c1 == 0) return 0;
    }
}

void __eabi(void)
{
	printf("__eabi\n");
	taskSuspend(0);
}
