/* The DC290 is missing some GNU generated functions so I will force
   them to be included here. */

extern void __eabi(void);
extern void __divdi3(void);
 
void * missing[] = {
__eabi,
__divdi3,
};