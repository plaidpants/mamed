// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id:$
//
// Copyright (C) 1993-1996 by id Software, Inc.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// $Log:$
//
// DESCRIPTION:
//	DOOM graphics stuff for X11, UNIX.
//
//-----------------------------------------------------------------------------

static const char
rcsid[] = "$Id: i_x.c,v 1.6 1997/02/03 22:45:10 b1 Exp $";

#include <stdlib.h>

#include "doomstat.h"
#include "i_system.h"
#include "v_video.h"
#include "m_argv.h"
#include "d_main.h"

#include "doomdef.h"

#include "osd_depend.h"
#include "sys/fcntlcom.h"
#include "mqueue.h"

unsigned long 				*gLCD_buffer1 = 0;
unsigned long 				*gLCD_buffer2 = 0;
unsigned long 				*gLCD_buffer = 0;
unsigned long 				*current_display = 0;
unsigned long 				*pens823 = 0;

mqd_t event_receive_mq = 0;


//
// I_ShutdownGraphics
//
void I_ShutdownGraphics(void)
{
}


//
// I_StartFrame
//
void I_StartFrame (void)
{
    // er?
}


//
// I_GetEvent
//
void I_GetEvent(void)
{
    event_t doom_event;
    int buttomMsg;
    int priority;

	if (mq_receive(event_receive_mq, &buttomMsg, 4, &priority) != -1)
	{
		doom_event.type = buttomMsg >> 8;
	    doom_event.data1 = buttomMsg & 0xff;
	    
		D_PostEvent(&doom_event);
	}
}


//
// I_StartTic
//
void I_StartTic (void)
{
	/* Digita */
	// allow some event processing
	I_GetEvent();
}


//
// I_UpdateNoBlit
//
void I_UpdateNoBlit (void)
{
    // what is this?
}

//
// I_FinishUpdate
//
void I_FinishUpdate (void)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;

	if (current_display == gLCD_buffer1)
	{
		current_display = gLCD_buffer2;
	}
	else
	{
		current_display = gLCD_buffer1;
	}

	for (i = 0;i < 200;i++)
	{
		walk_display = current_display + 288*(i + (216-200)/2);
		walk_bitmap = screens[0] + 320*i + (320-288)/2;

		for (j = 0; j < 288; j++)
		{
			*walk_display++ = pens823[*walk_bitmap++];
		}
	}
	
	LMSwitchBuffer(current_display);
	
	I_GetEvent();
}


//
// I_ReadScreen
//
void I_ReadScreen (byte* scr)
{
    memcpy (scr, screens[0], SCREENWIDTH*SCREENHEIGHT);
}


//
// I_SetPalette
//

#define kMathScaleBits  10
#define kMathScale     (1 << kMathScaleBits)
#define kMaxValue      (kMathScale * 235)
#define kMinValue      (kMathScale * 16)
#define kMaxYValue     (kMathScale * 240)
#define kMinYValue     (kMathScale * 16)

#define kYRcoeff    ((long)( 0.2990 * kMathScale))
#define kYGcoeff    ((long)( 0.5870 * kMathScale))
#define kYBcoeff    ((long)( 0.1140 * kMathScale))

#define kCbRcoeff    ((long)( 0.1687 * kMathScale))
#define kCbGcoeff    ((long)( 0.3313 * kMathScale))
#define kCbBcoeff    ((long)( 0.5000 * kMathScale))

#define kCrRcoeff    ((long)( 0.5000 * kMathScale))
#define kCrGcoeff    ((long)( 0.4187 * kMathScale))
#define kCrBcoeff    ((long)( 0.0813 * kMathScale))

#define kRYcoeff     ((long)( 1.0000 * kMathScale))
#define kRCbcoeff    ((long)( 0.0000 * kMathScale))
#define kRCrcoeff    ((long)( 1.4020 * kMathScale))

#define kGYcoeff     ((long)( 1.0000 * kMathScale))
#define kGCbcoeff    ((long)( 0.3441 * kMathScale))
#define kGCrcoeff    ((long)( 0.7141 * kMathScale))

#define kBYcoeff     ((long)( 1.0000 * kMathScale))
#define kBCbcoeff    ((long)( 1.7720 * kMathScale))
#define kBCrcoeff    ((long)( 0.0000 * kMathScale))

#define PIN(x)   	((x) > kMaxValue  ? 235 : ((x) < kMinValue  ? 16 : (x >> kMathScaleBits)))
#define PINY(x)  	((x) > kMaxYValue ? 240 : ((x) < kMinYValue ? 16 : (x >> kMathScaleBits)))
#define PIN255(x)   ((x) > 255        ? 255 : ((x) < 0          ?  0 : 255))

unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) << 24) + (PINY(v0) << 16) + (PIN(v2) << 8) + (PINY(v0) << 0));
}

void I_SetPalette (byte* palette)
{
	// palette is 256 3 byte pairs of RGB
	int i;
	
	int r,g,b;
	
	pens823 = (unsigned long *)(M_CPM_MEM1);

    for (i=0 ; i<256 ; i++)
    {
		r = gammatable[usegamma][*palette++];
		g = gammatable[usegamma][*palette++];
		b = gammatable[usegamma][*palette++];

		pens823[i] = RGB2YCYC823(r,g,b);
    }
}


//
// I_InitGraphics
//

void I_InitGraphics(void)
{
    static int		firsttime=1;
	int i;
	struct mq_attr mqa;
	mode_t mode;
	
    if (!firsttime)
	return;
    firsttime = 0;

	// allocate 2 lcd buffers that are continuous so we can use them for interlaced
	// mode also
	MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);

	// clear the display
	gLCD_buffer1 = gLCD_buffer;
	for (i = 0;i < 288*216*2;i++)
	{
		*gLCD_buffer1++ = 0x80108010; // this is black in the YCC PPC 823 LCD world
	}
	
	// set the globals
	gLCD_buffer1 = gLCD_buffer;
	gLCD_buffer2 = gLCD_buffer + 288*216;
	
	// display the port
    LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
    
	// turn on the LCD
    LMEnableLCDController();

	pens823 = (unsigned long *)(M_CPM_MEM1);
	
    mqa.mq_flags = O_RDONLY | O_NONBLOCK;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	event_receive_mq = mq_open("DOOMEVENTS",O_RDONLY | O_NONBLOCK, mode, &mqa);
}