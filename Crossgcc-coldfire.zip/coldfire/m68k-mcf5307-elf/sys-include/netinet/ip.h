#ifndef _NETINET_IP_H
#define _NETINET_IP_H

#include <cygwin/ip.h>

#endif /* _NETINET_IP_H */
