#ifndef __SOUNDPRIVATE__
#define __SOUNDPRIVATE__

#define kSNDConfigureCodecOutput 0x00000001
#define kSNDConfigureCodecInput 0x00000002
#define kSNDHWPowerAndClockOff 0
#define kSNDHWClockOn 1
#define kSNDHWPowerAmpOn 2
#define kSNDHWPowerAmpOff 3
#define kSNDCodecFrameSize 2
#define kSNDDefaultRXASetup 0x0187
#define kSNDDefaultTXASetup 0x0187
#define kSNDChannelCount 4
#define kSNDStackSize (4 * 1024)
#define kSNDMessageCtlParamsCount 4
#define kSNDMaxMessageCount 16
#define kSND16BitSampleLengthMask (~(0x01UL))
#define kSND16MonoSampleSize 2
#define kSNDLPCMSamplesPerBlock 1
#define kSNDADPCMCompressionRatio 4
#define kSNDADPCMSamplesPerByte (kSNDADPCMCompressionRatio / kSND16MonoSampleSize) 
#define kSNDADPCMSamplesPerBlock (kSNDADPCMSamplesPerByte * kSNDADPCMSampleBlockSize)
#define kSND16MonoSampleToFrameMultiple (kSNDCodecFrameSize / kSND16MonoSampleSize)
#define kSNDCodecFrameControlSize (kSNDCodecFrameSize - kSND16MonoSampleSize)
#define kSNDDefaultNumberOfADPCMBlocksPerBD 1
#define kSNDDefaultNumberOfFramesPerBD (kSNDDefaultNumberOfADPCMBlocksPerBD * kSNDADPCMSamplesPerBlock * kSND16MonoSampleToFrameMultiple)
#define kSNDDefaultBDLength (kSNDDefaultNumberOfFramesPerBD * kSNDCodecFrameSize)
#define kSNDBDSyncOffset 0

#define kSMCBDInitTransparent 0x0000U	// no interrupt will be generated when this BD is serviced.
#define kSMCBDLastBDInTable 0x2000U		// this is the "W" (wrap or final BD in table) bit in the
#define kSMCBDInterrupt 0x1000U			// this is the "I" (interrupt may be generated) bit in the
#define kSMCBDReady 0x8000U				// this is the "R" (ready) bit in the SMC buffer descriptor.
#define kSMCBDLastByteInMessage 0x0800U	// this is the "L" (last) bit in the SMC buffer descriptor.
#define kSMCBDUnderrun	0x0002U			// this is the "UN" (underrun) bit in the SMC buffer descriptor.
#define kSMCBDOverrun	0x0002U			// this is the "OV" (overrun) bit in the SMC buffer descriptor.
#define kSMCBDReceiveEmpty 0x8000U		// this is the "E" bit in the receive buffer descriptor.
#define kSMCBDContinuousMode 0x0200U	// this is the "CM" bit in the SMC buffer descriptor.
#define kSMCEventBufferIsTransmitted 0x02	// this is the "TX" bit in the SMC Event register.
#define kSMCEventReceiveBufferIsClosed 0x01	// this is the "RX" bit in the SMC Event register.
#define kSMCEventUnderrun 0x10				// this is the TXE (underrun) bit in the SMC Event register.
#define kSMCEventBusy 0x04					// this is the BSY (busy condition) bit in the SMC Event register.
#define kSMC8BitTransparentNormal 0x3930U
#define kSMC16BitTransparentNormal 0x7B30U	// 16 bit data, reversed data, transmit low address byte first (CHRP821).
#define kSMCEnableTransmitter 0x0002U
#define kSMCEnableReceiver 0x0001U

#define kUCodeOffset 0xD00
#define kSMC2TxBDOffset (kUCodeOffset + 0x0060)	
#define	kSMC2TxBD(dprBase) ((volatile unsigned short *)(dprBase + kSMC2TxBDOffset))	

#define CISR(base) ((volatile unsigned long *) (base + 0x094C))
#define SMCE2(base) ((volatile unsigned char *) (base + 0x0A96))
#define SMCM2(base) ((volatile unsigned char *) (base + 0x0A9A))
#define SMCMR2(base) ((volatile unsigned short *) (base + 0x0A92))
#define MPC860_DPRAM_BASE(base) (base + 0x2000)

#define IV_SMC2_PIP 35
#define CISR_SMC2_PIP 8

typedef struct TAUDBufferDescriptor
{
	unsigned short	fStatus				__attribute ((packed));
	unsigned short	fDataLength			__attribute ((packed));
	unsigned char	*fBufferPointer		__attribute ((packed));
} TAUDBufferDescriptor;

/* prototypes */
extern void SNDSMC2InterruptHandler(void);
extern short sndConfigureCodec(unsigned long configure);
extern short sndOpenCodec(void);
extern short sndCloseCodec(void);
extern short sndHWPowerCodec(unsigned int n);
extern short sndHWSetBilevelVolume(unsigned char volumeFull);
extern short sndMuteAudio(unsigned char muteOn);
extern short sndInitCodecTransmit(void);
extern short sndCloseCodecTransmit(void);

/* Unity and 290 */
extern void AUD1InterruptHandler(void *, void *);
extern short AUDConfigureCodec(unsigned long configure);
extern short AUDOpenCodec(void);
extern short AUDCloseCodec(void);
extern short AUDPowerCodec(unsigned int n);
extern short AUDHWSetBilevelVolume(unsigned char volumeFull);
extern short AUDMuteAudio(unsigned char muteOn);
extern short AUDInitCodecTransmit(void);
extern short AUDCloseCodecTransmit(void);

#endif	/* __SOUNDPRIVATE__	*/