
#include <ID3.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

const char *  V2TagId = "ID3";
#define V2TAGIDLEN 3
#define V2VERLEN 2
#define V2FLAGLEN 1
#define V2TAGSIZELEN 4
#define V2HEADERLEN (V2TAGIDLEN + V2VERLEN + V2FLAGLEN + V2TAGSIZELEN)

#define V2VER3 0x03
#define V2EXTENDEDHEADERMASK 0x40

#define V2EXHEADSIZELEN 4

// Defined for V2 Frames.
#define V2FRAMEIDLEN 4
#define V2FRAMESIZELEN 4
#define V2FRAMEFLAGLEN 2
#define V2FRAMEHEADERLEN (V2FRAMEIDLEN+V2FRAMESIZELEN+V2FRAMEFLAGLEN)

#define V2FRAMECOMPRESSIONMASK   0x0080
#define V2FRAMEENCRYPTEDMASK     0x0040

#define V2TEXTFRAMEENCODELEN 1


// Tag identifiers:
const char * V2FrameTOAL = "TOAL";
const char * V2FrameTALB = "TALB";
const char * V2FrameTIT2 = "TIT2";
const char * V2FrameTMED = "TMED";
const char * V2FrameTIT1 = "TIT1";
const char * V2FrameTOPE = "TOPE";
const char * V2FrameTLEN = "TLEN";
const char * V2FrameTRCK = "TRCK";
const char * V2FrameTPE1 = "TPE1";

#define STANDARDENCODING 0x00


// Error Codes:
#define MP3_NOERR                   0
#define MP3_ERR_SONGTOOLONG       101
#define MP3_ERR_NOENCRYPTYET      102
#define MP3_ERR_NOCOMPRESSYET     103
#define MP3_ERR_TAGTOOBIGTOREAD   104
#define MP3_ERR_BADV2FRAMETAG     105
#define MP3_ERR_NOTEXTENCODEYET   106
#define MP3_ERR_TEXTTAGTOOBIG     107


#define BUFFERSIZE (32*1024)
static unsigned char parseBuf[BUFFERSIZE];

// To track the bytes read while processing the header.
static TagBytes = 0;



void InitBasicSongInfo(tBasicSongInfo * basicSongInfo)
{
  basicSongInfo->title = NULL;
  basicSongInfo->artist = NULL;
  basicSongInfo->album = NULL;
  basicSongInfo->songLength = 0;
}




unsigned int V2ItemSize (unsigned char * ID3v2Size)
{
  // ID3 tag size is in 4 bytes, format:
  // 0xxxxxxx 0xxxxxxx 0xxxxxxx 0xxxxxxx
  // Where "x" is significant.  All the "x"s make a 28 bit value for the length.
  // This weird format is done to avoid false "FF" sync patterns in the ID3
  // tag data.
  
  unsigned int Result;
  unsigned int Temp;
  unsigned int * IntInput = (unsigned int *)ID3v2Size;

  // Working LSB to MSB for the 4 bytes of the size.
  Temp = *IntInput & 0x0000007F;
  Result = (Temp << 1) | (*IntInput & 0xFFFFFF00);

  Temp = Result & 0x00007FFF;
  Result = (Temp << 1) | (*IntInput & 0xFFFF0000);

  Temp = Result & 0x007FFFFF;
  Result = (Temp << 1) | (*IntInput & 0xFF000000);

  Result = ((Result << 1) >> 4);

  return (Result);
}



// Returns TRUE if the tag is an accurate ID3 frame tag.
char ValidID3FrameTag(char * ID3Frame)
{
  if (! ( ((ID3Frame[0] >= 'A') && (ID3Frame[0] <= 'Z')) ||
		  ((ID3Frame[0] >= '0') && (ID3Frame[0] <= '9')) ) )
	return (FALSE);
  if (! ( ((ID3Frame[1] >= 'A') && (ID3Frame[1] <= 'Z')) ||
		  ((ID3Frame[1] >= '0') && (ID3Frame[1] <= '9')) ) )
	return (FALSE);
  if (! ( ((ID3Frame[2] >= 'A') && (ID3Frame[2] <= 'Z')) ||
		  ((ID3Frame[2] >= '0') && (ID3Frame[2] <= '9')) ) )
	return (FALSE);
  if (! ( ((ID3Frame[3] >= 'A') && (ID3Frame[3] <= 'Z')) ||
		  ((ID3Frame[3] >= '0') && (ID3Frame[3] <= '9')) ) )
	return (FALSE);

#ifdef qMP3_DEBUG
  printf("Tag Found: %c%c%c%c\n",ID3Frame[0],ID3Frame[1],ID3Frame[2],ID3Frame[3]);
#endif
  
  return (TRUE);
}





// Returns TRUE if the ID3 text frame text string is parsed into a destination area.
unsigned short LoadTextFrame (char ** dest, unsigned char * textFrame, unsigned int textFrameSize) {

  unsigned char  TextFrameEncoding;
  
  // Get Encoding:
  TextFrameEncoding = *textFrame;
  if (TextFrameEncoding != STANDARDENCODING)
	return (MP3_ERR_NOTEXTENCODEYET);   // Don't handle non-standard encoding

  if ((textFrameSize-V2TEXTFRAMEENCODELEN)>0)
	{
	  // Allocate space for the new text string:
	  if ( (*dest = malloc(textFrameSize-V2TEXTFRAMEENCODELEN+1)) == NULL )
		return (MP3_ERR_TEXTTAGTOOBIG);

	  // Copy the text data to the desitnation buffer.
	  strncpy(*dest, (textFrame+V2TEXTFRAMEENCODELEN), (textFrameSize-V2TEXTFRAMEENCODELEN));
	  (*dest)[(textFrameSize-V2TEXTFRAMEENCODELEN)] = '\0';
	}

  return (MP3_NOERR);
}




unsigned short V2HandledFrameTag (tBasicSongInfo *basicSongInfo, FILE * fp)
{
  unsigned short      Status = 0;
  unsigned char       FrameTag[4];
  unsigned int        FrameSize;
  unsigned short      FrameFlags;
  unsigned char *     FrameBuffer;
	
  // Store the information from the Frame Header
  memcpy (FrameTag,parseBuf,V2FRAMEIDLEN);
  FrameSize = *(unsigned int*)(parseBuf+(V2FRAMEIDLEN));
  FrameFlags = *(unsigned short*)(parseBuf+(V2FRAMEIDLEN+V2FRAMESIZELEN));

  // Return if the tag bytes read are not legal frame ID characters (spec 3.3)
  if (! ValidID3FrameTag(FrameTag))
	return (MP3_ERR_BADV2FRAMETAG);

  // Deal with compression if needed.
  if (FrameFlags & V2FRAMECOMPRESSIONMASK)
	return (MP3_ERR_NOCOMPRESSYET);  // Don't deal with compression yet.
  
  // Deal with encryption if needed.
  if (FrameFlags & V2FRAMEENCRYPTEDMASK)
	return (MP3_ERR_NOENCRYPTYET);  // Don't deal with encryption yet.

  // Read the frame into a newly allocated memory area.
  if ( (FrameBuffer = malloc(FrameSize)) == NULL )
	return (MP3_ERR_TAGTOOBIGTOREAD);

  // Load the data for the Frame
  fread(FrameBuffer, FrameSize, 1, fp);
  TagBytes += FrameSize;


  if (memcmp(FrameTag,V2FrameTALB,V2FRAMEIDLEN) == 0)
	Status = LoadTextFrame(&(basicSongInfo->album), FrameBuffer, FrameSize);
  else if (memcmp(FrameTag,V2FrameTOAL,V2FRAMEIDLEN) == 0)
	Status = LoadTextFrame(&(basicSongInfo->album), FrameBuffer, FrameSize);
  else if (memcmp(FrameTag,V2FrameTIT2,V2FRAMEIDLEN) == 0)
	Status = LoadTextFrame(&(basicSongInfo->title), FrameBuffer, FrameSize);
  else if (memcmp(FrameTag,V2FrameTOPE,V2FRAMEIDLEN) == 0)
	Status = LoadTextFrame(&(basicSongInfo->artist), FrameBuffer, FrameSize);
  else if (memcmp(FrameTag,V2FrameTPE1,V2FRAMEIDLEN) == 0)
	Status = LoadTextFrame(&(basicSongInfo->artist), FrameBuffer, FrameSize);
  else if (memcmp(FrameTag,V2FrameTLEN,V2FRAMEIDLEN) == 0) {
	char * characterSongLength;
	if ( (Status = LoadTextFrame(&characterSongLength, FrameBuffer, FrameSize)) == MP3_NOERR ) {
	  sscanf(characterSongLength,"%u",&(basicSongInfo->songLength));
	  free (characterSongLength);
	  characterSongLength = NULL;
	}
  }

  free (FrameBuffer);
  return (Status);
	
}


// Given an MP3 file, parse the header info.
void SetBasicSongInfo(tBasicSongInfo * basicSongInfo, char * filePath)
{
  unsigned short        Status;
  unsigned int          ID3TagSize;
  char       ExtendedHeader;
  FILE  *        fp;

  // Clean out the data currently in the structure.
  InitBasicSongInfo(basicSongInfo);

  fp = fopen(filePath, "r");

  // Parse the ID3v2 Header:
  
  fread(parseBuf,V2HEADERLEN,1,fp);
  if (memcmp(parseBuf, V2TagId, V2TAGIDLEN) != 0 ) {
#ifdef qMP3_DEBUG
	printf ("No ID3 header: %s\n",filePath);
#endif
	fclose (fp);
	return;
  }

  // Verify version "03"
  if (*(parseBuf+(V2TAGIDLEN)) != V2VER3) {
#ifdef qMP3_DEBUG
	printf ("Wrong ID3 Version: %s\n",filePath);
#endif
	fclose (fp);
	return;
  }


  // Find out if there is an extended header.
  ExtendedHeader = (*(parseBuf+(V2TAGIDLEN+V2VERLEN)) & V2EXTENDEDHEADERMASK);

  // Get the length of the ID3 Tag
  ID3TagSize = V2ItemSize(parseBuf+(V2TAGIDLEN+V2VERLEN+V2FLAGLEN));

  TagBytes = 0;
  // Read past the extended header if we need to:
  if (ExtendedHeader) {
	unsigned int Length;
	fread (parseBuf, V2EXHEADSIZELEN, 1, fp);
	TagBytes += V2EXHEADSIZELEN;
	Length = *((unsigned int*)parseBuf);
	fread (parseBuf, Length, 1, fp);
	TagBytes += Length;
  }

  while (TagBytes < ID3TagSize) {

	// Parse out each frame from the ID3 Tag.
	fread (parseBuf, V2FRAMEHEADERLEN, 1, fp);
	TagBytes += V2FRAMEHEADERLEN;
	if (Status = V2HandledFrameTag(basicSongInfo, fp)) {
#ifdef qMP3_DEBUG
	  printf("%s - Problem: %hu\n",filePath, Status);
#endif
	  if ( (Status == MP3_ERR_SONGTOOLONG) ||
		   (Status == MP3_ERR_TAGTOOBIGTOREAD) ||
		   (Status == MP3_ERR_BADV2FRAMETAG) ) {
		// Cannot recover yet, so break out.
#ifdef qMP3_DEBUG
		printf("Stopping\n");
#endif
		break;
	  }
	}
  }

  fclose (fp);
}


void ClearBasicSongInfo(tBasicSongInfo * basicSongInfo)
{
  // Deallocated memory:
  if (basicSongInfo->title != NULL) {
	free(basicSongInfo->title);
	basicSongInfo->title = NULL;
  }
  
  if (basicSongInfo->artist != NULL) {
	free(basicSongInfo->artist);
	basicSongInfo->artist = NULL;
  }
  
  if (basicSongInfo->album != NULL) {
	free(basicSongInfo->album);
	basicSongInfo->album = NULL;
  }
  
  basicSongInfo->songLength = 0;
}



void CopyBasicSongInfo(tBasicSongInfo * dest, tBasicSongInfo * source)
{
  // strdup the title
  if (source->title) {
	dest->title = malloc(strlen(source->title)+1);
	strcpy(dest->title, source->title);
  }
  else
	dest->title = NULL;

  // strdup the album
  if (source->album) {
	dest->album = malloc(strlen(source->album)+1);
	strcpy(dest->album, source->album);
  }
  else
	dest->album = NULL;

  // strdup the artist
  if (source->artist) {
	dest->artist = malloc(strlen(source->artist)+1);
	strcpy(dest->artist, source->artist);
  }
  else
	dest->artist = NULL;

  dest->songLength = source->songLength;
  
}


