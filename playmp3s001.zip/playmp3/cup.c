/*____________________________________________________________________________
	
	FreeAmp - The Free MP3 Player

        MP3 Decoder originally Copyright (C) 1995-1997 Xing Technology
        Corp.  http://www.xingtech.com

	Portions Copyright (C) 1998-1999 EMusic.com

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
	
	$Id: cup.c,v 1.1.2.2 2000/09/29 04:54:20 klamarch Exp $
____________________________________________________________________________*/

/****  cup.c  ***************************************************

MPEG audio decoder Layer I/II  mpeg1 and mpeg2
should be portable ANSI C, should be endian independent


mod  2/21/95 2/21/95  add bit skip, sb limiting

mods 11/15/95 for Layer I

******************************************************************/
/******************************************************************

       MPEG audio software decoder portable ANSI c.
       Decodes all Layer I/II to 16 bit linear pcm.
       Optional stereo to mono conversion.  Optional
       output sample rate conversion to half or quarter of
       native mpeg rate. dec8.c adds oupuut conversion features.

-------------------------------------
int audio_decode_init(MPEG_HEAD *h, int framebytes_arg,
         int reduction_code, int transform_code, int convert_code,
         int freq_limit)

initilize decoder:
       return 0 = fail, not 0 = success

MPEG_HEAD *h    input, mpeg header info (returned by call to head_info)
framebytes      input, mpeg frame size (returned by call to head_info)
reduction_code  input, sample rate reduction code
                    0 = full rate
                    1 = half rate
                    2 = quarter rate

transform_code  input, ignored
convert_code    input, channel conversion
                  convert_code:  0 = two chan output
                                 1 = convert two chan to mono
                                 2 = convert two chan to left chan
                                 3 = convert two chan to right chan
freq_limit      input, limits bandwidth of pcm output to specified
                frequency.  Special use. Set to 24000 for normal use.


---------------------------------
void audio_decode_info( DEC_INFO *info)

information return:
          Call after audio_decode_init.  See mhead.h for
          information returned in DEC_INFO structure.


---------------------------------
IN_OUT audio_decode(unsigned char *bs, void *pcmbuf)

decode one mpeg audio frame:
bs        input, mpeg bitstream, must start with
          sync word.  Caution: may read up to 3 bytes
          beyond end of frame.
pcmbuf    output, pcm samples.

IN_OUT structure returns:
          Number bytes conceptually removed from mpeg bitstream.
          Returns 0 if sync loss.
          Number bytes of pcm output.

*******************************************************************/

#include "cup.h"

#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include "mhead.h"		/* mpeg header structure */


#ifdef _MSC_VER
#pragma warning(disable: 4709)
#endif


/*-------------------------------------------------------
NOTE:  Decoder may read up to three bytes beyond end of
frame.  Calling application must ensure that this does
not cause a memory access violation (protection fault)
---------------------------------------------------------*/

/*====================================================================*/
/*----------------*/
DEC_INFO decinfo;		/* global for Layer III */

/*----------------*/
static float look_c_value[18];	/* built by init */

/*----------------*/
static int outbytes;
static int framebytes;
static int outvalues;
static int pad;
static int look_joint[16] =
{				/* lookup stereo sb's by mode+ext */
   64, 64, 64, 64,		/* stereo */
   2 * 4, 2 * 8, 2 * 12, 2 * 16,	/* joint */
   64, 64, 64, 64,		/* dual */
   32, 32, 32, 32,		/* mono */
};

/*----------------*/
static int max_sb;
static int stereo_sb;

/*----------------*/
static int nsb_limit = 6;
static int bit_skip;

/*----------------*/
static int bat[4][16];
static int ballo[64];		/* set by unpack_ba */
static unsigned int samp_dispatch[66];	/* set by unpack_ba */
static float c_value[64];	/* set by unpack_ba */

/*----------------*/
static unsigned int sf_dispatch[66];	/* set by unpack_ba */
static float sf_table[64];
static float cs_factor[3][64];

/*----------------*/
float sample[2304];		/* global for use by Later 3 */
static signed char group3_table[32][3];
static signed char group5_table[128][3];
static signed short group9_table[1024][3];

/*----------------*/
static int out_chans[5] =
{1, 2, 1, 1, 1};

/*----------------*/


// Sub-band translation routines.
// Need one routine for each of the layer, for each possibility
// of # of channel inputs.
void sbt_layer1and2_stereo(float *sample, short *pcm, int n);
void sbt_layer1and2_mono(float *sample, short *pcm, int n);
void sbt_layer3_stereo(float *sample, short *pcm, int n);
void sbt_layer3_mono(float *sample, short *pcm, int n);
SBT_FUNCTION sbt = sbt_layer1and2_stereo;
static SBT_FUNCTION sbt_table[2][3] =
{
  {
	sbt_layer1and2_mono,
	sbt_layer1and2_mono,
	sbt_layer3_mono
  },
  {
	sbt_layer1and2_stereo,
	sbt_layer1and2_stereo,
	sbt_layer3_stereo
  }  
};



typedef IN_OUT(*AUDIO_DECODE_ROUTINE) (unsigned char *bs, signed short *pcm);
IN_OUT L1audio_decode(unsigned char *bs, signed short *pcm);
IN_OUT L2audio_decode(unsigned char *bs, signed short *pcm);
IN_OUT L3audio_decode(unsigned char *bs, unsigned char *pcm);
static AUDIO_DECODE_ROUTINE audio_decode_routine = L2audio_decode;
static AUDIO_DECODE_ROUTINE decode_routine_table[3] =
{
  L1audio_decode,
   L2audio_decode,
   L3audio_decode
};



typedef int(*AUDIO_DECODE_INIT_ROUTINE) (MPEG_HEAD * h, int framebytes_arg);
int L1audio_decode_init(MPEG_HEAD * h, int framebytes_arg);
int L2audio_decode_init(MPEG_HEAD * h, int framebytes_arg);
int L3audio_decode_init(MPEG_HEAD * h, int framebytes_arg);
static AUDIO_DECODE_INIT_ROUTINE audio_decode_init_routine = L2audio_decode_init;
static AUDIO_DECODE_INIT_ROUTINE decode_init_routine_table[3] =
{
  L1audio_decode_init,
  L2audio_decode_init,
  L3audio_decode_init
};


/*======================================================================*/
/*======================================================================*/
/* get bits from bitstream in endian independent way */
static unsigned char *bs_ptr;
static unsigned long bitbuf;
static int bits;
static long bitval;

/*------------- initialize bit getter -------------*/
static void load_init(unsigned char *buf)
{
   bs_ptr = buf;
   bits = 0;
   bitbuf = 0;
}
/*------------- get n bits from bitstream -------------*/
static long load(int n)
{
   unsigned long x;

   if (bits < n)
   {				/* refill bit buf if necessary */
      while (bits <= 24)
      {
	 bitbuf = (bitbuf << 8) | *bs_ptr++;
	 bits += 8;
      }
   }
   bits -= n;
   x = bitbuf >> bits;
   bitbuf -= x << bits;
   return x;
}
/*------------- skip over n bits in bitstream -------------*/
static void skip(int n)
{
   int k;

   if (bits < n)
   {
      n -= bits;
      k = n >> 3;
/*--- bytes = n/8 --*/
      bs_ptr += k;
      n -= k << 3;
      bitbuf = *bs_ptr++;
      bits = 8;
   }
   bits -= n;
   bitbuf -= (bitbuf >> bits) << bits;
}
/*--------------------------------------------------------------*/
#define mac_load_check(n) if( bits < (n) ) {                           \
          while( bits <= 24 ) {               \
             bitbuf = (bitbuf << 8) | *bs_ptr++;  \
             bits += 8;                       \
          }                                   \
   }
/*--------------------------------------------------------------*/
#define mac_load(n) ( bits -= n,                    \
         bitval = bitbuf >> bits,      \
         bitbuf -= bitval << bits,     \
         bitval )


  
/*-------------------------------------------------------------------------*/
IN_OUT audio_decode(unsigned char *bs, signed short *pcm)
{
   return audio_decode_routine(bs, pcm);
}


static long steps[18] =
{
   0, 3, 5, 7, 9, 15, 31, 63, 127,
   255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535};



/*---------------------------------------------------------*/
static void table_init()
{
   int i, j;
   int code;

/*--  c_values (dequant) --*/
   for (i = 1; i < 18; i++)
      look_c_value[i] = 2.0F / steps[i];

/*--  scale factor table, scale by 32768 for 16 pcm output  --*/
   for (i = 0; i < 64; i++)
      sf_table[i] = (float) (32768.0 * 2.0 * pow(2.0, -i / 3.0));

/*--  grouped 3 level lookup table 5 bit token --*/
   for (i = 0; i < 32; i++)
   {
      code = i;
      for (j = 0; j < 3; j++)
      {
	 group3_table[i][j] = (char) ((code % 3) - 1);
	 code /= 3;
      }
   }
/*--  grouped 5 level lookup table 7 bit token --*/
   for (i = 0; i < 128; i++)
   {
      code = i;
      for (j = 0; j < 3; j++)
      {
	 group5_table[i][j] = (char) ((code % 5) - 2);
	 code /= 5;
      }
   }
/*--  grouped 9 level lookup table 10 bit token --*/
   for (i = 0; i < 1024; i++)
   {
      code = i;
      for (j = 0; j < 3; j++)
      {
	 group9_table[i][j] = (short) ((code % 9) - 4);
	 code /= 9;
      }
   }


}


/*---------------------------------------------------------*/
/* mpeg_head defined in mhead.h  frame bytes is without pad */
int audio_decode_init(MPEG_HEAD * h, int framebytes_arg)
{
   static int first_pass = 1;

   if (first_pass)
   {
      table_init();
      first_pass = 0;
   }

   // Set the SBT routine based on the layer, and output channels.
   sbt = sbt_table[CHANNELS_FROM_MODE(h->mode)-1][LAYER_FROM_LAYER_CODE(h->option)-1];
   
/* select decoder routine Layer I,II,III */
   audio_decode_routine = decode_routine_table[LAYER_FROM_LAYER_CODE(h->option)-1];


   // Select the decoder Initialization routine
   audio_decode_init_routine = decode_init_routine_table[LAYER_FROM_LAYER_CODE(h->option)-1];

   return audio_decode_init_routine(h, framebytes_arg);

}



/*---------------------------------------------------------*/
void audio_decode_info(DEC_INFO * info)
{
   *info = decinfo;		/* info return, call after init */
}



// Initialization for subband translation.
void sbt_init();


/*-------------------------------------------------------------------------*/
#include "cupl1.include"		/* Layer I */
#include "cupl2.include"      /* Layer II */
/*-------------------------------------------------------------------------*/


