//
//====================================================================================
#ifndef __MP3TASK_H__
#define __MP3TASK_H__

typedef enum  
{
	kMP3TaskInitial,
	kMP3TaskWaiting,
	kMP3TaskPlaying,
	kMP3TaskPaused,
	kMP3TaskEnding,
	kMP3TaskTerminated
} MP3TaskStates;

extern MP3TaskStates MP3TaskState;

char MP3TaskInit(void);
void StartPlaying(char * FilePath);
void StopPlaying(void);
void PausePlaying(void);
void ResumePlaying(void);
void StopMP3(void);

#endif


