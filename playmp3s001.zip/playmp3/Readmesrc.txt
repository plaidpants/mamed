The MP3Task operates as a independent task from any UI task.  The
UI task communicates with the MP3Task through the interface routines
declares in MP3Task.h

All the files should build with a very fundamental makefile.

Also, I just noticed that I set a 64K stack size for MP3Task. I don't
know if this is really required, I haven't tried it another way.

The decoder code has changed a bit from what I got from the net:

1. I use fixed point for the DCT calculation (but ONLY for the
   DCT calculation that we normally do - 8 point DCT, with
   1/4 REDUCTION (1/4 REDUCTION means the 44.1Khz sampling
   produces 11.025Khz output sampling).

2. All the optional code has be changed from run-time options
   to compile time options.  I did this to try to save space,
   but I'm not sure if it really made a difference.

3. The original code was organized a little strange, the Layer 3
   logic was kind of patched onto the Layer 1, and 2 code.  To
   get item 2. done, I had to incorporate Layer 3 code into
   the code more closely to the way Layer 1 and Layer 2 code was
   incorporated.  For example, there used to be a cup.c module
   that included code for layer 1 and 2.  Then a cupl3.c module
   was included that contained separately named modules for
   Layer 3 processing.  Now, there is a cupl1.c cupl2.c and
   cupl3.c module to keep things separate.

