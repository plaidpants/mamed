#ifndef __ID3_H_
#define __ID3_H_

typedef struct {
  char*       		title;
  char*       		artist;
  char*       		album;
  unsigned int      songLength;
} tBasicSongInfo;


void SetBasicSongInfo(tBasicSongInfo * basicSongInfo,  char * filePath);
void ClearBasicSongInfo(tBasicSongInfo * basicSongInfo);
void CopyBasicSongInfo(tBasicSongInfo * dest, tBasicSongInfo * source);


#endif
