/*____________________________________________________________________________
	
	FreeAmp - The Free MP3 Player

        MP3 Decoder originally Copyright (C) 1995-1997 Xing Technology
        Corp.  http://www.xingtech.com

	Portions Copyright (C) 1998 EMusic.com

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
	
	$Id: csbt.c,v 1.1.2.2 2000/09/29 04:49:55 klamarch Exp $
____________________________________________________________________________*/

/****  csbt.c  ***************************************************

MPEG audio decoder, dct and window
portable C

1/7/96 mod for Layer III

Ken Lamarche - 09/18/00 - Added fixed point routines for dct and
 window.  Used by fixed point layer III decoding.
  
******************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include "fixed_t.h"
#include "mhead.h"

void fdct32(float *, float *);
void fdct32_dual(float *, float *);
void fdct32_dual_mono(float *, float *);
void fdct16(float *, float *);
void fdct16fx(float *, fixed_t *);
void fdct16_dual(float *, float *);
void fdct16_dual_mono(float *, float *);
void fdct8(float *, float *);
void fdct8fx(float *, fixed_t *);
void fdct8_dual(float *, float *);
void fdct8_dual_mono(float *, float *);

void window(float *vbuf, int vb_ptr, short *pcm);
void window_dual(float *vbuf, int vb_ptr, short *pcm);
void window16(float *vbuf, int vb_ptr, short *pcm);
void window16fx(fixed_t *vbuf, int vb_ptr, short *pcm);
void window16_dual(float *vbuf, int vb_ptr, short *pcm);
void window8(float *vbuf, int vb_ptr, short *pcm);
void window8_fx(fixed_t *vbuf, int vb_ptr, short *pcm);
void window8_dual(float *vbuf, int vb_ptr, short *pcm);

void windowB(float *vbuf, int vb_ptr, unsigned char *pcm);
void windowB_dual(float *vbuf, int vb_ptr, unsigned char *pcm);
void windowB16(float *vbuf, int vb_ptr, unsigned char *pcm);
void windowB16_dual(float *vbuf, int vb_ptr, unsigned char *pcm);
void windowB8(float *vbuf, int vb_ptr, unsigned char *pcm);
void windowB8_dual(float *vbuf, int vb_ptr, unsigned char *pcm);


float *dct_coef_addr();

fixed_t *dct_coef_addrfx();

/*-------------------------------------------------------------------------*/
/* circular window buffers */
static signed int vb_ptr;
static signed int vb2_ptr;
static float vbuf[512];
static float vbuf2[512];

static fixed_t vbuffx[512];

float *dct_coef_addr();

extern fixed_t wincoeffx[264];
extern float wincoef[264];

/*======================================================================*/
static void gencoef()		/* gen coef for N=32 (31 coefs) */
{
   int p, n, i, k;
   double t, pi;
   float *coef32;
   fixed_t *coef32fx;

   coef32 = dct_coef_addr();
   coef32fx = dct_coef_addrfx();

   pi = 4.0 * atan(1.0);
   n = 16;
   k = 0;
   for (i = 0; i < 5; i++, n = n / 2) {
	 for (p = 0; p < n; p++, k++) {
	   t = (pi / (4 * n)) * (2 * p + 1);
	   coef32[k] = (float) (0.50 / cos(t));
	   coef32fx[k] = TOFIXED(coef32[k]);
	 }
   }
}
/*------------------------------------------------------------*/
void sbt_init()
{
   int i;
   static int first_pass = 1;

   if (first_pass)
   {
      gencoef();
      first_pass = 0;
   }

/* clear window vbuf */
   for (i = 0; i < 512; i++)
   {
      vbuf[i] = 0.0F;
      vbuf2[i] = 0.0F;
	  vbuffx[i] = 0;
   }
   vb2_ptr = vb_ptr = 0;

   // Set up fixed point window coefficient table:
   for (i = 0; i < 264; i++)
	 wincoeffx[i] = TOFIXED(wincoef[i]);
   
}



// SBT Routines for Layer 1 and 2:


#if     (qMP3_REDUCTION == FULL_SAMPLE)

#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default Case

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32_dual_mono(sample, vbuf + vb_ptr);
      window(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32(sample, vbuf + vb_ptr);
      window(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32_dual(sample, vbuf + vb_ptr);
      fdct32_dual(sample + 1, vbuf2 + vb_ptr);
      window_dual(vbuf, vb_ptr, pcm);
      window_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 64;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32(sample, vbuf + vb_ptr);
      fdct32(sample, vbuf2 + vb_ptr);
      window_dual(vbuf, vb_ptr, pcm);
      window_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 64;
   }
}
#endif



#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32_dual_mono(sample, vbuf + vb_ptr);
      windowB(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32(sample, vbuf + vb_ptr);
      windowB(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32_dual(sample, vbuf + vb_ptr);
      fdct32_dual(sample + 1, vbuf2 + vb_ptr);
      windowB_dual(vbuf, vb_ptr, pcm);
      windowB_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 64;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct32(sample, vbuf + vb_ptr);
      fdct32(sample, vbuf2 + vb_ptr);
      windowB_dual(vbuf, vb_ptr, pcm);
      windowB_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 64;
   }
}
#endif


#endif

#elif   qMP3_REDUCTION == HALF_SAMPLE

#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default Case
#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16_dual_mono(sample, vbuf + vb_ptr);
      window16(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16(sample, vbuf + vb_ptr);
      window16(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16_dual(sample, vbuf + vb_ptr);
      fdct16_dual(sample + 1, vbuf2 + vb_ptr);
      window16_dual(vbuf, vb_ptr, pcm);
      window16_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 32;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16(sample, vbuf + vb_ptr);
      fdct16(sample, vbuf2 + vb_ptr);
      window16_dual(vbuf, vb_ptr, pcm);
      window16_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 32;
   }
}
#endif


#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16_dual_mono(sample, vbuf + vb_ptr);
      windowB16(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16(sample, vbuf + vb_ptr);
      windowB16(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16_dual(sample, vbuf + vb_ptr);
      fdct16_dual(sample + 1, vbuf2 + vb_ptr);
      windowB16_dual(vbuf, vb_ptr, pcm);
      windowB16_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 32;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct16(sample, vbuf + vb_ptr);
      fdct16(sample, vbuf2 + vb_ptr);
      windowB16_dual(vbuf, vb_ptr, pcm);
      windowB16_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 32;
   }
}
#endif


#endif

#elif   qMP3_REDUCTION == QUARTER_SAMPLE
// Default Case
#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default Case
#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8_dual_mono(sample, vbuf + vb_ptr);
      window8(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8(sample, vbuf + vb_ptr);
      window8(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8_dual(sample, vbuf + vb_ptr);
      fdct8_dual(sample + 1, vbuf2 + vb_ptr);
      window8_dual(vbuf, vb_ptr, pcm);
      window8_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 16;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8(sample, vbuf + vb_ptr);
      fdct8(sample, vbuf2 + vb_ptr);
      window8_dual(vbuf, vb_ptr, pcm);
      window8_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 16;
   }
}
#endif


#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8_dual_mono(sample, vbuf + vb_ptr);
      windowB8(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8(sample, vbuf + vb_ptr);
      windowB8(vbuf, vb_ptr, pcm);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
   }
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer1and2_stereo(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8_dual(sample, vbuf + vb_ptr);
      fdct8_dual(sample + 1, vbuf2 + vb_ptr);
      windowB8_dual(vbuf, vb_ptr, pcm);
      windowB8_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 16;
   }
}
void sbt_layer1and2_mono(float *sample, short *pcm, int n)
{
   int i;

   for (i = 0; i < n; i++)
   {
      fdct8(sample, vbuf + vb_ptr);
      fdct8(sample, vbuf2 + vb_ptr);
      windowB8_dual(vbuf, vb_ptr, pcm);
      windowB8_dual(vbuf2, vb_ptr, pcm + 1);
      sample += 64;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 16;
   }
}
#endif


#endif

#endif






// SBT Routines for Layer 3


#if     (qMP3_REDUCTION == FULL_SAMPLE)

#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default
#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct32(sample, vbuf + vb_ptr);
      window(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	for (i = 0; i < 18; i++)
      {
		fdct32(sample, vbuf + vb_ptr);
		window_dual(vbuf, vb_ptr, pcm);
		sample += 32;
		vb_ptr = (vb_ptr - 32) & 511;
		pcm += 64;
      }
  else
	for (i = 0; i < 18; i++)
      {
		fdct32(sample, vbuf2 + vb2_ptr);
		window_dual(vbuf2, vb2_ptr, pcm + 1);
		sample += 32;
		vb2_ptr = (vb2_ptr - 32) & 511;
		pcm += 64;
      }
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct32(sample, vbuf + vb_ptr);
      window(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
	}
}
#endif


#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct32(sample, vbuf + vb_ptr);
      windowB(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	for (i = 0; i < 18; i++)
      {
		fdct32(sample, vbuf + vb_ptr);
		windowB_dual(vbuf, vb_ptr, pcm);
		sample += 32;
		vb_ptr = (vb_ptr - 32) & 511;
		pcm += 64;
      }
  else
	for (i = 0; i < 18; i++)
      {
		fdct32(sample, vbuf2 + vb2_ptr);
		windowB_dual(vbuf2, vb2_ptr, pcm + 1);
		sample += 32;
		vb2_ptr = (vb2_ptr - 32) & 511;
		pcm += 64;
      }
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct32(sample, vbuf + vb_ptr);
      windowB(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 32) & 511;
      pcm += 32;
	}
}
#endif


#endif

#elif   qMP3_REDUCTION == HALF_SAMPLE

#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default Case
#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++) {
	fdct16fx(sample, vbuffx + vb_ptr);
	window16fx(vbuffx, vb_ptr, pcm);
	sample += 32;
	vb_ptr = (vb_ptr - 16) & 255;
	pcm += 16;
  }
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	{
      for (i = 0; i < 18; i++)
		{
		  fdct16(sample, vbuf + vb_ptr);
		  window16_dual(vbuf, vb_ptr, pcm);
		  sample += 32;
		  vb_ptr = (vb_ptr - 16) & 255;
		  pcm += 32;
		}
	}
  else
	{
      for (i = 0; i < 18; i++)
		{
		  fdct16(sample, vbuf2 + vb2_ptr);
		  window16_dual(vbuf2, vb2_ptr, pcm + 1);
		  sample += 32;
		  vb2_ptr = (vb2_ptr - 16) & 255;
		  pcm += 32;
		}
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++) {
	fdct16fx(sample, vbuffx + vb_ptr);
	window16fx(vbuffx, vb_ptr, pcm);
	sample += 32;
	vb_ptr = (vb_ptr - 16) & 255;
	pcm += 16;
  }
}
#endif


#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct16(sample, vbuf + vb_ptr);
      windowB16(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	{
      for (i = 0; i < 18; i++)
		{
		  fdct16(sample, vbuf + vb_ptr);
		  windowB16_dual(vbuf, vb_ptr, pcm);
		  sample += 32;
		  vb_ptr = (vb_ptr - 16) & 255;
		  pcm += 32;
		}
	}
  else
	{
      for (i = 0; i < 18; i++)
		{
		  fdct16(sample, vbuf2 + vb2_ptr);
		  windowB16_dual(vbuf2, vb2_ptr, pcm + 1);
		  sample += 32;
		  vb2_ptr = (vb2_ptr - 16) & 255;
		  pcm += 32;
		}
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct16(sample, vbuf + vb_ptr);
      windowB16(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 16) & 255;
      pcm += 16;
	}
}
#endif


#endif

#elif   qMP3_REDUCTION == QUARTER_SAMPLE
// Default Case
#if     (qMP3_BIT_OUTPUT == q16_BIT_OUTPUT)
// Default Case
#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++) {
	fdct8fx(sample, vbuffx + vb_ptr);
	window8_fx(vbuffx, vb_ptr, pcm);
	sample += 32;
	vb_ptr = (vb_ptr - 8) & 127;
	pcm += 8;
  }
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	{
      for (i = 0; i < 18; i++)
		{
		  fdct8(sample, vbuf + vb_ptr);
		  window8_dual(vbuf, vb_ptr, pcm);
		  sample += 32;
		  vb_ptr = (vb_ptr - 8) & 127;
		  pcm += 16;
		}
	}
  else
	{
      for (i = 0; i < 18; i++)
		{
		  fdct8(sample, vbuf2 + vb2_ptr);
		  window8_dual(vbuf2, vb2_ptr, pcm + 1);
		  sample += 32;
		  vb2_ptr = (vb2_ptr - 8) & 127;
		  pcm += 16;
		}
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++) {
	fdct8fx(sample, vbuffx + vb_ptr);
	window8_fx(vbuffx, vb_ptr, pcm);
	sample += 32;
	vb_ptr = (vb_ptr - 8) & 127;
	pcm += 8;
  }
}
#endif


#elif   (qMP3_BIT_OUTPUT == q8_BIT_OUTPUT)

#if     (qMP3_OUTPUT_CHANNELS == MONO_OUTPUT)
// Default Case
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct8(sample, vbuf + vb_ptr);
      windowB8(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  sbt_layer3_stereo(sample, pcm, n);
}

#elif   (qMP3_OUTPUT_CHANNELS == STEREO_OUTPUT)
void sbt_layer3_stereo(float *sample, short *pcm, int n)
{
  int i;

  if (n == 0)
	{
      for (i = 0; i < 18; i++)
		{
		  fdct8(sample, vbuf + vb_ptr);
		  windowB8_dual(vbuf, vb_ptr, pcm);
		  sample += 32;
		  vb_ptr = (vb_ptr - 8) & 127;
		  pcm += 16;
		}
	}
  else
	{
      for (i = 0; i < 18; i++)
		{
		  fdct8(sample, vbuf2 + vb2_ptr);
		  windowB8_dual(vbuf2, vb2_ptr, pcm + 1);
		  sample += 32;
		  vb2_ptr = (vb2_ptr - 8) & 127;
		  pcm += 16;
		}
	}
}
void sbt_layer3_mono(float *sample, short *pcm, int n)
{
  // The init logic for this MP3 reader does special
  // processing if the input MP3 file is mono.  The init code
  // makes it look like the user has requested mono output.
  // Therefore, we can use the same code as if qMP3_OUTPUT_CHANNELS
  // was MONO_OUTPUT, and be asure that the buffer sizing is
  // accurate.
  int i;

  for (i = 0; i < 18; i++)
	{
      fdct8(sample, vbuf + vb_ptr);
      windowB8(vbuf, vb_ptr, pcm);
      sample += 32;
      vb_ptr = (vb_ptr - 8) & 127;
      pcm += 8;
	}
}
#endif


#endif

#endif




