
#ifndef FIXED_T_H
#define FIXED_T_H

// Converting floating point operations to 32 bit integer
// with implied . between bit 15 and 16.
#define FRACBITS 16
#define FRACUNIT (1<<FRACBITS)
typedef int   fixed_t;
// MAKEFIXED will take a constant like 4500000 and make the
// fixed point number that is 4 1/2 (the 32 bit pattern with 16
// fraction bits would be:
// ( 0000 0000 0000 0100.1000 0000 0000 0000 ) (note implied decimal).
#define MAKEFIXED(x) ((int)((((long long)x)<<FRACBITS)/10000000))

#define TOFLOAT(x) (((float)x)/(float)(FRACUNIT))
#define TOFIXED(f) ((int)(f*(float)(FRACUNIT)))
#define TOINT(i) (i>>FRACBITS)
fixed_t FixedMul ( fixed_t a, fixed_t b );
//fixed_t FixedDiv ( fixed_t a, fixed_t b );


#endif // FIXED_T_H


