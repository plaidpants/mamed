#include "osd_depend.h"
#include "MP3Task.h"
#include "dirent.h" // this is a local copy not the version in vxWorks

int				quitting = 0;
int 			camera_type = -1;
char 			altAppID;
unsigned short	lastButtonState;
unsigned short	lastButtonID;
int 			mainLoopTaskID;
DIR     		*b = 0;
char    		fname[200];
char			dname[200];
int 			*gLCD_buffer;

void openDirectory(char *dirpath)
{
    b = opendir(dirpath);
    strcpy(dname, dirpath);
}

char * getNextDirectoryEntry(void)
{
    struct dirent 	*c;
	int 			fid;
	
    if (b) 
    {
    	c = readdir(b);
		if (c)
		{
			strcpy(fname, dname);
			strcat(fname, c->d_name);
			fid = open(fname, O_RDONLY, 0);
			if (fid)
			{
				close(fid);
				return fname;
			}
		}
	}
	
	return 0;
}

char isMP3File(char * filepath)
{
	char * ext;
	
	ext = strrchr(filepath, '.');
	if (ext)
	{
		ext++;
		if (strcmp("MP3",ext) == 0)
		{
			return TRUE;
		}
	}
	
	return FALSE;
}

char * getNextMP3DirectoryEntry(void)
{
	char * filepath;
	
	do
	{
		filepath = getNextDirectoryEntry();
		
		if (filepath)
		{
			if (isMP3File(filepath))
			{
				return filepath;
			}
		}
	} while (filepath);
}

void closeDirectory(void)
{
    if (b) 
    {
		closedir(b);
		b = 0;
	}
}

void mainLoopTask(void)
{
	char * filepath;

	MP3TaskInit();

	while (!quitting)
	{
		openDirectory("/B/");
		do
		{
			filepath = getNextMP3DirectoryEntry();
			
			if (filepath)
			{
				StartPlaying(filepath);
				
				// wait for it to start playing
				while (MP3TaskState != kMP3TaskPlaying)
				{
					taskDelay(10);
				}
				
				// wait for it to finish
				while (MP3TaskState != kMP3TaskWaiting)
				{
					taskDelay(10);
					if (quitting)
					{
						StopPlaying();
					}

					if ((lastButtonID == kSoftkeyLeft) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak1))
					{
						// stop playing this song and skip to next song
						StopPlaying();
						lastButtonID = 0;
					}
					
					if ((lastButtonID == kSoftkeyRight) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak1)
						&& (MP3TaskState == kMP3TaskPaused))
					{
						// stop playing this song and skip to next song
						ResumePlaying();
						lastButtonID = 0;
					}
					
					if ((lastButtonID == kSoftkeyRight) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak1)
						&& (MP3TaskState == kMP3TaskPlaying))
					{
						// stop playing this song and skip to next song
						PausePlaying();
						lastButtonID = 0;
					}

					if ((lastButtonID == kDigitaSoftKey1) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak2))
					{
						// stop playing this song and skip to next song
						StopPlaying();
						lastButtonID = 0;
					}
					
					if ((lastButtonID == kDigitaSoftKey3) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak2)
						&& (MP3TaskState == kMP3TaskPaused))
					{
						// stop playing this song and skip to next song
						ResumePlaying();
						lastButtonID = 0;
					}
					
					if ((lastButtonID == kDigitaSoftKey3) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak2)
						&& (MP3TaskState == kMP3TaskPlaying))
					{
						// stop playing this song and skip to next song
						PausePlaying();
						lastButtonID = 0;
					}
				}
			}
		} while (filepath);
		closeDirectory();
	}
	
	StopMP3();
	
	// signal we are done
	quitting = 2;
}

void eventHandlerTask(void)
{
	short result;
	
	taskPrioritySet(taskIdSelf(), 29);

	while(TRUE)
	{
		TEMEventRecord *	event;

		while (TRUE)
		{
			if ((result = EMGetEvent( altAppID, &event )) != 0)
			{
				// event queue is empty
				taskDelay(30);
				break;
			}

			switch (event->fEvClass)
			{
				case kButtonClassEvent:
				{
					lastButtonState = event->fPosition;
					lastButtonID = event->fButtonIndex;
					
					if ((lastButtonID == kPowerEvent) 
						&& (lastButtonState) 
						&& (camera_type == kTypeKodak1))
					{
						taskSuspend(mainLoopTaskID);
						PMPowerDown(0);
						while(TRUE)
							taskDelay(10);
					}
					
					if ((lastButtonID == kDigitaPowerOnOff) 
						&& (lastButtonState == 0) 
						&& (camera_type == kTypeKodak2))
					{
						taskSuspend(mainLoopTaskID);
						SUPowerDown(0);
						while(TRUE)
							taskDelay(10);
					}
					
					if ((lastButtonID == kDigitaPowerOnOff) 
						&& (lastButtonState) // note difference, after button down, no more buttons
						&& (camera_type == kTypeHP2))
					{
						taskSuspend(mainLoopTaskID);
						/* HP's PMPowerDown() is not a function pointer, so call the function directly */
						SUPowerDown(0);
						while(TRUE)
							taskDelay(10);
					}
					break;
				}
				default:
				{
					break;
				}
			}

			result = EMReleaseEventRecord(event);
		}
	}
}

void detect_camera_type(void)
{
	short err = 0;
	TPARMNameTypeValue data;
	char vendor[50];
	char product[50];

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
	else if (strcmp( vendor, strHP2VendorName ) == 0)
	{
		if (strcmp( product, strHPC615ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		if (strcmp( product, strHPC618ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strHPC912ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strHP615ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		if (strcmp( product, strHP618ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strHP912ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else
		{
			camera_type = kTypeHP2;
		}
	}
	else if (strcmp( vendor, strPENTAXVendorName ) == 0)
	{
		if (strcmp( product, strPENTAXEI200ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strPENTAXEI2000ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
	}
	else
	{
		// Unknown
		camera_type = -1;
	}
}

void entry(void)
{
	detect_camera_type();

	if (camera_type == kTypeKodak2)
	{
		// initialized the MPU and wait for it to finish initializing
		CMInit();
		HYInit();

#if 0
		// allocate 2 lcd buffers that are continuous so we can use them for interlaced
		// mode also
		MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);

		// display the port
	    LMSetupBuffers(gLCD_buffer, gLCD_buffer, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();
#endif

		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
		
		AMGetSelfAppID(&altAppID);
		EMOpen(altAppID, 0);
	}
	else if (camera_type == kTypeKodak1)
	{
		// initialized the MPU and wait for it to finish initializing
		MPUInit();
		while( !smMconStat )
			taskDelay(20);

#if 0	
		// allocate 2 lcd buffers that are continuous so we can use them for interlaced
		// mode also
		MMNewAlignedPtr((288*216*4*2), 16, (char *)&gLCD_buffer);
		
		// display the port
	    LMSetupBuffers(gLCD_buffer, gLCD_buffer, FALSE);
	    
		// turn on the LCD
	    LMEnableLCDController();
#endif

		// Disable the blinking green viewfinder LED.
		MPUSetLED( LED_VIEWFINDER | LED_OFF );
		
		AMGetSelfAppID(&altAppID);
		EMOpen(altAppID, 0);
	}
	else
	{
		// I don't support sound on any other cameras yet, so die
		return;
	}

	// start the main loop
	mainLoopTaskID = taskSpawn("MainLoopTask", 30, 0, 4096, mainLoopTask, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

	// this becomes the event handler task
	eventHandlerTask();
}
