#include "MP3Task.h"

#include <stdio.h>
#include <stdlib.h>
#include <memLib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <mqueue.h>

// Interface to freeamp decoder.
#include <mhead.h>

//#define qMP3_DEBUG

//
// Defines...
//
#define MP3TASK_STACK_SIZE 		(64 * 1024)
#define BS_BUFBYTES 			60000U
#define PCM_BUFBYTES 			(16 * 1024)
#define AUDIO_BUFBYTES 			(8 * 1024)
#define kMP3Msg 				0x4D503320

// "MP3 " string in hex.
#define kMP3MsgQName 			"MP3Q"
#define kMP3StartPlaying 		0x01
#define kMP3StopPlaying 		0x03
#define kMP3PausePlaying 		0x05
#define kMP3ResumePlaying 		0x07
#define kMP3StopMP3 			0x09

// MP3 Directive structure.
typedef struct 
{
  int       MP3MagicNum;
  unsigned int      MsgCode;
  unsigned char     Data[128];
} TMP3Directive;

// External subprograms.
extern void DigitaSoundTask(void);
extern void sysdep_audio_init(void);
extern void sysdep_audio_close(void);
extern void sysdep_audio_flush_and_close(void);
extern int sysdep_audio_play(unsigned char *buf, int bufsize);
extern void sysdep_audio_pauseCODEC(void);
extern void sysdep_audio_resumeCODEC(void);
extern void sysdep_audio_shutdown(void);

void MP3TaskRun(void);
static void CleanupPlay(char flush);
static void DumpPCMBuffer(void);
static int InitializeMP3DecodingFromHeader(void);
static int bs_fill(void);
#ifdef qMP3_DEBUG
static int out_mpeg_info(MPEG_HEAD * h, int bitrate_arg);
#endif

//---------------------------------------------------------------------
// freeamp file and buffer handles.  Declared so that other routines in this
// module can use them.

// For IPC with the MP3Task:
int						MP3TaskID = 0;
int						MP3TaskPriority = 0;
mqd_t					MP3MsgQ = 0;

// Input File Handle.
int						MP3InFile = -1;

#ifdef MP3FILEOUTPUT
// Output sound file (used for debugging independent of the audio layer).
FILE *					SoundOutFile = NULL;
#endif

// Buffers used for MP3 bitstream and PCM output buffer.
unsigned char *         bs_buffer = NULL;
unsigned char *         bs_bufptr = NULL;
unsigned char *         pcm_buffer = NULL;
int             		bs_bufbytes = 0;
unsigned int            pcm_bufbytes = 0;
const unsigned int      kpcm_trigger = (PCM_BUFBYTES - (2500*sizeof(short)));
const int       		kbs_trigger = 2500;

// The "Milli"frames are thousands of a frame that are processed
// each second.  There is generally 30-50.xxxx frames processed
// each second (depending on the sample rate and the layer).  Use
// "Milli"frames so we can use integer math.
unsigned int			MilliFramesPerSecond;

MP3TaskStates MP3TaskState;

// Notes on debugging.  If the qMP3_DEBUG compile symbol is set, debug
// ouput will be attempted to standard out.  This means that some type
// of shell must be connected to receive the output.
// If debug I/O operations fail, nothing is done about it.
// Providing alternative debug, or debug of debug would introduce
// unnecessary complication to the code.

//----------------------------------------------------------------------
// The main program of the task.
// This task starts and waits for events.  Upon receiving an event to
// start playing, the task will:
// Make sure it's now already started
// Start and initialize the audio layer task
// Start a look that reads data from the MP3 file, decodes it, and feeds it
//   to the audio layer task.
//
// The main loop is performed as a state machine.
void MP3TaskRun(void)
{
	mqd_t             lMP3MsgQ = NULL;
	TMP3Directive     MP3Directive;
	int              StreamSoundTaskID;
	int              framebytes = 0;
	IN_OUT            decodeStats;
	struct mq_attr    mqAttr;
	
	// Track the "Milli"frames going by so we can
	// update the seconds counter.
	unsigned int             MilliFrameCount;
	
	// Set the initial state.
	MP3TaskState = kMP3TaskInitial;

	while (MP3TaskState != kMP3TaskTerminated) 
	{
		switch (MP3TaskState) 
		{
			case kMP3TaskInitial:
			{
				// Set up the local Msg queue:
				if ( (lMP3MsgQ = mq_open(kMP3MsgQName, O_CREAT|O_RDWR, 0, &mqAttr)) == (mqd_t)-1 ) 
				{
					#ifdef qMP3_DEBUG
					printf("MP3Task: Trouble openning the message queue\n");
					#endif
					
					MP3TaskState = kMP3TaskEnding;
					break;
				}
				
				// Start StreamSound task with LOW priority
				StreamSoundTaskID = taskSpawn("StreamSound", 3, 0, 4096, DigitaSoundTask, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0);
				
				#ifdef qMP3_DEBUG
				printf("State: %d, StreamSound started\n", MP3TaskState);
				#endif
				
				MP3TaskState = kMP3TaskWaiting;
				break;
			}

			case kMP3TaskWaiting:
			{
				// Read any analyze a possible MP3 directive off the message queue.
				if (mq_receive(lMP3MsgQ,&MP3Directive, sizeof(MP3Directive), NULL) > 0)
				{
					if (MP3Directive.MP3MagicNum == kMP3Msg)
					{
						// Switch on the MP3 Directive data:
						switch (MP3Directive.MsgCode) 
						{
							case kMP3StartPlaying:
							{
								// Start and initialize the audio layer.
								sysdep_audio_init();
								
								// Allocate space for the bitstream buffer:
								if (!(bs_buffer = (unsigned char*)malloc(BS_BUFBYTES))) 
								{
									#ifdef qMP3_DEBUG
									printf("State: %d, Trouble allocating space for bitstream buffer\n", MP3TaskState);
									#endif
									
									CleanupPlay(FALSE);
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								// Allocate space for the PCM buffer:
								if (!(pcm_buffer = (unsigned char*)malloc(PCM_BUFBYTES))) 
								{
									#ifdef qMP3_DEBUG
									printf("Trouble allocating space for PCM buffer\n");
									#endif
									
									CleanupPlay(FALSE);
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								// Open the mpeg file:
								MP3InFile = open((char *)MP3Directive.Data, O_RDONLY, 0644);
								if (MP3InFile < 0) 
								{
									#ifdef qMP3_DEBUG
									printf("Trouble openning MP3 file\n");
									#endif
									
									CleanupPlay(FALSE);
									break;
								}
								
								// Fill the bitstream buffer from the file, and seek for sync pattern:
								if (bs_fill() < 0) 
								{
									#ifdef qMP3_DEBUG
									printf("Trouble on initial bitstream buffer load.\n");
									#endif
									
									CleanupPlay(FALSE);
									break;
								}
								
								if ((framebytes = InitializeMP3DecodingFromHeader()) <= 0) 
								{
									CleanupPlay(FALSE);
									break;
								}
								MilliFrameCount = 0;
								
								#ifdef qMP3_DEBUG
								printf("MP3Task: Initial frame info retrieved.  Framesize: %d bytes.\n",framebytes);
								#endif
								
								#ifdef MP3FILEOUTPUT
								// Open the output file (used only for debugging):
								SoundOutFile = fopen("/B/X.SND", "w");
								if (SoundOutFile == NULL) 
								{
									#ifdef qMP3_DEBUG
									printf("Trouble openning output file\n");
									#endif
									
									MP3TaskState = kMP3TaskEnding;
									CleanupPlay(FALSE);
									break;
								}
								#endif
								
								// Close the message queue, and reopen it for non-blocking:
								mq_close(lMP3MsgQ);
								if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR|O_NONBLOCK)) == (mqd_t)-1 ) 
								{
									#ifdef qMP3_DEBUG
									printf("MP3Task: Trouble openning message queue NONBLOCK\n");
									#endif
									
									CleanupPlay(FALSE);
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								// Set next state.
								MP3TaskState = kMP3TaskPlaying;
								break;
							}
							
							case kMP3StopMP3:
							{
								MP3TaskState = kMP3TaskEnding;
								break;
							}
							
							default:
							{
								break;
							}
						}
					}
				}
				break;
			}
			
			case kMP3TaskPlaying:
			{
				// Do another iteration of MP3 processing.
				if (bs_fill() < 0) 
				{
					#ifdef qMP3_DEBUG
					printf("State: %d, Trouble filling bitstream buffer\n",MP3TaskState);
					#endif
					
					CleanupPlay(FALSE);
					// Close the message queue, and reopen it blocking:
					mq_close(lMP3MsgQ);
					
					if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR)) == (mqd_t)-1 ) 
					{
						#ifdef qMP3_DEBUG
						printf("MP3Task: Trouble openning message queue (blocking)\n");
						#endif
						
						MP3TaskState = kMP3TaskEnding;
						break;
					}
					
					MP3TaskState = kMP3TaskWaiting;
					continue;
				}
				
				if (bs_bufbytes < framebytes) 
				{
					// Now at the end of the MP3 song file.
					DumpPCMBuffer();
					// Cleanup by allowing the audio buffers to clear.
					CleanupPlay(TRUE);
					// Close the message queue, and reopen it blocking:
					mq_close(lMP3MsgQ);
					if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR)) == (mqd_t)-1 ) 
					{
						#ifdef qMP3_DEBUG
						printf("MP3Task: Trouble openning message queue (blocking)\n");
						#endif
						
						MP3TaskState = kMP3TaskEnding;
						break;
					}
					
					MP3TaskState = kMP3TaskWaiting;
					continue;
				}
				
				// Decode into the pcm buffer:
				decodeStats = audio_decode(bs_bufptr, (short*)(pcm_buffer+pcm_bufbytes));
				if ((MilliFrameCount += 1000) > MilliFramesPerSecond) 
				{
					MilliFrameCount -= MilliFramesPerSecond;
				}
				
				if (decodeStats.in_bytes > 0) 
				{
					bs_bufptr += decodeStats.in_bytes;
					bs_bufbytes -= decodeStats.in_bytes;
					pcm_bufbytes += decodeStats.out_bytes;
					
					if (pcm_bufbytes > kpcm_trigger) 
					{
						DumpPCMBuffer();
					}
				}
				else 
				{
					#ifdef qMP3_DEBUG
					printf("State: %d, Nothing decoded in this data\n",MP3TaskState);
					#endif
					;
				}
				
				if (mq_receive(lMP3MsgQ,&MP3Directive, sizeof(MP3Directive), NULL) > 0)
				{
					// Analyze the directive data:
					if (MP3Directive.MP3MagicNum == kMP3Msg)
					{
						// Switch on the MP3 Directive data:
						switch (MP3Directive.MsgCode) 
						{
							case kMP3PausePlaying:
							{
								sysdep_audio_pauseCODEC();
								
								// Close the message queue, and reopen it blocking:
								mq_close(lMP3MsgQ);
								if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR)) == (mqd_t)-1 ) 
								{
									#ifdef qMP3_DEBUG
									printf("MP3Task: Trouble openning message queue (blocking)\n");
									#endif
									
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								MP3TaskState = kMP3TaskPaused;
								break;
							}
							
							case kMP3StopPlaying:
							{
								CleanupPlay(FALSE);
								
								// Close the message queue, and reopen it blocking:
								mq_close(lMP3MsgQ);
								if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR)) == (mqd_t)-1 ) 
								{
									#ifdef qMP3_DEBUG
									printf("MP3Task: Trouble openning message queue (blocking)\n");
									#endif
									
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								// Set next state.
								MP3TaskState = kMP3TaskWaiting;
								break;
							}
							
							case kMP3StopMP3:
							{
								MP3TaskState = kMP3TaskEnding;
								break;
							}
							
							default:
							{
								break;
							}
						}
					}
				}
				break;
			}
			
			case kMP3TaskPaused:
			{
				// Read any analyze a possible MP3 directive off the message queue.
				if (mq_receive(lMP3MsgQ,&MP3Directive, sizeof(MP3Directive), NULL) > 0)
				{
					if (MP3Directive.MP3MagicNum == kMP3Msg)
					{
						// Switch on the MP3 Directive data:
						switch (MP3Directive.MsgCode) 
						{
							case kMP3ResumePlaying:
							{
								sysdep_audio_resumeCODEC();
								
								// Close the message queue, and reopen it for non-blocking:
								mq_close(lMP3MsgQ);
								if ( (lMP3MsgQ = mq_open(kMP3MsgQName,O_RDWR|O_NONBLOCK)) == (mqd_t)-1 ) 
								{
									#ifdef qMP3_DEBUG
									printf("MP3Task: Trouble openning message queue NONBLOCK\n");
									#endif
									
									CleanupPlay(FALSE);
									MP3TaskState = kMP3TaskEnding;
									break;
								}
								
								MP3TaskState = kMP3TaskPlaying;
								break;
							}
						
							case kMP3StopPlaying:
							{
								sysdep_audio_resumeCODEC();
								CleanupPlay(FALSE);
								MP3TaskState = kMP3TaskWaiting;
								break;
							}
						
							case kMP3StopMP3:
							{
								MP3TaskState = kMP3TaskEnding;
								break;
							}
						
							default:
							{
								break;
							}
						}
					}
				}
				break;
			}
	
			case kMP3TaskEnding:
			{
				CleanupPlay(FALSE);
				sysdep_audio_shutdown();
				
				#ifdef qMP3_DEBUG
				printf("MP3Task Terminating.\n");
				#endif
				
				MP3TaskState = kMP3TaskTerminated;
				break;
			}
	
			default:
			{
				break;
			}
		}
	}
		
	return NULL;
}

//----------------------------------------------------------------------
// Called from users of the MP3 task to get an MP3 task running, and
// establish a msg queue identifier for further communications.
char MP3TaskInit(void)
{
	struct mq_attr mqAttr;
	
	// Set up the Msg queue:
	mqAttr.mq_msgsize = sizeof(TMP3Directive);
	mqAttr.mq_maxmsg = 10;
	if ( (MP3MsgQ = mq_open(kMP3MsgQName,O_RDWR|O_CREAT,0,&mqAttr)) < 0)
	{
		return (FALSE);
	}
	
	// Start the MP3Task
	MP3TaskID = taskSpawn("MP3Task", 31, 0, MP3TASK_STACK_SIZE, MP3TaskRun, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	
	return (TRUE);
}

//----------------------------------------------------------------------
// Analyze the MP3 header for framesize, and initialize the decoder with
// the correct parameters.
// Returns:
//    >0 number of bytes in the frames
//    0  there was a problem in reading the frame, or initializing
//       the decoder.
//
static int InitializeMP3DecodingFromHeader (void)
{
	unsigned int      framebytes;
	MPEG_HEAD  head;
	int       bitrate;
	unsigned int      searchforward;
	unsigned int      returnCode = 0;
	DEC_INFO       FrameInfo;
	
	// The samples per frame for each of the layer codes:
	// 00b unused, 01b Layer3, 10b Layer2, 11b Layer1
	unsigned int      SamplesPerFrame[4] = {1,1152,1152,384};
	
	if ((framebytes = head_info3(bs_buffer, bs_bufbytes, &head, &bitrate, &searchforward)) > 0) 
	{
		bs_bufptr += searchforward;
		bs_bufbytes -= searchforward;
		
		#ifdef qMP3_DEBUG
		printf("Found a frame header in the bitstream\n");
		out_mpeg_info(&head, bitrate);
		#endif
		
		// Initialize the decoder
		// freq limit is 24000, this is also hard coded on the sparc.
		if (audio_decode_init(&head, framebytes)) 
		{
			#ifdef qMP3_DEBUG
			printf("Audio decoder initialized from header info.\n");
			#endif
			
			// At this point, we know the sample rate and "layer" of the file
			// (Unfortuneately, this code does not respond to the possible
			// dynamics in the frame headers throughout the file.  The
			// parameters read in the first frame header, set the values
			// for the whole file.)
			audio_decode_info(&FrameInfo);
			MilliFramesPerSecond = (FrameInfo.samprate * 1000)/SamplesPerFrame[head.option];
			
			returnCode = framebytes;
		}
		else 
		{
			#ifdef qMP3_DEBUG
			printf("audio_decode_init failed\n");
			#endif
			;
		}
	}
	else 
	{
		#ifdef qMP3_DEBUG
		printf("Problems syncing up to a frame header in bitstream\n");
		#endif
	}
	
	return (returnCode);
}

//----------------------------------------------------------------------
// When there is enough PCM data, or at the end of the song, empty the
// data to the audio layer.
//
void DumpPCMBuffer(void)
{
	int offset = 0;		  
	while (pcm_bufbytes)
	{
		// Send data in lumps (length send to sysdep_audio_play is
		// length of 16 bit words).
		if (pcm_bufbytes < AUDIO_BUFBYTES) 
		{
			#ifdef MP3FILEOUTPUT
			fwrite(pcm_buffer+offset,pcm_bufbytes,1,SoundOutFile);
			#else
			sysdep_audio_play(pcm_buffer+offset,(pcm_bufbytes>>1));
			#endif
			pcm_bufbytes = 0;
		}
		else 
		{
			#ifdef MP3FILEOUTPUT
			fwrite(pcm_buffer+offset,AUDIO_BUFBYTES,1,SoundOutFile);
			#else
			sysdep_audio_play(pcm_buffer+offset,(AUDIO_BUFBYTES >> 1));
			#endif
			pcm_bufbytes -= AUDIO_BUFBYTES;
			offset += AUDIO_BUFBYTES;
		}
	}
}

//----------------------------------------------------------------------
// Any time the audio stops, this routine is used to close down the
// input and output streams.
// 
void CleanupPlay(char flush)
{
	// Close out the audio layer output.
	#ifdef MP3FILEOUTPUT
	if (SoundOutFile != 0) 
	{
		fclose(SoundOutFile);
		SundOutFile = 0;
	}
	#else
	if (flush)
	{
		sysdep_audio_flush_and_close();
	}
	else
	{
		sysdep_audio_close();
	}
	#endif
	
	if (MP3InFile >= 0)
	{
		close(MP3InFile);
		MP3InFile = -1;
	}
	
	if (bs_buffer != NULL) 
	{
		free(bs_buffer);
		bs_buffer = NULL;
		bs_bufbytes = 0;
	}
	
	if (pcm_buffer != NULL) 
	{
		free(pcm_buffer);
		pcm_buffer = NULL;
		pcm_bufbytes = 0;
	}
}

//----------------------------------------------------------------------
// Used to move a set of bytes from the input MP3 file into the bitstream.
// Returns:
//  > 0 for the number of new bytes read from the file.
//  0   if no new bytes were read into the buffer.
//  -1  for a read error
// 
static int bs_fill(void)
{
	int nread = 0;
	
	if (bs_bufbytes < 0)
	{
		bs_bufbytes = 0;		// signed var could be negative
	}
	
	// If there is significant room in the buffer for more bytes, move
	// bytes in from the file.
	if (bs_bufbytes < kbs_trigger) 
	{
		// 
		// Make room, and read more data.
		memmove(bs_buffer, bs_bufptr, bs_bufbytes);
		nread = read(MP3InFile, (char *)(bs_buffer + bs_bufbytes), BS_BUFBYTES - bs_bufbytes);
		if (nread == -1) 
		{
			#ifdef qMP3_DEBUG
			printf("MP3Task: bs_fill: FILE READ ERROR\n");
			#endif
			
			return (nread);
		}
		// Reset the pointer back to the begining of the bitstream buffer, and set
		// the number of bytes now in the buffer.
		bs_bufbytes += nread;
		bs_bufptr = bs_buffer;
	}
	return (nread);
}

//----------------------------------------------------------------------
// Used by the UI task to send a directive to start MP3 playing.
void StartPlaying (char * FilePath)
{
	TMP3Directive Msg;
	Msg.MP3MagicNum = kMP3Msg;
	Msg.MsgCode = kMP3StartPlaying;
	strcpy(Msg.Data, FilePath);
	if (mq_send(MP3MsgQ, &Msg, sizeof(Msg), 0))
	{
		#ifdef qMP3_DEBUG
		perror("StartPlaying: Problem sending on msg queue\n");
		#else
		;
		#endif
	}
}

//----------------------------------------------------------------------
// Used by the UI task to send a directive to stop MP3 playing.
void StopPlaying (void)
{
	TMP3Directive Msg;
	Msg.MP3MagicNum = kMP3Msg;
	Msg.MsgCode = kMP3StopPlaying;
	if (mq_send(MP3MsgQ, &Msg, sizeof(Msg), 0))
	{
		#ifdef qMP3_DEBUG
		perror("StopPlaying: Problem sending on msg queue\n");
		#else
		;
		#endif
	}
}

//----------------------------------------------------------------------
// Used by the UI task to send a directive to pause MP3 playing.
void PausePlaying (void)
{
	TMP3Directive Msg;
	Msg.MP3MagicNum = kMP3Msg;
	Msg.MsgCode = kMP3PausePlaying;
	if (mq_send(MP3MsgQ, &Msg, sizeof(Msg), 0))
	{
		#ifdef qMP3_DEBUG
		perror("PausePlaying: Problem sending on msg queue\n");
		#else
		;
		#endif
	}
}

//----------------------------------------------------------------------
// Used by the UI task to send a directive to Resume MP3 playing.
void ResumePlaying (void)
{
	TMP3Directive Msg;
	Msg.MP3MagicNum = kMP3Msg;
	Msg.MsgCode = kMP3ResumePlaying;
	if (mq_send(MP3MsgQ, &Msg, sizeof(Msg), 0))
	{
		#ifdef qMP3_DEBUG
		perror("ResumePlaying: Problem sending on msg queue\n");
		#else
		;
		#endif
	}
}

//----------------------------------------------------------------------
// Used by the UI task to stop the MP3 tasks.
void StopMP3 (void)
{
	TMP3Directive Msg;
	Msg.MP3MagicNum = kMP3Msg;
	Msg.MsgCode = kMP3StopMP3;
	if (mq_send(MP3MsgQ, &Msg, sizeof(Msg), 0))
	{
		#ifdef qMP3_DEBUG
		perror("StopMP3: Problem sending on msg queue\n");
		#else
		;
		#endif
	}
}

#ifdef qMP3_DEBUG
/*------------------------------------------------------------------*/
// Routines for freeamp decoder.
static int out_mpeg_info(MPEG_HEAD * h, int bitrate_arg)	/* info only */
{
	int bitrate;
	int samprate;
	static char *Layer_msg[] = {"INVALID", "III", "II", "I"};
	static char *mode_msg[] = {"STEREO", "JOINT", "DUAL", "MONO"};
	
	bitrate = bitrate_arg / 1000;
	printf("\n Layer %s ", Layer_msg[h->option]);
	
	printf("  %s ", mode_msg[h->mode]);
	samprate = sr_table[4 * h->id + h->sr_index];
	if ((h->sync & 1) == 0)
	{
		samprate = samprate / 2;	// mpeg25
	}
	
	printf(" %d ", samprate);
	printf("  %dKb ", bitrate);
	if ((h->mode == 1) && (h->option != 1))
	{
		printf("  %d stereo bands\n", 4 + 4 * h->mode_ext);
	}

	if (h->prot == 0)
	{
		printf(" (CRC)\n");
	}
	
	return 0;
	
}
#endif

