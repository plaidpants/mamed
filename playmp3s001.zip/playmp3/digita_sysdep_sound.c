#include "osd_depend.h"
#include "SoundPrivate.h"

// We need 15 bit sound
#define qSOUND_NEED_15_BIT

// make this a bit bigger for us, seems to sound better
#undef kSNDDefaultBDLength
#define kSNDDefaultBDLength 8 * 1024

// structures
typedef struct cache
{
	SEM_ID soundPlaying;
	unsigned char data[2*kSNDDefaultBDLength];
	int length;
	int best_repeat_offset;
} cache_data;

// extern globals
extern long camera_type;

// local globals
#define kNumStreams 16

cache_data stream_cache[kNumStreams];
unsigned char no_sound_cache[2*kSNDDefaultBDLength];

int curStream;
int nextStream;
cache_data * cur_cache_data = 0;

SEM_ID new_audio = 0;
SEM_ID sound_isr = 0;
SEM_ID * current_sound_playing = 0;
SEM_ID CODEC_available = 0;
SEM_ID shutdown_task = 0;
SEM_ID all_caches_empty = 0;

static unsigned long             	base;
static TAUDBufferDescriptor *    	pBD_DPRAM;
static short                  		sysdep_sound_audioOn;

//-----------------------------------------------------------------------------
// The sound hardware kicks this routine when some event against the sound
// registers occurs.  This ISR will "give" a semaphore identifying that
// register event info is available, and, will "give" a semaphore is
// the hardware has finished playing a cache of sound data
void sysInterruptHandler(void)
{
	unsigned char					event;
	unsigned char					processedEvent;
	
	/* let's handle the interrupt */
	*CISR(base) = CISR_SMC2_PIP;
	
	event = (unsigned char)*SMCE2(base);
	
	if (event & kSMCEventReceiveBufferIsClosed)
	{
		processedEvent = kSMCEventReceiveBufferIsClosed; 
	}
	else if (event & kSMCEventBufferIsTransmitted)  	
	{
		processedEvent = kSMCEventBufferIsTransmitted; 
	}
	else if (event & kSMCEventUnderrun)
	{
		*SMCM2(base) &= ~kSMCEventUnderrun;
		processedEvent = kSMCEventUnderrun;
	} 
	else if (event & kSMCEventBusy)
	{
		*SMCM2(base) &= ~kSMCEventBusy;
		processedEvent = kSMCEventBusy;
	}
	else
	{
		processedEvent = event;
	}
	
	*SMCE2(base) = processedEvent;
	
	/* done playing sound */
	if (sound_isr)
	{
		semGive(sound_isr);
	}
	
	if (current_sound_playing != 0)
	{
		/* done playing this sound buffer */
		semGive(*current_sound_playing);
		current_sound_playing = 0;
	}
}

//-----------------------------------------------------------------------------

void SetupGlobals(void)
{
	// Create the semaphores for synchronization.
	new_audio = semCCreate(SEM_Q_PRIORITY, 0);
	sound_isr =  semBCreate(SEM_Q_PRIORITY, 0);
	CODEC_available = semBCreate(SEM_Q_PRIORITY, 0);
	all_caches_empty = semBCreate(SEM_Q_PRIORITY, 0);
	shutdown_task = semBCreate(SEM_Q_PRIORITY, 0);
	
	// Set up the "blank" sound.
	memset(no_sound_cache, 0, 2*kSNDDefaultBDLength);
	
	/* setup globals so we don't have to call these functions later */
	base = vxImmrGet();
	pBD_DPRAM = (TAUDBufferDescriptor*)(kSMC2TxBD(MPC860_DPRAM_BASE(base)));
		
	sysdep_sound_audioOn = FALSE;
}

void UnsetGlobals(void)
{
	// Delete the semaphores.
	semDelete(new_audio);
	semDelete(sound_isr);
	semDelete(CODEC_available);
	semDelete(all_caches_empty);
	semDelete(shutdown_task);
}

//-----------------------------------------------------------------------------

void sysdep_audio_turnonCODEC(void)
{
	if (!sysdep_sound_audioOn) 
	{
		sysdep_sound_audioOn = TRUE;
		if (camera_type == kTypeKodak1)
		{
			sndOpenCodec();
			sndConfigureCodec(kSNDConfigureCodecOutput);
			taskDelay(1);
			sndHWSetBilevelVolume(2);
			sndHWPowerCodec(2);
			taskDelay(7);
			sndMuteAudio(0);
			sndInitCodecTransmit();
		}
		else if (camera_type == kTypeKodak2)
		{
			AUDOpenCodec();
			AUDConfigureCodec(kSNDConfigureCodecOutput);
			taskDelay(1);
			AUDHWSetBilevelVolume(2);
			AUDPowerCodec(2);
			taskDelay(7);
			AUDMuteAudio(0);
			AUDInitCodecTransmit();
		}

		/* take over the isr so we can add a sem */
		intConnect(IV_SMC2_PIP, sysInterruptHandler, 0);
		
		semGive(CODEC_available);
	}
}

//-----------------------------------------------------------------------------

void sysdep_audio_construct_caches(void)
{
	int i;
	
	nextStream = 0;
	curStream = 0;
	
	/* Clear out stream cache */
	for (i = 0; i < kNumStreams; i++)
	{
		stream_cache[i].length = kSNDDefaultBDLength;
		memset(stream_cache[i].data,0,2*kSNDDefaultBDLength);
		stream_cache[i].soundPlaying = semBCreate(SEM_Q_PRIORITY, SEM_FULL);
	}
	
	cur_cache_data = 0;
	current_sound_playing = 0;
	
	semGive(all_caches_empty);
}

//-----------------------------------------------------------------------------
// The controlling task calls this routine to set up the codec, and establish
// comm with the main sound task.
void sysdep_audio_init(void)

{
	// Reclaim all the new_audio semaphores to stop the
	// audio task from producing audio to the hardware
	while (semTake(new_audio, NO_WAIT) == OK)
		;
	
	// Set up the caches used to transfer audio data between the client and
	// the CODEC hardware.
	sysdep_audio_construct_caches();
	
	// Turn on the CODEC so allow audio data.
	sysdep_audio_turnonCODEC();
}

//-----------------------------------------------------------------------------

void sysdep_audio_shutdownCODEC(void)
{
	if (sysdep_sound_audioOn) 
	{
		semTake(CODEC_available, WAIT_FOREVER);
		if (camera_type == kTypeKodak1)
		{
			/* close up the codec */
			sndCloseCodecTransmit();
			sndMuteAudio(1);
			sndCloseCodec();
		}
		else if (camera_type == kTypeKodak2)
		{
			AUDCloseCodecTransmit();
			AUDMuteAudio(1);
			AUDCloseCodec();
		}
		sysdep_sound_audioOn = FALSE;
		
		// make sure isr sem's are released
		if (sound_isr)
		{
			semGive(sound_isr);
		}
		
		if (current_sound_playing != 0)
		{
			/* done playing this sound buffer */
			semGive(*current_sound_playing);
			current_sound_playing = 0;
		}
	}
}

//-----------------------------------------------------------------------------

void sysdep_audio_pauseCODEC(void)
{
	semTake(CODEC_available, WAIT_FOREVER);
}

//-----------------------------------------------------------------------------

void sysdep_audio_resumeCODEC(void)
{
	semGive(CODEC_available);
}

//-----------------------------------------------------------------------------

void sysdep_audio_remove_caches(void)
{
	int i;
	
	nextStream = 0;
	curStream = 0;
	
	/* Clear out stream cache */
	for (i = 0; i < kNumStreams; i++)
	{
		stream_cache[i].length = kSNDDefaultBDLength;
		memset(stream_cache[i].data, 0, 2*kSNDDefaultBDLength);
		semDelete(stream_cache[i].soundPlaying);
		stream_cache[i].soundPlaying = 0;
	}
	
	cur_cache_data = 0;
	current_sound_playing = 0;
	
	semGive(all_caches_empty);
}

//-----------------------------------------------------------------------------
// The controlling task calls this routine to close the sound layer:  The
// caches are cleared, the Codec is closed.
void sysdep_audio_close(void)
{
	// Reclaim all the new_audio semaphores to stop the
	// audio task from producing audio to the hardware
	while (semTake(new_audio, NO_WAIT) == OK)
		;
	
	// Shutdown the CODEC
	sysdep_audio_shutdownCODEC();
	
	// Clear out all the cache used for audio data between
	// the client task and the CODEC hardware.
	sysdep_audio_remove_caches();
}

//-----------------------------------------------------------------------------
// A routine to close the CODEC only after the currently waiting caches are played.
void sysdep_audio_flush_and_close(void)
{
	// Wait for all caches to play.
	semTake(all_caches_empty, WAIT_FOREVER);
	semGive(all_caches_empty);
	
	// Shutdown the CODEC
	sysdep_audio_shutdownCODEC();
	
	// Clear out all the cache used for audio data between
	// the client task and the CODEC hardware.
	sysdep_audio_remove_caches();
}

//-----------------------------------------------------------------------------
// Used by the controlling task to communicate a block of data into the
// caches.  The data once in the caches will be taken by the main sound
// layer task to feed the hardware.
int sysdep_audio_play(unsigned char *buf, int bufsize)
{
	int i;
	unsigned short  *tmp;
	unsigned short temp;
	cache_data * next_cache_data;
	
	next_cache_data = &stream_cache[nextStream];
	
	/* make sure the buffer is not in use */
	semTake(next_cache_data->soundPlaying, WAIT_FOREVER);	
	
	/* copy the data into the buffer */
	memcpy(next_cache_data->data, buf, 2*bufsize);
	
	#ifdef qSOUND_NEED_15_BIT
	/* Convert 16 bit to 15 bit first since we have time now */
	tmp = next_cache_data->data;
	for (i = 0; i < bufsize; i++)
	{
		temp = *tmp;
		*tmp++ = temp >> 1;
	}
	#endif
	
	#ifdef qSOUND_DEBUG
	// kjl - Dump 100 16 bit points from the cache to see
	// a sample of the data:
	{
		int kl = 0;
		unsigned short *klp = (short*)next_cache_data->data;
		
		for (kl=0;kl<50;kl++)
		printf(" %h04x",*klp++);
		printf("\n");
	}
	#endif
	
	next_cache_data->length = 2*bufsize;
	
	/* go to next buffer */
	nextStream++;
	if (nextStream == kNumStreams)
	nextStream = 0;
	
	{
		int last_diff;
		int last_offset;
		int end_offset;
		int diff;
		int i,j;
		short * data_ptr;
		
		/* Find a match in the waveform to match the end of the wave form segment */
		last_diff = 32000;
		last_offset = 0;
		data_ptr = (short *)next_cache_data->data;
		for (i = 0; i < bufsize / 4; i += 1)
		{
			end_offset = bufsize - 1 - 40;
			diff = 0;
			
			for (j = 0; j < 40; j += 3)
			{
				diff = diff + abs(data_ptr[end_offset + j] - data_ptr[i + j]);
			}
				
			if (diff < last_diff)
			{
				last_diff = diff;
				last_offset = i + 40 + 1; /* go to next sample */
						
				if (diff < (40/3))
				{
					/* good enough */
					break;
				}
			}
		}
		next_cache_data->best_repeat_offset = last_offset * 2;
	}
	
	/* signal the sound task we have new buffers to play */
	semGive(new_audio);
	semTake(all_caches_empty, NO_WAIT);
	
	return bufsize;
}

//-----------------------------------------------------------------------------
// Used by the controlling task to tell the audio layer to shutdown.
int sysdep_audio_shutdown(void)
{
	// Turn on the CODEC to allow the task to process
	sysdep_audio_turnonCODEC();
	semGive(shutdown_task);
}

//-----------------------------------------------------------------------------
// Used by the main sound layer task, this subprogram does the mechanics of
// communicating sound data from a cache into the hardware.
void PlaySound(void)
{
	semTake(CODEC_available, WAIT_FOREVER);
	
	cur_cache_data = &stream_cache[curStream];
	
	/* setup current sound buffer sem */
	current_sound_playing = &cur_cache_data->soundPlaying;
	
	pBD_DPRAM->fDataLength = cur_cache_data->length - kSNDBDSyncOffset;
	pBD_DPRAM->fBufferPointer = (unsigned char *)cur_cache_data->data + kSNDBDSyncOffset;
	pBD_DPRAM->fStatus = (kSMCBDInitTransparent
					| kSMCBDInterrupt
					| kSMCBDReady
					| kSMCBDLastByteInMessage
					| kSMCBDLastBDInTable);
	
	*SMCE2(base) = 0xff;
	*SMCM2(base) = kSMCEventBufferIsTransmitted | kSMCEventUnderrun;
	*SMCMR2(base) = kSMC16BitTransparentNormal | kSMCEnableTransmitter;
	
	/* go to next sound buffer */
	curStream++;
	if (curStream == kNumStreams)
	{
		curStream = 0;
	}
	
	semGive(CODEC_available);
}

void PlayNoSound(void)
{
	semTake(CODEC_available,WAIT_FOREVER);
	
	/* setup current sound buffer sem */
	current_sound_playing = 0;
	
	pBD_DPRAM->fDataLength =   (2*kSNDDefaultBDLength) - kSNDBDSyncOffset;
	pBD_DPRAM->fBufferPointer = (unsigned char *)no_sound_cache + kSNDBDSyncOffset;
	pBD_DPRAM->fStatus = (kSMCBDInitTransparent
						| kSMCBDInterrupt
						| kSMCBDReady
						| kSMCBDLastByteInMessage
						| kSMCBDLastBDInTable);
	
	*SMCE2(base) = 0xff;
	*SMCM2(base) = kSMCEventBufferIsTransmitted | kSMCEventUnderrun;
	*SMCMR2(base) = kSMC16BitTransparentNormal | kSMCEnableTransmitter;
	
	semGive(CODEC_available);
}

//-----------------------------------------------------------------------------
// This is the main sound layer task.  Looping forever, it moves the data
// received in the sound caches into the sound hardware.
void DigitaSoundTask(void)
{
	SetupGlobals();
	
	// Continue until the shutdown_task semaphore is delivered.
	while (semTake(shutdown_task, NO_WAIT) != OK) 
	{
		if (semTake(new_audio, NO_WAIT) == OK) 
		{
			// If the CODEC is not available, or shut down, this task will
			// wait indefinately at this point, until the CODEC is turned
			// on again.
			PlaySound();
		}
		else 
		{
			// There should always be audio data available to play on the hardware,
			// if there is not, the program feeding the audio layer is not keeping
			// up, or, the CODEC is about to be shut down so no data has been
			// sent by the feeding program.  In either of these cases, play NULL
			// sound until the CODEC is shut down, or data arrives.
			// If the CODEC is not available, or shut down, this task will
			// wait indefinately at this point, until the CODEC is turned
			// on again.
			PlayNoSound();
			semGive(all_caches_empty);
		}
		
		// wait for current sound to finish
		if (sound_isr && sysdep_sound_audioOn)
		{
			semTake(sound_isr, WAIT_FOREVER);
		}
#if 0
		// Wait for ISR signaling that the buffer is available to write to again.
		// Don't get stuck here.  The audio may have been turned off.
		if (sound_isr)
		{
			if (semTake(sound_isr, 1) != OK)
			{
				// If the semaphore timed out, the audio hardware is not responding.
				// Give back the semaphore associated with the cache if applicable.
				if (current_sound_playing != 0) 
				{
					/* done playing this sound buffer */
					semGive(*current_sound_playing);
					current_sound_playing = 0;
				}
			}
		}
#endif
	}
	
	// Shutdown the CODEC
	sysdep_audio_shutdownCODEC();
	
	// Clear out all the cache used for audio data between
	// the client task and the CODEC hardware.
	sysdep_audio_remove_caches();
	
	UnsetGlobals();
	
	return 0;
}