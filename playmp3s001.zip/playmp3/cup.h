
// Header file for declarations needed by Layer 1, 2, and 3 unpacking.

#ifndef CUP_H
#define CUP_H

typedef void (*SBT_FUNCTION) (float *sample, short *pcm, int n);


#endif // CUP_H
