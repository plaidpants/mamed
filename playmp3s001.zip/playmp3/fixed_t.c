//-----------------------------------------------------------------------------
//
// DESCRIPTION:
//	Fixed point implementation.  - From Jim Surine.
//
//-----------------------------------------------------------------------------

#include "fixed_t.h"

#define MININT (0x80000000)
#define MAXINT (0x7fffffff)

// Multiply two fixed points
fixed_t FixedMul ( fixed_t a, fixed_t b )
{
    return ((long long) a * (long long) b) >> FRACBITS;
}


//
// FixedDiv, C version.
//
/*
fixed_t FixedDiv2 ( fixed_t	a, fixed_t b )
{
  long long c;
  c = ((long long) a << FRACBITS) / (long long) b;
  return (fixed_t) c;
}


fixed_t FixedDiv ( fixed_t a, fixed_t b )
{
  if ( (abs(a)>>14) >= abs(b))
	return (a^b)<0 ? MININT : MAXINT;
  return FixedDiv2 (a,b);
}
*/


