#include <stdio.h>
#include <ctype.h>
#include <dirent.h>
#include <stat.h>

/**********************************************************/
/* Functions called from DIGITA.C by MAME for running MESS */
/**********************************************************/
static char startup_dir[260]; /* Max Windows Path? */


/* Go back to the startup dir on exit */
void return_to_startup_dir(void)
{
    chdir(startup_dir);
}


/*****************************************************************************
 * device, directory and file functions
 *****************************************************************************/

static char dos_cwd[260];
static char dos_filemask[260];

static int fnmatch(const char *f1, const char *f2)
{
	while (*f1 && *f2)
	{
		if (*f1 == '*')
		{
			/* asterisk is not the last character? */
			if (f1[1])
			{
				/* skip until first occurance of the character after the asterisk */
                while (*f2 && toupper(f1[1]) != toupper(*f2))
					f2++;
				/* skip repetitions of the character after the asterisk */
				while (*f2 && toupper(f1[1]) == toupper(f2[1]))
					f2++;
			}
			else
			{
				/* skip until end of string */
                while (*f2)
					f2++;
			}
        }
		else
		if (*f1 == '?')
		{
			/* skip one character */
            f2++;
		}
		else
		{
			/* mismatch? */
            if (toupper(*f1) != toupper(*f2))
				return 0;
            /* skip one character */
			f2++;
		}
		/* skip mask */
        f1++;
	}
	/* no match if anything is left */
	if (*f1 || *f2)
		return 0;
    return 1;
}

int osd_num_devices(void)
{
	return 1;
}

const char *osd_get_device_name(int idx)
{
	if (idx == 0)
        return "/B";
    return "";
}

void osd_change_device(const char *device)
{
	strncpy(dos_cwd, device, 260);
	chdir(device);
}

void osd_change_directory(const char *directory)
{
	char new_cwd[260];
	DIR *dir;
	
	// get current directory
	getcwd(new_cwd, 260);
	
	// add a slash
	strncat(new_cwd, "/", 260);
	
	// add the new directory
	strncat(new_cwd, directory, 260);
	
	// try and change to the new directory
	chdir(new_cwd);
	
	// try and open itm just to make sure it's there
	dir = opendir(".");
	
    if (dir == 0)
    {
     	// got an error, go back to original directory
	   	chdir(dos_cwd);
    }
    else
    {
    	// save current directory
		getcwd(dos_cwd, 260);
		
    	// close it
    	closedir(dir);
	}
}

const char *osd_get_cwd(void)
{
	getcwd(dos_cwd, 260);
	
	return dos_cwd;
}

void *osd_dir_open(const char *mess_dirname, const char *filemask)
{
	DIR *dir;

	strcpy(dos_filemask, filemask);

    dir = opendir(".");

    return dir;
}

int osd_dir_get_entry(void *dir, char *name, int namelength, int *is_dir)
{
	int len;
    struct dirent *d;

    name[0] = '\0';
	*is_dir = 0;

    if (!dir)
		return 0;

    d = readdir(dir);
	while (d)
	{
		struct stat st;

		strncpy(name, d->d_name, namelength-1);
		name[namelength-1]='\0';

		len = strlen(name);

		if( stat(d->d_name, &st) == 0 )
		{
			*is_dir = S_ISDIR(st.st_mode);
			if (*is_dir)
			{
				return len;
			}
			else
			{
				if (S_ISREG(st.st_mode) && fnmatch(dos_filemask, d->d_name))
				{
					return len;
				}
				else
				{
					/* no match, zap the name and type again */
					name[0] = '\0';
					*is_dir = 0;
		        }
	        }
	    }
		else
		{
			/* no match, zap the name and type again */
			name[0] = '\0';
			*is_dir = 0;
		}

		d = readdir(dir);
	}
	return 0;
}

void osd_dir_close(void *dir)
{
	if (dir)
		closedir(dir);
}

char * strdup(const char * str)
{
	char * newstr;
	newstr = malloc(strlen(str) + 1);
	strcpy(newstr, str);
	return newstr;
}

int strwildcmp(const char *sp1, const char *sp2)
{
	char s1[9], s2[9];
	int i, l1, l2;
	char *p;

	strncpy(s1, sp1, 8); s1[8] = 0; if (s1[0] == 0) strcpy(s1, "*");

	strncpy(s2, sp2, 8); s2[8] = 0; if (s2[0] == 0) strcpy(s2, "*");

	p = strchr(s1, '*');
	if (p)
	{
		for (i = p - s1; i < 8; i++) s1[i] = '?';
		s1[8] = 0;
	}

	p = strchr(s2, '*');
	if (p)
	{
		for (i = p - s2; i < 8; i++) s2[i] = '?';
		s2[8] = 0;
	}

	l1 = strlen(s1);
	if (l1 < 8)
	{
		for (i = l1 + 1; i < 8; i++) s1[i] = ' ';
		s1[8] = 0;
	}

	l2 = strlen(s2);
	if (l2 < 8)
	{
		for (i = l2 + 1; i < 8; i++) s2[i] = ' ';
		s2[8] = 0;
	}

	for (i = 0; i < 8; i++)
	{
		if (s1[i] == '?' && s2[i] != '?') s1[i] = s2[i];
		if (s2[i] == '?' && s1[i] != '?') s2[i] = s1[i];
	}

	return stricmp(s1, s2);
}