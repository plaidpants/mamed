#include "driver.h"
#include "mamedbg.h"
#include "vidhrdw/vector.h"
#include "dirty.h"
#include "ticker.h"


#include "osdepend.h"

static int warming_up;

/* tweak values for centering tweaked modes */
int center_x;
int center_y;


#define BACKGROUND 0


dirtygrid grid1;
dirtygrid grid2;
char *dirty_old=grid1;
char *dirty_new=grid2;

static void update_screen_dummy(struct osd_bitmap *bitmap);
void (*update_screen)(struct osd_bitmap *bitmap) = update_screen_dummy;
void (*update_screen_debugger)(struct osd_bitmap *bitmap) = update_screen_dummy;


static int video_depth,video_fps,video_attributes,video_orientation;
static int modifiable_palette;
static int screen_colors;
static UINT8 *current_palette;
static unsigned int *dirtycolor;
static int dirtypalette;
static int dirty_bright;
static int bright_lookup[256];

int frameskip,autoframeskip;
#define FRAMESKIP_LEVELS 12

int vsync_frame_rate;
int skiplines;
int skipcolumns;
int use_dirty;
float osd_gamma_correction = 1.0;
int brightness;
float brightness_paused_adjust;
int gfx_width;
int gfx_height;
static int vis_min_x,vis_max_x,vis_min_y,vis_max_y;


static int viswidth;
static int visheight;
static int skiplinesmax;
static int skipcolumnsmax;
static int skiplinesmin;
static int skipcolumnsmin;
static int show_debugger,debugger_focus_changed;

static int vector_game;


int gfx_xoffset;
int gfx_yoffset;
int gfx_display_lines;
int gfx_display_columns;
static int xmultiply,ymultiply;
int throttle = 1;       /* toggled by F10 */

static int gone_to_gfx_mode;
static int frameskip_counter;
static int frames_displayed;
static TICKER start_time,end_time;    /* to calculate fps average on exit */
#define FRAMES_TO_SKIP 20       /* skip the first few frames from the FPS calculation */
							/* to avoid counting the copyright and info screens */

unsigned long * current_display = NULL;

unsigned long * pens823 = 0;
unsigned long * pens823right = 0;
unsigned long * pens823left = 0;
unsigned long * pensDCAM = 0;
unsigned long * pensDCAMright = 0;
unsigned long * pensDCAMleft = 0;

extern unsigned long * 		gLCD_buffer1;
extern unsigned long * 		gLCD_buffer2;
extern int 					gResolution;
extern long 				camera_type;

extern void * event_Sem;

#define kMathScaleBits  10
#define kMathScale     (1 << kMathScaleBits)
#define kMaxValue      (kMathScale * 235)
#define kMinValue      (kMathScale * 16)
#define kMaxYValue     (kMathScale * 240)
#define kMinYValue     (kMathScale * 16)

#define kYRcoeff    ((long)( 0.2990 * kMathScale))
#define kYGcoeff    ((long)( 0.5870 * kMathScale))
#define kYBcoeff    ((long)( 0.1140 * kMathScale))

#define kCbRcoeff    ((long)( 0.1687 * kMathScale))
#define kCbGcoeff    ((long)( 0.3313 * kMathScale))
#define kCbBcoeff    ((long)( 0.5000 * kMathScale))

#define kCrRcoeff    ((long)( 0.5000 * kMathScale))
#define kCrGcoeff    ((long)( 0.4187 * kMathScale))
#define kCrBcoeff    ((long)( 0.0813 * kMathScale))

#define kRYcoeff     ((long)( 1.0000 * kMathScale))
#define kRCbcoeff    ((long)( 0.0000 * kMathScale))
#define kRCrcoeff    ((long)( 1.4020 * kMathScale))

#define kGYcoeff     ((long)( 1.0000 * kMathScale))
#define kGCbcoeff    ((long)( 0.3441 * kMathScale))
#define kGCrcoeff    ((long)( 0.7141 * kMathScale))

#define kBYcoeff     ((long)( 1.0000 * kMathScale))
#define kBCbcoeff    ((long)( 1.7720 * kMathScale))
#define kBCrcoeff    ((long)( 0.0000 * kMathScale))

#define PIN(x)   	((x) > kMaxValue  ? 235 : ((x) < kMinValue  ? 16 : (x >> kMathScaleBits)))
#define PINY(x)  	((x) > kMaxYValue ? 240 : ((x) < kMinYValue ? 16 : (x >> kMathScaleBits)))
#define PIN255(x)   ((x) > 255        ? 255 : ((x) < 0          ?  0 : 255))

unsigned long RGB2YCYC823( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) << 24) + (PINY(v0) << 16) + (PIN(v2) << 8) + (PINY(v0) << 0));
}

unsigned long RGB2YCYC823LEFT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return (((PIN(v1) >> 1) << 24) + ((PIN(v2) >> 1) << 8) + (PINY(v0) << 0));
}

unsigned long RGB2YCYC823RIGHT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return (((PIN(v1) >> 1) << 24) + (PINY(v0) << 16)  + ((PIN(v2) >> 1) << 8));
}

unsigned long RGB2CYCYDCAM( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + (PINY(v0) << 8) + ((PIN(v2) >> 1) << 16) + (PINY(v0) << 24));
}

unsigned long RGB2CYCYDCAMRIGHT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + (PINY(v0) << 8) + ((PIN(v2) >> 1) << 16));
}

unsigned long RGB2CYCYDCAMLEFT( unsigned char r, unsigned char g, unsigned char b)
{ 
	long v0, v1, v2;
	
    v0 =  +kYRcoeff*r   +kYGcoeff*g   +kYBcoeff*b;
    v1 =  -kCbRcoeff*r  -kCbGcoeff*g  +kCbBcoeff*b + (128 << kMathScaleBits);
    v2 =  +kCrRcoeff*r  -kCrGcoeff*g  -kCrBcoeff*b + (128 << kMathScaleBits);
    return ((PIN(v1) >> 1) + ((PIN(v2) >> 1) << 16) + (PINY(v0) << 24));
}

// force an event check 10 times a second
int last_event_update = 0;
void force_event(void)
{
	int current_ticks;
	current_ticks = tickGet();
	
	if ((current_ticks - last_event_update) > 10)
	{
		if (event_Sem == 0)
			event_Sem = semCCreate(SEM_Q_FIFO, 0);
		semGive(event_Sem);
		last_event_update = current_ticks;
	}
}

// don't update more than 60 times a sec, cause that's too fast
int last_update = 0;
void wait_update(void)
{
	if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		while ((tickGet() - last_update) == 0)
		{
			;
		}
		
		last_update = tickGet();
	}
}

void update_screen_nodirty1(struct osd_bitmap *bitmap)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;

	wait_update();
	
	if (current_display == gLCD_buffer1)
	{
		current_display = gLCD_buffer2;
	}
	else
	{
		current_display = gLCD_buffer1;
	}

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + gfx_xoffset + (gfx_width * gfx_yoffset);
	displayInc = gfx_width - gfx_display_columns;
	
	walk_bitmap = bitmap->line[startRow] + skipcolumns;
	
	for (i = startRow;i < endRow;i++)
	{
		for (j = startColumn; j < endColumn; j++)
		{
			*walk_display++ = pens823[*walk_bitmap++];
		}
		
		walk_display += displayInc;
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}
	
	LMSwitchBuffer(current_display);

	force_event();
}

void update_screen_stretch_nodirty1(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;

	wait_update();
	
	if (current_display == gLCD_buffer1)
	{
		current_display = gLCD_buffer2;
	}
	else
	{
		current_display = gLCD_buffer1;
	}

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	
	walk_bitmap = bitmap->line[startRow] + skipcolumns;
	
	for (i = startRow; i < endRow; i++)
	{
		for (j = startColumn; j < endColumn; j += 2)
		{
			*walk_display = pens823right[*walk_bitmap++];
			*walk_display++ += pens823left[*walk_bitmap++];
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
		walk_display += displayInc;
	}
	
	LMSwitchBuffer(current_display);
	
	force_event();
}

void update_screen_stretch_dirty1(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;

	current_display = gLCD_buffer1;

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	skipInc = gfx_width / 2;
	
	walk_bitmap = bitmap->line[startRow] + skipcolumns;
	
	for (i = startRow; i < endRow;)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j += 2)
			{
				*walk_display = pens823right[*walk_bitmap++];
				*walk_display++ += pens823left[*walk_bitmap++];
			}
			walk_display += displayInc;
		}
		else
		{
			walk_display += skipInc;
		}
		
		i++;
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}
	
	force_event();
}

void update_screen_expand_nodirty1(struct osd_bitmap *bitmap)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;

	current_display = gLCD_buffer1;

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + 2*gfx_xoffset + 4*(gfx_width * gfx_yoffset);
	displayInc = 2*(gfx_width - gfx_display_columns);
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow; i++)
	{
		for (j = startColumn; j < endColumn; j++)
		{
			int val = pens823[*walk_bitmap++];
			*walk_display++ = val;
			*walk_display++ = val;
		}

		walk_display += displayInc;		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_dirty1(struct osd_bitmap *bitmap)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;

	current_display = gLCD_buffer1;

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + gfx_xoffset + (gfx_width * gfx_yoffset);
	displayInc = gfx_width - gfx_display_columns;
	skipInc = gfx_width;
	
	walk_bitmap = bitmap->line[startRow] + skipcolumns;
	
	for (i = startRow;i < endRow;i++)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j++)
			{
				*walk_display++ = pens823[*walk_bitmap++];
			}
			
			walk_display += displayInc;
		}
		else
		{
			walk_display += skipInc;
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}
}

void update_screen_double_nodirty1(struct osd_bitmap *bitmap)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;

	current_display = gLCD_buffer1;

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + 2*gfx_xoffset + 4*(gfx_width * gfx_yoffset);
	displayInc = 2*(gfx_width - gfx_display_columns);
	skipInc = 2*gfx_width;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow; i++)
	{
		unsigned long * save_start_display = walk_display;
		
		for (j = startColumn; j < endColumn; j++)
		{
			int val = pens823[*walk_bitmap++];
			*walk_display++ = val;
			*walk_display++ = val;
		}

		walk_display += displayInc;
		memcpy(walk_display, save_start_display, 4*2*gfx_display_columns);
		walk_display += skipInc;
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_double_dirty1(struct osd_bitmap *bitmap)
{
	register unsigned long * walk_display;
	register unsigned char * walk_bitmap;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;

	current_display = gLCD_buffer1;

	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + 2*gfx_xoffset + 4*(gfx_width * gfx_yoffset);
	displayInc = 2*(gfx_width - gfx_display_columns);
	skipInc = 2*gfx_width;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow; i++)
	{
		unsigned long * save_start_display = walk_display;
		
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j++)
			{
				int val = pens823[*walk_bitmap++];
				*walk_display++ = val;
				*walk_display++ = val;
			}

			walk_display += displayInc;
			memcpy(walk_display, save_start_display, 4*2*gfx_display_columns);
			walk_display += skipInc;
		}
		else
		{
			walk_display += 2*skipInc;
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_nodirty2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	
	wait_update();

	current_display = (unsigned long *)LMGetNextLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + gfx_xoffset + (gfx_width * gfx_xoffset);
	displayInc = gfx_width - gfx_display_columns;

	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow;i++)
	{
		for (j = startColumn; j < endColumn; j++)
		{
			*walk_display++ = pens823[*walk_bitmap++];
		}
		
		walk_display += displayInc;
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	LMSwitchToNextLiveviewFrame();

	force_event();
}

void update_screen_dirty2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();

	current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + gfx_xoffset + (gfx_width * gfx_yoffset);
	displayInc = gfx_width - gfx_display_columns;
	skipInc = gfx_width;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow;i++)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j++)
			{
				*walk_display++ = pens823[*walk_bitmap++];
			}
			
			walk_display += displayInc;
		}
		else
		{
			walk_display += skipInc;
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_double_dirty2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();
	
	current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + 2*gfx_xoffset + 4*(gfx_width * gfx_yoffset);
	displayInc = 2*(gfx_width - gfx_display_columns);
	skipInc = 2*gfx_width;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow; i++)
	{
		unsigned long * save_start_display = walk_display;
		
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j++)
			{
				int val = pens823[*walk_bitmap++];
				*walk_display++ = val;
				*walk_display++ = val;
			}
			
			walk_display += displayInc;
			memcpy(walk_display, save_start_display, 4*2*gfx_display_columns);
			walk_display += skipInc;		
		}
		else
		{
			walk_display += 2*skipInc;
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_double_nodirty2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();
	
	current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + 2*gfx_xoffset + 4*(gfx_width * gfx_yoffset);
	displayInc = 2*(gfx_width - gfx_display_columns);
	skipInc = 2*gfx_width;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow;i < endRow; i++)
	{
		unsigned long * save_start_display = walk_display;
		
		for (j = startColumn; j < endColumn; j++)
		{
			int val = pens823[*walk_bitmap++];
			*walk_display++ = val;
			*walk_display++ = val;
		}
		
		walk_display += displayInc;
		memcpy(walk_display, save_start_display, 4*2*gfx_display_columns);
		walk_display += skipInc;		
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_interlace_dirty(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display1;
	register unsigned long * walk_display2;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;

	walk_display1 = gLCD_buffer1 + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	walk_display2 = gLCD_buffer2 + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	skipInc = gfx_width / 2;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;

	for (i = startRow; i < endRow;)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j += 2)
			{
				*walk_display1 = pens823right[*walk_bitmap++];
				*walk_display1++ += pens823left[*walk_bitmap++];
			}
			walk_display1 += displayInc;
		}
		else
		{
			walk_display1 += skipInc;
		}
		
		i++;
		walk_bitmap = bitmap->line[i] + skipcolumns;

		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j += 2)
			{
				*walk_display2 = pens823right[*walk_bitmap++];
				*walk_display2++ += pens823left[*walk_bitmap++];
			}
			walk_display2 += displayInc;
		}
		else
		{
			walk_display2 += skipInc;
		}
		
		i++;
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

void update_screen_interlace_nodirty(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display1;
	register unsigned long * walk_display2;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display1 = gLCD_buffer1 + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	walk_display2 = gLCD_buffer2 + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;

	walk_bitmap = bitmap->line[skiplines] + skipcolumns;

	for (i = startRow; i < endRow;)
	{
		for (j = startColumn; j < endColumn; j += 2)
		{
			*walk_display1 = pens823right[*walk_bitmap++];
			*walk_display1++ += pens823left[*walk_bitmap++];
		}
		
		i++;
		walk_bitmap = bitmap->line[i] + skipcolumns;
		walk_display1 += displayInc;

		for (j = startColumn; j < endColumn; j += 2)
		{
			*walk_display2 = pens823right[*walk_bitmap++];
			*walk_display2++ += pens823left[*walk_bitmap++];
		}

		i++;
		walk_bitmap = bitmap->line[i] + skipcolumns;
		walk_display2 += displayInc;
	}

	force_event();
}

void update_screen_nodirty_dcam1(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();

	current_display = (unsigned long *)LMGetNextLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	skipInc = gfx_width / 2;

	walk_bitmap = bitmap->line[skiplines] + skipcolumns;

	for (i = startRow; i < endRow; i++)
	{
		for (j = startColumn; j < endColumn; j += 2)
		{
			*walk_display = pensDCAMright[*walk_bitmap++];
			*walk_display++ += pensDCAMleft[*walk_bitmap++];
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
		walk_display += displayInc;
	}

	LMSwitchToNextLiveviewFrame();

	force_event();
}

void update_screen_dirty_dcam1(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();
	
	last_update = tickGet();

	current_display = (unsigned long *)LMGetCurrentLiveviewFrame();
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	skipInc = gfx_width / 2;

	walk_bitmap = bitmap->line[skiplines] + skipcolumns;

	for (i = startRow;i < endRow;i++)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j += 2)
			{
				*walk_display = pensDCAMright[*walk_bitmap++];
				*walk_display++ += pensDCAMleft[*walk_bitmap++];
			}
			
			walk_display += displayInc;
		}
		else
		{
			walk_display += skipInc;
		}
		walk_bitmap = bitmap->line[i] + skipcolumns;
	}
	
	LMSwitchToNextLiveviewFrame();

	force_event();
}

void update_screen_nodirty_dcam2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	
	wait_update();
	
	if (current_display == gLCD_buffer1)
	{
		current_display = gLCD_buffer2;
	}
	else
	{
		current_display = gLCD_buffer1;
	}
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;
	
	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;
	
	for (i = startRow; i < endRow; i++)
	{
		for (j = startColumn; j < endColumn; j += 2)
		{
			*walk_display = pensDCAMright[*walk_bitmap++];
			*walk_display++ += pensDCAMleft[*walk_bitmap++];
		}
		
		walk_bitmap = bitmap->line[i] + skipcolumns;
		walk_display += displayInc;
	}
	
	LMSwitchBuffer(current_display);
	
	force_event();
}

void update_screen_dirty_dcam2(struct osd_bitmap *bitmap)
{
	register unsigned char * walk_bitmap;
	register unsigned long * walk_display;
	register int i;
	register int j;
	int startRow;
	int endRow;
	int startColumn;
	int endColumn;
	int displayInc;
	int skipInc;
	
	wait_update();
	
	current_display = gLCD_buffer1;
	
	startRow = skiplines;
	endRow = skiplines + gfx_display_lines;
	startColumn = skipcolumns;
	endColumn = skipcolumns + gfx_display_columns;

	walk_display = current_display + (gfx_xoffset / 2) + (gfx_width * gfx_yoffset) / 4;
	displayInc = (gfx_width - gfx_display_columns) / 2;
	skipInc = gfx_width / 2;
	
	walk_bitmap = bitmap->line[skiplines] + skipcolumns;

	for (i = startRow;i < endRow;i++)
	{
		if (ISDIRTY(i))
		{
			for (j = startColumn; j < endColumn; j += 2)
			{
				*walk_display = pensDCAMright[*walk_bitmap++];
				*walk_display++ += pensDCAMleft[*walk_bitmap++];
			}
			
			walk_display += displayInc;
		}
		else
		{
			walk_display += skipInc;
		}

		walk_bitmap = bitmap->line[i] + skipcolumns;
	}

	force_event();
}

/* Create a bitmap. Also calls osd_clearbitmap() to appropriately initialize */
/* it to the background color. */
/* VERY IMPORTANT: the function must allocate also a "safety area" 16 pixels wide all */
/* around the bitmap. This is required because, for performance reasons, some graphic */
/* routines don't clip at boundaries of the bitmap. */

const int safety = 16;

struct osd_bitmap *osd_alloc_bitmap(int width,int height,int depth)
{
	struct osd_bitmap *bitmap;


	if ((bitmap = malloc(sizeof(struct osd_bitmap))) != 0)
	{
		int i,rowlen,rdwidth;
		unsigned char *bm;


		if (depth != 8 && depth != 16) depth = 8;
		
		bitmap->depth = depth;
		bitmap->width = width;
		bitmap->height = height;
		
		rdwidth = (width + 7) & ~7;     /* round width to a quadword */
		if (depth == 16)
			rowlen = 2 * (rdwidth + 2 * safety) * sizeof(unsigned char);
		else
			rowlen =     (rdwidth + 2 * safety) * sizeof(unsigned char);

		if ((bm = malloc((height + 2 * safety) * rowlen)) == 0)
		{
			free(bitmap);
			return 0;
		}

		/* clear ALL bitmap, including safety area, to avoid garbage on right */
		/* side of screen is width is not a multiple of 4 */
		memset(bm,0,(height + 2 * safety) * rowlen);

		if ((bitmap->line = malloc((height + 2 * safety) * sizeof(unsigned char *))) == 0)
		{
			free(bm);
			free(bitmap);
			return 0;
		}

		for (i = 0;i < height + 2 * safety;i++)
		{
			if (depth == 16)
				bitmap->line[i] = &bm[i * rowlen + 2*safety];
			else
			bitmap->line[i] = &bm[i * rowlen + safety];
		}
		bitmap->line += safety;
		
		bitmap->_private = bm;

		osd_clearbitmap(bitmap);
	}
	
	return bitmap;
}



/* set the bitmap to black */
void osd_clearbitmap(struct osd_bitmap *bitmap)
{
	int i;


	for (i = 0;i < bitmap->height;i++)
	{
		if (bitmap->depth == 16)
			memset(bitmap->line[i],0,2*bitmap->width);
		else
			memset(bitmap->line[i],BACKGROUND,bitmap->width);
	}


	if (bitmap == Machine->scrbitmap || bitmap == overlay_real_scrbitmap)
	{
		extern int bitmap_dirty;        /* in mame.c */

		osd_mark_dirty (0,0,bitmap->width-1,bitmap->height-1,1);
		bitmap_dirty = 1;
	}
}



void osd_free_bitmap(struct osd_bitmap *bitmap)
{
	if (bitmap)
	{
		bitmap->line -= safety;
		free(bitmap->line);
		free(bitmap->_private);
		free(bitmap);
	}
}


void osd_mark_dirty(int _x1, int _y1, int _x2, int _y2, int ui)
{
	if (use_dirty)
	{
		int y;
		
//        logerror("mark_dirty %3d,%3d - %3d,%3d\n", _x1,_y1, _x2,_y2);

//		_y1 -= skiplines;
//		_y2 -= skiplines;

//	if (_y1 >= gfx_display_lines || _y2 < 0 || _x1 > gfx_display_columns || _x2 < 0) return;
		if (_y1 < skiplines) _y1 = 0;
		if (_y2 >= (gfx_display_lines + skiplines)) _y2 = gfx_display_lines + skiplines - 1;
//		if (_x1 < 0) _x1 = 0;
//		if (_x2 >= gfx_width) _x2 = gfx_width - 1;

/* Digita, vector games actually need one extra pixel dirty */
		for (y = _y1; y <= _y2 + 2; y++)
//			for (x = _x1; x <= _x2 + 15; x += 16)
				MARKDIRTY(y);
	}
}

static void init_dirty(char dirty)
{
	memset(dirty_new, dirty, MAX_GFX_HEIGHT);
}

INLINE void swap_dirty(void)
{
    char *tmp;

	tmp = dirty_old;
	dirty_old = dirty_new;
	dirty_new = tmp;
}



/*
 * This function tries to find the best display mode.
 */
static void select_display_mode(int width,int height,int depth,int attributes,int orientation)
{
	if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		/* clear the screen */
		{
			int i;
			long * walk_display1 = gLCD_buffer1;
			long * walk_display2 = gLCD_buffer2;
			
			for (i = 0; i < 288*216; i++)
			{
				*walk_display1++ = 0x80108010;
				*walk_display2++ = 0x80108010;
			}
		}

		switch (gResolution)
		{
			case 3:
			{
				gfx_width = 144;
				gfx_height = 216;
				LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
				
				if (use_dirty)
				{
					update_screen = update_screen_expand_nodirty1;
				}
				else
				{
					update_screen = update_screen_expand_nodirty1;
				}
				break;
			}
			case 2:
			{
				gfx_width = 576;
				gfx_height = 216;
				LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
				
				if (use_dirty)
				{
					update_screen = update_screen_stretch_dirty1;
				}
				else
				{
					update_screen = update_screen_stretch_nodirty1;
				}
				break;
			}
			case 1:
			{
				gfx_width = 576;
				gfx_height = 432;
				if (camera_type == kTypeKodak2)
				{
					LMSetupBuffers(gLCD_buffer2, gLCD_buffer1, TRUE);
				}
				else
				{
					LMSetUpInterlacedMode(gLCD_buffer2, gLCD_buffer1);
				}
				
				if (use_dirty)
				{
					update_screen = update_screen_interlace_dirty;
				}
				else
				{
					update_screen = update_screen_interlace_nodirty;
				}
				break;
			}
			case -1:
			{
				gfx_width = 144;
				gfx_height = 108;
				LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
				
				if (use_dirty)
				{
					update_screen = update_screen_double_dirty1;
				}
				else
				{
					update_screen = update_screen_double_nodirty1;
				}
				break;
			}
			case 0:
			default:
			{
				gfx_width = 288;
				gfx_height = 216;
				LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
				
				if (use_dirty)
				{
					update_screen = update_screen_dirty1;
				}
				else
				{
					update_screen = update_screen_nodirty1;
				}
				break;
			}
		}
	}
	else if (camera_type == kTypeHP2)
	{
		if (gResolution > 0)
		{
			gfx_width = 288;
			gfx_height = 216;
			if (use_dirty)
			{
				update_screen = update_screen_dirty2;
			}
			else
			{
				update_screen = update_screen_nodirty2;
			}
		}
		else if (gResolution < 0)
		{
			gfx_width = 144;
			gfx_height = 108;
			if (use_dirty)
			{
				update_screen = update_screen_double_dirty2;
			}
			else
			{
				update_screen = update_screen_double_nodirty2;
			}
		}
		else
		{
			gfx_width = 288;
			gfx_height = 216;
			if (use_dirty)
			{
				update_screen = update_screen_dirty2;
			}
			else
			{
				update_screen = update_screen_nodirty2;
			}
		}
	
		LMSwitchLiveviewMode();
	}
	else if (camera_type == kTypeHP1)
	{
		if (gResolution < 0)
		{
			gfx_width = 180;
			gfx_height = 120;
			if (use_dirty)
			{
				update_screen = update_screen_dirty_dcam1;
			}
			else
			{
				update_screen = update_screen_nodirty_dcam1;
			}
		}
		else
		{
			gfx_width = 360;
			gfx_height = 240;
			if (use_dirty)
			{
				update_screen = update_screen_dirty_dcam1;
			}
			else
			{
				update_screen = update_screen_nodirty_dcam1;
			}
		}
	}
	else if (camera_type == kTypeMinolta1)
	{
		if (gResolution < 0)
		{
			gfx_width = 180;
			gfx_height = 120;
			if (use_dirty)
			{
				update_screen = update_screen_dirty_dcam2;
			}
			else
			{
				update_screen = update_screen_nodirty_dcam2;
			}
		}
		else
		{
			gfx_width = 360;
			gfx_height = 240;
			if (use_dirty)
			{
				update_screen = update_screen_dirty_dcam2;
			}
			else
			{
				update_screen = update_screen_nodirty_dcam2;
			}
		}
		LMSetupBuffers(gLCD_buffer1, gLCD_buffer2, FALSE);
	}

	// set this to our size so we don't try and go over
	options.vector_width = gfx_width;
	options.vector_height = gfx_height;
}



/* center image inside the display based on the visual area */
static void internal_set_visible_area(int min_x,int max_x,int min_y,int max_y,int debugger)
{
	int act_width;

logerror("set visible area %d-%d %d-%d\n",min_x,max_x,min_y,max_y);

		act_width = gfx_width;


	viswidth  = max_x - min_x + 1;
	visheight = max_y - min_y + 1;

		xmultiply = ymultiply = 1;

	gfx_display_lines = visheight;
	gfx_display_columns = viswidth;

	gfx_xoffset = (act_width - viswidth * xmultiply) / 2;
	if (gfx_display_columns > act_width / xmultiply)
		gfx_display_columns = act_width / xmultiply;

	gfx_yoffset = (gfx_height - visheight * ymultiply) / 2;
		if (gfx_display_lines > gfx_height / ymultiply)
			gfx_display_lines = gfx_height / ymultiply;


	skiplinesmin = min_y;
	skiplinesmax = visheight - gfx_display_lines + min_y;
	skipcolumnsmin = min_x;
	skipcolumnsmax = viswidth - gfx_display_columns + min_x;

	/* Align on a quadword !*/
	gfx_xoffset &= ~7;

	/* the skipcolumns from mame.cfg/cmdline is relative to the visible area */
	skipcolumns = min_x + skipcolumns;
	skiplines   = min_y + skiplines;

	/* Just in case the visual area doesn't fit */
	if (gfx_xoffset < 0)
	{
		skipcolumns -= gfx_xoffset;
		gfx_xoffset = 0;
	}
	if (gfx_yoffset < 0)
	{
		skiplines   -= gfx_yoffset;
		gfx_yoffset = 0;
	}

	/* Failsafe against silly parameters */
	if (skiplines < skiplinesmin)
		skiplines = skiplinesmin;
	if (skipcolumns < skipcolumnsmin)
		skipcolumns = skipcolumnsmin;
	if (skiplines > skiplinesmax)
		skiplines = skiplinesmax;
	if (skipcolumns > skipcolumnsmax)
		skipcolumns = skipcolumnsmax;

	logerror("gfx_width = %d gfx_height = %d\n"
				"gfx_xoffset = %d gfx_yoffset = %d\n"
				"xmin %d ymin %d xmax %d ymax %d\n"
				"skiplines %d skipcolumns %d\n"
				"gfx_display_lines %d gfx_display_columns %d\n"
				"xmultiply %d ymultiply %d\n",
				gfx_width,gfx_height,
				gfx_xoffset,gfx_yoffset,
				min_x, min_y, max_x, max_y, skiplines, skipcolumns,gfx_display_lines,gfx_display_columns,xmultiply,ymultiply);

/* Digita, I've discoved that it's actually one less pixel, probably a bug in the UI code */
	set_ui_visarea(skipcolumns, skiplines, skipcolumns+gfx_display_columns-1, skiplines+gfx_display_lines-2);

	/* round to a multiple of 4 to avoid missing pixels on the right side */
	gfx_display_columns  = (gfx_display_columns + 3) & ~3;
}


void osd_set_visible_area(int min_x,int max_x,int min_y,int max_y)
{
	vis_min_x = min_x;
	vis_max_x = max_x;
	vis_min_y = min_y;
	vis_max_y = max_y;
	internal_set_visible_area(min_x,max_x,min_y,max_y,0);
}




/* set the actual display screen but don't allocate the screen bitmap */
static int osd_set_display(int width,int height,int depth,int attributes,int orientation)
{
	int     i;
	
	if (!gfx_height || !gfx_width)
	{
		printf("Please specify height AND width (e.g. -640x480)\n");
		return 0;
	}


	/* Mark the dirty buffers as dirty */

	if (use_dirty)
	{
		if (vector_game)
			/* vector games only use one dirty buffer */
			init_dirty (0);
		else
			init_dirty(1);
		swap_dirty();
		init_dirty(1);
	}
	if (dirtycolor)
	{
		for (i = 0;i < screen_colors;i++)
			dirtycolor[i] = 1;
		dirtypalette = 1;
	}


	gone_to_gfx_mode = 1;

	
	vsync_frame_rate = video_fps;


	warming_up = 1;
	
	return 1;
}


/*
Create a display screen, or window, of the given dimensions (or larger).
Attributes are the ones defined in driver.h.
Returns 0 on success.
*/
int osd_create_display(int width,int height,int depth,int fps,int attributes,int orientation)
{
	logerror("width %d, height %d\n", width,height);

	video_depth = depth;
	video_fps = fps;
	video_attributes = attributes;
	video_orientation = orientation;

	show_debugger = 0;

	brightness = 100;
	brightness_paused_adjust = 1.0;
	dirty_bright = 1;

	if (frameskip < 0) frameskip = 0;
	if (frameskip >= FRAMESKIP_LEVELS) frameskip = FRAMESKIP_LEVELS-1;
	


	gone_to_gfx_mode = 0;

	/* Look if this is a vector game */
	if (attributes & VIDEO_TYPE_VECTOR)
		vector_game = 1;
	else
		vector_game = 0;


	if (use_dirty == -1)	/* dirty=auto in mame.cfg? */
	{
		/* Is the game using a dirty system? */
		if ((attributes & VIDEO_SUPPORTS_DIRTY) || vector_game)
			use_dirty = 1;
		else
			use_dirty = 0;
	}

	select_display_mode(width,height,depth,attributes,orientation);



	if (!osd_set_display(width,height,depth,attributes,orientation))
		return 1;

	/* set visible area to nothing just to initialize it - it will be set by the core */
	osd_set_visible_area(0,0,0,0);

    return 0;
}


/* shut up the display */
void osd_close_display(void)
{
	if (pens823 && (pens823 != (unsigned long *)(M_CPM_MEM1)))
	{
		free(pens823);
		pens823 = 0;
	}

	if (pens823left && (pens823left != (unsigned long *)(M_CPM_MEM2)))
	{
		free(pens823left);
		pens823left = 0;
	}
	
	if (pens823right && (pens823right != (unsigned long *)(M_CPM_MEM3)))
	{
		free(pens823right);
		pens823right = 0;
	}
	
	if (pensDCAM)
	{
		free(pensDCAM);
		pensDCAM = 0;
	}

	if (pensDCAMleft && (pensDCAMleft != (unsigned long *)(M_DPSRAM_MEM0)))
	{
		free(pensDCAMleft);
		pensDCAMleft = 0;
	}
	
	if (pensDCAMright && (pensDCAMright != (unsigned long *)(M_DPSRAM_MEM1)))
	{
		free(pensDCAMright);
		pensDCAMright = 0;
	}
	
	current_display = 0;

	free(dirtycolor);
	dirtycolor = 0;
	free(current_palette);
	current_palette = 0;
}


void osd_debugger_focus(int debugger_has_focus)
{
    if (show_debugger != debugger_has_focus)
	{
		int i;
		show_debugger = debugger_has_focus;
		debugger_focus_changed = 1;
		for (i = 0;i < screen_colors;i++)
			dirtycolor[i] = 1;
		dirtypalette = 1;

		if (!show_debugger)
		{
			/* silly way to clear the screen */
			struct osd_bitmap *clrbitmap;
			clrbitmap = osd_alloc_bitmap(gfx_display_columns,gfx_display_lines,video_depth);
			if (clrbitmap)
			{
				update_screen(clrbitmap);
				osd_free_bitmap(clrbitmap);
			}
		}
	}
}


int osd_allocate_colors(unsigned int totalcolors,
		const UINT8 *palette,UINT16 *pens,int modifiable,
		const UINT8 *debug_palette,UINT16 *debug_pens)
{
	int i;

	modifiable_palette = modifiable;
	screen_colors = totalcolors;
	screen_colors += 2;

	dirtycolor = malloc(screen_colors * sizeof(int));
	current_palette = malloc(3 * screen_colors * sizeof(unsigned char));
	if (dirtycolor == 0 || current_palette == 0)
		return 1;

	for (i = 0;i < screen_colors;i++)
		dirtycolor[i] = 1;
	dirtypalette = 1;
	for (i = 0;i < screen_colors;i++)
		current_palette[3*i+0] = current_palette[3*i+1] = current_palette[3*i+2] = 0;

	if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		if (screen_colors < 512)
		{
			// 2K of zero wait state RAM
			pens823 = (unsigned long *)(M_CPM_MEM1);
			pens823left = (unsigned long *)(M_CPM_MEM2);
			pens823right = (unsigned long *)(M_CPM_MEM3);
		}
		else
		{
			pens823 = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
			pens823left = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
			pens823right = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
		}
	
		// add our black first
		pens823[0] = RGB2YCYC823(0,0,0);
		pens823left[0] = RGB2YCYC823LEFT(0,0,0);
		pens823right[0] = RGB2YCYC823RIGHT(0,0,0);
	
		current_palette[0] = 0;
		current_palette[1] = 0;
		current_palette[2] = 0;
	
		// add our white second
		pens823[1] = RGB2YCYC823(255,255,255);
		pens823left[1] = RGB2YCYC823LEFT(255,255,255);
		pens823right[1] = RGB2YCYC823RIGHT(255,255,255);
	
		current_palette[3] = 255;
		current_palette[4] = 255;
		current_palette[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < screen_colors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			current_palette[3*i+0] = r;
			current_palette[3*i+1] = g;
			current_palette[3*i+2] = b;
			
//			r = 255.0 * pow((float)(r) / 255.0, 1.0 / osd_gamma_correction);
//			g = 255.0 * pow((float)(g) / 255.0, 1.0 / osd_gamma_correction);
//			b = 255.0 * pow((float)(b) / 255.0, 1.0 / osd_gamma_correction);

			r = r * brightness * brightness_paused_adjust / 100.0;
			g = g * brightness * brightness_paused_adjust / 100.0;
			b = b * brightness * brightness_paused_adjust / 100.0;
			
			pens[x] = i;
			pens823[i] = RGB2YCYC823(r,g,b);
			pens823left[i] = RGB2YCYC823LEFT(r,g,b);
			pens823right[i] = RGB2YCYC823RIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;
	}
	else if (camera_type == kTypeHP2)
	{
		pens823 = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
		pens823left = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
		pens823right = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
	
		current_palette = (unsigned char *)malloc(3 * screen_colors * sizeof(unsigned char));
	
		// add our black first
		pens823[0] = RGB2YCYC823(0,0,0);
		pens823left[0] = RGB2YCYC823LEFT(0,0,0);
		pens823right[0] = RGB2YCYC823RIGHT(0,0,0);
	
		current_palette[0] = 0;
		current_palette[1] = 0;
		current_palette[2] = 0;
	
		// add our white second
		pens823[1] = RGB2YCYC823(255,255,255);
		pens823left[1] = RGB2YCYC823LEFT(255,255,255);
		pens823right[1] = RGB2YCYC823RIGHT(255,255,255);
	
		current_palette[3] = 255;
		current_palette[4] = 255;
		current_palette[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < screen_colors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			current_palette[3*i+0] = r;
			current_palette[3*i+1] = g;
			current_palette[3*i+2] = b;
			
//			r = 255.0 * pow((float)(r) / 255.0, 1.0 / osd_gamma_correction);
//			g = 255.0 * pow((float)(g) / 255.0, 1.0 / osd_gamma_correction);
//			b = 255.0 * pow((float)(b) / 255.0, 1.0 / osd_gamma_correction);

			r = r * brightness * brightness_paused_adjust / 100.0;
			g = g * brightness * brightness_paused_adjust / 100.0;
			b = b * brightness * brightness_paused_adjust / 100.0;

			pens[x] = i;
			pens823[i] = RGB2YCYC823(r,g,b);
			pens823left[i] = RGB2YCYC823LEFT(r,g,b);
			pens823right[i] = RGB2YCYC823RIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;
	}
	else if ((camera_type == kTypeMinolta1) || (camera_type == kTypeHP1))
	{
		if (screen_colors < 512)
		{
			// 2K of zero wait state RAM
			pensDCAM = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
			pensDCAMleft = (unsigned long *)(M_DPSRAM_MEM0);
			pensDCAMright = (unsigned long *)(M_DPSRAM_MEM1);
		}
		else
		{
			pensDCAM = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
			pensDCAMleft = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
			pensDCAMright = (unsigned long *)malloc(screen_colors * sizeof(unsigned long));
		}
	
		current_palette = (unsigned char *)malloc(3 * screen_colors * sizeof(unsigned char));
	
		// add our black first
		pensDCAM[0] = RGB2CYCYDCAM(0,0,0);
		pensDCAMleft[0] = RGB2CYCYDCAMLEFT(0,0,0);
		pensDCAMright[0] = RGB2CYCYDCAMRIGHT(0,0,0);
	
		current_palette[0] = 0;
		current_palette[1] = 0;
		current_palette[2] = 0;
	
		// add our white second
		pensDCAM[1] = RGB2CYCYDCAM(255,255,255);
		pensDCAMleft[1] = RGB2CYCYDCAMLEFT(255,255,255);
		pensDCAMright[1] = RGB2CYCYDCAMRIGHT(255,255,255);
	
		current_palette[3] = 255;
		current_palette[4] = 255;
		current_palette[5] = 255;
	
		// OK start with number 2 and continue to the end of the list
		for (i = 2;i < screen_colors;i++)
		{
			int r,g,b,x;
			
			x = i - 2;
			
			r = palette[3*x+0];
			g = palette[3*x+1];
			b = palette[3*x+2];
			
			current_palette[3*i+0] = r;
			current_palette[3*i+1] = g;
			current_palette[3*i+2] = b;
			
//			r = 255.0 * pow((float)(r) / 255.0, 1.0 / osd_gamma_correction);
//			g = 255.0 * pow((float)(g) / 255.0, 1.0 / osd_gamma_correction);
//			b = 255.0 * pow((float)(b) / 255.0, 1.0 / osd_gamma_correction);

			r = r * brightness * brightness_paused_adjust / 100.0;
			g = g * brightness * brightness_paused_adjust / 100.0;
			b = b * brightness * brightness_paused_adjust / 100.0;

			pens[x] = i;
			pensDCAM[1] = RGB2CYCYDCAM(r,g,b);
			pensDCAMleft[i] = RGB2CYCYDCAMLEFT(r,g,b);
			pensDCAMright[i] = RGB2CYCYDCAMRIGHT(r,g,b);
		}
	
		Machine->uifont->colortable[0] = 0;
		Machine->uifont->colortable[1] = 1;
		Machine->uifont->colortable[2] = 1;
		Machine->uifont->colortable[3] = 0;	
	}
	
	return 0;
}


void osd_modify_pen(int pen,unsigned char red, unsigned char green, unsigned char blue)
{
	if (modifiable_palette == 0)
	{
		logerror("error: osd_modify_pen() called with modifiable_palette == 0\n");
		return;
	}


	if (	current_palette[3*pen+0] != red ||
			current_palette[3*pen+1] != green ||
			current_palette[3*pen+2] != blue)
	{
		current_palette[3*pen+0] = red;
		current_palette[3*pen+1] = green;
		current_palette[3*pen+2] = blue;

		dirtycolor[pen] = 1;
		dirtypalette = 1;
	
		if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1) || (camera_type == kTypeKodak2) || (camera_type == kTypeHP2))
		{
			if (pens823)
			{
				pens823[pen] = RGB2YCYC823(red,green,blue);
			}
			if (pens823left)
			{
				pens823left[pen] = RGB2YCYC823LEFT(red,green,blue);
			}
			if (pens823right)
			{
				pens823right[pen] = RGB2YCYC823RIGHT(red,green,blue);
			}
		}
		else if ((camera_type == kTypeMinolta1) || (camera_type == kTypeHP1))
		{
			if (pensDCAMleft)
			{
				pensDCAMleft[pen] = RGB2CYCYDCAMLEFT(red,green,blue);
			}
			if (pensDCAMright)
			{
				pensDCAMright[pen] = RGB2CYCYDCAMRIGHT(red,green,blue);
			}
		}
		
		// mark the whole screen dirty
		osd_mark_dirty(0, 0, Machine->scrbitmap->width-1,Machine->scrbitmap->height-1,1);
	}	
}



void osd_get_pen(int pen,unsigned char *red, unsigned char *green, unsigned char *blue)
{
	if (current_palette)
	{
		*red =	 current_palette[3*pen+0];
		*green = current_palette[3*pen+1];
		*blue =  current_palette[3*pen+2];
	}
	else
	{
		*red = 0;
		*green = 0;
		*blue = 0;
	}
}



static void update_screen_dummy(struct osd_bitmap *bitmap)
{
	logerror("digita/video.c: undefined update_screen() function for %d x %d!\n",xmultiply,ymultiply);
}

INLINE void pan_display(void)
{
	int pan_changed = 0;

	/* horizontal panning */
	if (input_ui_pressed_repeat(IPT_UI_PAN_LEFT,1))
		if (skipcolumns < skipcolumnsmax)
		{
			skipcolumns++;
			osd_mark_dirty (0,0,Machine->scrbitmap->width-1,Machine->scrbitmap->height-1,1);
			pan_changed = 1;
		}
	if (input_ui_pressed_repeat(IPT_UI_PAN_RIGHT,1))
		if (skipcolumns > skipcolumnsmin)
		{
			skipcolumns--;
			osd_mark_dirty (0,0,Machine->scrbitmap->width-1,Machine->scrbitmap->height-1,1);
			pan_changed = 1;
		}
	if (input_ui_pressed_repeat(IPT_UI_PAN_DOWN,1))
		if (skiplines < skiplinesmax)
		{
			skiplines++;
			osd_mark_dirty (0,0,Machine->scrbitmap->width-1,Machine->scrbitmap->height-1,1);
			pan_changed = 1;
		}
	if (input_ui_pressed_repeat(IPT_UI_PAN_UP,1))
		if (skiplines > skiplinesmin)
		{
			skiplines--;
			osd_mark_dirty (0,0,Machine->scrbitmap->width-1,Machine->scrbitmap->height-1,1);
			pan_changed = 1;
		}

	if (pan_changed)
	{
		if (use_dirty) init_dirty(1);

/* Digita, I've discoved that it's actually one less pixel, probably a bug in the UI code */
		set_ui_visarea (skipcolumns, skiplines, skipcolumns+gfx_display_columns-1, skiplines+gfx_display_lines-2);
	}
}



int osd_skip_this_frame(void)
{
	static const int skiptable[FRAMESKIP_LEVELS][FRAMESKIP_LEVELS] =
	{
		{ 0,0,0,0,0,0,0,0,0,0,0,0 },
		{ 0,0,0,0,0,0,0,0,0,0,0,1 },
		{ 0,0,0,0,0,1,0,0,0,0,0,1 },
		{ 0,0,0,1,0,0,0,1,0,0,0,1 },
		{ 0,0,1,0,0,1,0,0,1,0,0,1 },
		{ 0,1,0,0,1,0,1,0,0,1,0,1 },
		{ 0,1,0,1,0,1,0,1,0,1,0,1 },
		{ 0,1,0,1,1,0,1,0,1,1,0,1 },
		{ 0,1,1,0,1,1,0,1,1,0,1,1 },
		{ 0,1,1,1,0,1,1,1,0,1,1,1 },
		{ 0,1,1,1,1,1,0,1,1,1,1,1 },
		{ 0,1,1,1,1,1,1,1,1,1,1,1 }
	};

	return skiptable[frameskip][frameskip_counter];
}

/* Update the display. */
void osd_update_video_and_audio(struct osd_bitmap *game_bitmap,struct osd_bitmap *debug_bitmap)
{
	static const int waittable[FRAMESKIP_LEVELS][FRAMESKIP_LEVELS] =
	{
		{ 1,1,1,1,1,1,1,1,1,1,1,1 },
		{ 2,1,1,1,1,1,1,1,1,1,1,0 },
		{ 2,1,1,1,1,0,2,1,1,1,1,0 },
		{ 2,1,1,0,2,1,1,0,2,1,1,0 },
		{ 2,1,0,2,1,0,2,1,0,2,1,0 },
		{ 2,0,2,1,0,2,0,2,1,0,2,0 },
		{ 2,0,2,0,2,0,2,0,2,0,2,0 },
		{ 2,0,2,0,0,3,0,2,0,0,3,0 },
		{ 3,0,0,3,0,0,3,0,0,3,0,0 },
		{ 4,0,0,0,4,0,0,0,4,0,0,0 },
		{ 6,0,0,0,0,0,6,0,0,0,0,0 },
		{12,0,0,0,0,0,0,0,0,0,0,0 }
	};
	int i;
	static int showfps,showfpstemp;
	TICKER curr;
	static TICKER prev_measure,this_frame_base,prev;
	static int speed = 100;
	static int vups,vfcount;
	int have_to_clear_bitmap = 0;
	int already_synced;
	struct osd_bitmap *bitmap;


	if (debug_bitmap && keyboard_pressed_memory(KEYCODE_F5))
	{
		osd_debugger_focus(show_debugger ^ 1);
	}

	if (debugger_focus_changed)
	{
		debugger_focus_changed = 0;

		if (show_debugger)
			internal_set_visible_area(0,debug_bitmap->width-1,0,debug_bitmap->height-1,1);
		else
			internal_set_visible_area(vis_min_x,vis_max_x,vis_min_y,vis_max_y,0);
	}

	if (show_debugger && debug_bitmap) bitmap = debug_bitmap;
	else bitmap = game_bitmap;

	if (warming_up)
	{
		/* first time through, initialize timer */
		prev_measure = ticker() - FRAMESKIP_LEVELS * TICKS_PER_SEC/video_fps;
		warming_up = 0;
	}

	if (frameskip_counter == 0)
		this_frame_base = prev_measure + FRAMESKIP_LEVELS * TICKS_PER_SEC/video_fps;

	if (throttle)
	{
		static TICKER last;

		/* if too much time has passed since last sound update, disable throttling */
		/* temporarily - we wouldn't be able to keep synch anyway. */
		curr = ticker();
		if ((curr - last) > 2*TICKS_PER_SEC / video_fps)
			throttle = 0;
		last = curr;

		already_synced = 1;

		throttle = 1;
	}
	else
		already_synced = 1;


	if (osd_skip_this_frame() == 0)
	{
		if (showfpstemp)
		{
			showfpstemp--;
			if (showfps == 0 && showfpstemp == 0)
			{
				have_to_clear_bitmap = 1;
			}
		}


		if (input_ui_pressed(IPT_UI_SHOW_FPS))
		{
			if (showfpstemp)
			{
				showfpstemp = 0;
				have_to_clear_bitmap = 1;
			}
			else
			{
				showfps ^= 1;
				if (showfps == 0)
				{
					have_to_clear_bitmap = 1;
				}
			}
		}


		/* now wait until it's time to update the screen */
		if (throttle)
		{
			profiler_mark(PROFILER_IDLE);
			{
				TICKER target;

				
				/* wait for video sync but use normal throttling */
//				if (wait_vsync)
//					vsync();

				curr = ticker();

				if (already_synced == 0)
				{
			/* wait only if the audio update hasn't synced us already */

					target = this_frame_base +
							frameskip_counter * TICKS_PER_SEC/video_fps;

			if (curr - target < 0)
			{
				do
				{
							curr = ticker();
				} while (curr - target < 0);
			}
				}

			}
			profiler_mark(PROFILER_END);
		}
		else curr = ticker();

		
		/* for the FPS average calculation */
		if (++frames_displayed == FRAMES_TO_SKIP)
			start_time = curr;
		else
			end_time = curr;

		
		if (frameskip_counter == 0)
		{
			int divdr;

/* Digita, fix overflow in floating point */
			divdr = video_fps * (curr - prev_measure) / (10 * FRAMESKIP_LEVELS);
			speed = (TICKS_PER_SEC + divdr/2) * 10 / divdr;

			prev_measure = curr;
		}
				
		prev = curr;

		vfcount += waittable[frameskip][frameskip_counter];
		if (vfcount >= video_fps)
		{
			extern int vector_updates; /* avgdvg_go_w()'s per Mame frame, should be 1 */


			vfcount = 0;
			vups = vector_updates;
			vector_updates = 0;
		}

		if (!show_debugger && (showfps || showfpstemp))
		{
			int fps;
			char buf[30];
			int divdr;


			divdr = 100 * FRAMESKIP_LEVELS;
			fps = (video_fps * (FRAMESKIP_LEVELS - frameskip) * speed + (divdr / 2)) / divdr;
			sprintf(buf,"%s%2d%4d%%%4d/%d fps",autoframeskip?"auto":"fskp",frameskip,speed,fps,(int)(video_fps+0.5));
			ui_text(bitmap,buf,Machine->uiwidth-strlen(buf)*Machine->uifontwidth,0);
			if (vector_game)
			{
				sprintf(buf," %d vector updates",vups);
				ui_text(bitmap,buf,Machine->uiwidth-strlen(buf)*Machine->uifontwidth,Machine->uifontheight);
			}
		}

		{
			if (dirty_bright)
			{
				dirty_bright = 0;
				for (i = 0;i < 256;i++)
				{
					int r;
					
					r = i;
					
//					r = 63.0 * pow((float)(r) / 255.0, 1.0 / osd_gamma_correction);
					
					r = r * brightness * brightness_paused_adjust / 100.0;

					bright_lookup[i] = r;
				}
			}
			if (dirtypalette)
			{
				dirtypalette = 0;
				{
					for (i = 2;i < screen_colors;i++)
					{
						if (dirtycolor[i])
						{
							int r,g,b;
							
							dirtycolor[i] = 0;
							
							r = current_palette[3*i+0];
							g = current_palette[3*i+1];
							b = current_palette[3*i+2];
							
							r = bright_lookup[r];
							g = bright_lookup[g];
							b = bright_lookup[b];
				
							pens823[i] = RGB2YCYC823(r,g,b);
							pens823left[i] = RGB2YCYC823LEFT(r,g,b);
							pens823right[i] = RGB2YCYC823RIGHT(r,g,b);
						}
					}
				}
			}
		}

		if (show_debugger)
		{
			update_screen(bitmap);
        }
		else
		{
			/* copy the bitmap to screen memory */
			profiler_mark(PROFILER_BLIT);
			update_screen(bitmap);
			profiler_mark(PROFILER_END);
		}

		/* see if we need to give the card enough time to draw both odd/even fields of the interlaced display
			(req. for 15.75KHz Arcade Monitor Modes */
//		interlace_sync();


		if (!show_debugger && have_to_clear_bitmap)
			osd_clearbitmap(bitmap);

		if (use_dirty)
		{
			if (!vector_game)
				swap_dirty();
			init_dirty(0);
		}

		if (!show_debugger && have_to_clear_bitmap)
			osd_clearbitmap(bitmap);


		if (throttle && autoframeskip && frameskip_counter == 0)
		{
			static int frameskipadjust;
			int adjspeed;

			/* adjust speed to video refresh rate if vsync is on */
			adjspeed = speed * video_fps / vsync_frame_rate;

			if (adjspeed >= 100)
			{
				frameskipadjust++;
				if (frameskipadjust >= 3)
				{
					frameskipadjust = 0;
					if (frameskip > 0) frameskip--;
				}
			}
			else
			{
				if (adjspeed < 80)
					frameskipadjust -= (90 - adjspeed) / 5;
				else
				{
					/* don't push frameskip too far if we are close to 100% speed */
					if (frameskip < 8)
						frameskipadjust--;
				}

				while (frameskipadjust <= -2)
				{
					frameskipadjust += 2;
					/* Digita, we don't work so well with frameskip of 12 */
					if (frameskip < 8) frameskip++;
				}
			}
		}
	}

	/* Check for PGUP, PGDN and pan screen */
	pan_display();

	if (input_ui_pressed(IPT_UI_FRAMESKIP_INC))
	{
		if (autoframeskip)
		{
			autoframeskip = 0;
			frameskip = 0;
		}
		else
		{
			if (frameskip == FRAMESKIP_LEVELS-1)
			{
				frameskip = 0;
				autoframeskip = 1;
			}
			else
				frameskip++;
		}

		if (showfps == 0)
			showfpstemp = 2*video_fps;

		/* reset the frame counter every time the frameskip key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}

	if (input_ui_pressed(IPT_UI_FRAMESKIP_DEC))
	{
		if (autoframeskip)
		{
			autoframeskip = 0;
			frameskip = FRAMESKIP_LEVELS-1;
		}
		else
		{
			if (frameskip == 0)
				autoframeskip = 1;
			else
				frameskip--;
		}

		if (showfps == 0)
			showfpstemp = 2*video_fps;

		/* reset the frame counter every time the frameskip key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}

	if (input_ui_pressed(IPT_UI_THROTTLE))
	{
		throttle ^= 1;

		/* reset the frame counter every time the throttle key is pressed, so */
		/* we'll measure the average FPS on a consistent status. */
		frames_displayed = 0;
	}


	frameskip_counter = (frameskip_counter + 1) % FRAMESKIP_LEVELS;

//	poll_joysticks();
}



void osd_set_gamma(float _gamma)
{
	int i;

	osd_gamma_correction = _gamma;

	for (i = 0;i < screen_colors;i++)
		dirtycolor[i] = 1;
	dirtypalette = 1;
	dirty_bright = 1;
}

float osd_get_gamma(void)
{
	return osd_gamma_correction;
}

/* brightess = percentage 0-100% */
void osd_set_brightness(int _brightness)
{
	int i;

	brightness = _brightness;

	for (i = 0;i < screen_colors;i++)
		dirtycolor[i] = 1;
	dirtypalette = 1;
	dirty_bright = 1;
}

int osd_get_brightness(void)
{
	return brightness;
}


void osd_save_snapshot(struct osd_bitmap *bitmap)
{
	save_screen_snapshot(bitmap);
}

void osd_pause(int paused)
{
	int i;

	if (paused) brightness_paused_adjust = 0.65;
	else brightness_paused_adjust = 1.0;

	for (i = 0;i < screen_colors;i++)
		dirtycolor[i] = 1;
	dirtypalette = 1;
	dirty_bright = 1;
}

void osd_mark_vector_dirty(int x, int y)
{
	MARKDIRTY(y);
}

