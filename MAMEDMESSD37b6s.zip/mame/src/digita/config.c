
/*
 * Configuration routines.
 *
 * 19971219 support for mame.cfg by Valerio Verrando
 * 19980402 moved out of msdos.c (N.S.), generalized routines (BW)
 * 19980917 added a "-cheatfile" option (misc) in MAME.CFG      JCK
 */

//#include "mamalleg.h"
#include "driver.h"
#include <ctype.h>
/* types of monitors supported */
//#include "monitors.h"
/* from main() */
extern int ignorecfg;

/* from video.c */
extern int frameskip,autoframeskip;
extern int scanlines, use_tweaked, video_sync, wait_vsync, use_triplebuf;
extern int stretch, use_mmx, use_dirty;
extern int vgafreq, always_synced, skiplines, skipcolumns;
extern float osd_gamma_correction;
extern int gfx_mode, gfx_width, gfx_height;
#ifdef DIGITA_SERIAL
extern int keyboard_type;
#endif

/* from sound.c */
extern int soundcard, usestereo,attenuation;

/* from input.c */
extern int use_mouse, joystick, use_hotrod;

/* from cheat.c */
extern char *cheatfile;

/* from datafile.c */
extern char *history_filename,*mameinfo_filename;

/* from hiscore.c */
extern char *db_filename;

/* from fileio.c */
void decompose_rom_sample_path (char *rompath, char *samplepath);

#ifdef MESS
void decompose_software_path (char *softwarepath);
#endif

extern char *nvdir, *hidir, *cfgdir, *inpdir, *stadir, *memcarddir;
extern char *artworkdir, *screenshotdir, *alternate_name;

extern char *cheatdir;

#ifdef MESS
/* path to the CRC database files */
char *crcdir;
char *softwarepath;  /* for use in fileio.c */
#define CHEAT_NAME	"/B/SYSTEM/CHEAT.CDB"
#define HISTRY_NAME "/B/SYSTEM/SYSINFO.DAT"
#else
#define CHEAT_NAME	"/B/SYSTEM/CHEAT.DAT"
#define HISTRY_NAME "/B/SYSTEM/HISTORY.DAT"
#endif

/* from video.c, for centering tweaked modes */
//extern int center_x;
//extern int center_y;

/*from video.c flag for 15.75KHz modes (req. for 15.75KHz Arcade Monitor Modes)*/
extern int arcade_mode;

/*from svga15kh.c flag to allow delay for odd/even fields for interlaced displays (req. for 15.75KHz Arcade Monitor Modes)*/
extern int wait_interlace;

extern int gResolution;
extern int gPadOrientation;
extern int play_sound;
extern int cpu_slices_per_frame_override;
extern int auto_rotate;

static int game;
char *rompath, *samplepath;

struct { char *name; int id; } joy_table[] =
{
	{ 0, 0 }
} ;



/* monitor type */
struct { char *name; int id; } monitor_table[] =
{
	{ NULL, NULL }
} ;

char *safeget(char *local_buffer, int len, FILE *file)
{
	char *ret;
	
	*local_buffer = 0;
	ret = 0;
	if (file)
	{
		ret = fgets(local_buffer, len, file);
		if (ret)
		{
			local_buffer[len] = 0;
			len = strlen(local_buffer);
			if (len)
			{
				// cut off cr-lf at end
				if(local_buffer[len-1] < 32)
				{
					local_buffer[len-1] = 0;
				}
				if(local_buffer[len-2] < 32)
				{
					local_buffer[len-2] = 0;
				}
			}
		}
	}
	
	return ret;
}

static char * cfgfname;

void set_config_file(char * fname)
{
	cfgfname = fname;
}

static char	storage_buffer[1024];

char * get_config_string(char * section, char * option, char * def)
{
	FILE 			*file;
	char  			*work1 = NULL;
	char 			*work2 = NULL;
	int				n;
	int				found;
	char			*found_section = NULL;

	file = fopen(cfgfname,"r");
	if (file == NULL)
	{
		return def;
	}

	found = FALSE;
	while (safeget (storage_buffer, 1023, file) != NULL)
	{
		/* Ignore commented and blank lines */
		if (storage_buffer[0] == ';') continue;
		if (storage_buffer[0] == '\n') continue;
		if (storage_buffer[0] == '#') continue;

		if (storage_buffer[0] == '[')
		{
			char * ptr;
			
			ptr = strtok (&storage_buffer[1], "]");
			/* Found a section, indicate as such */
			
			if (strstr(section, ptr))
				found_section = section;
			else
				found_section = NULL;
			
			/* Skip to the next line */
			continue;
		}

		if (strcmp (section, found_section) == 0)
		{
			if (!strstr(storage_buffer, "#") && strstr(storage_buffer, option))
			{
				found = TRUE;
				break;
			}
		}
	}
	
	if (found == TRUE)
	{
		work1 = strstr(storage_buffer, "=");
		if (work1)
		{
			work1++;
			n = (int)(work1-storage_buffer);
			
			while(isspace(*work1) && (n < strlen(storage_buffer)))
			{
				work1++;
				n++;
			}
			
			if (n < strlen(storage_buffer))
			{
				work2 = &storage_buffer[strlen(storage_buffer - 1)];
				while(isspace(*work2) && work2 != work1)
				{
					work2--;
				}
				work2++;
				*work2 = 0;
			}
		}
		else
		{
			work1 = def;
		}
	}
	else
	{
		work1 = def;
	}

	fclose(file);

	return work1;
}

void set_config_string(char * section, char * option, char * def)
{
	// not implemented yet
}

int get_config_int(char * section, char * option, int def)
{
	char *s = get_config_string(section, option, NULL);

	if (s)
	{
		return atoi(s);
	}
	return def;
}

void set_config_int(char * section, char * option, int def)
{
	// not implemented yet
}

float get_config_float(char * section, char * option, float def)
{
	char *s = get_config_string(section, option, NULL);

	if (s)
	{
		int tmp = atoi(s);
		return (float)(tmp) / 1000.0;
	}
	return def;
}

void set_config_float(char * section, char * option, float def)
{
	// not implemented yet
}

/*
 * gets some boolean config value.
 * 0 = false, >0 = true, <0 = auto
 * the shortcut can only be used on the commandline
 */
static int get_bool (char *section, char *option, char *shortcut, int def)
{
	char *yesnoauto;
	int res;

	res = def;

	if (ignorecfg) goto cmdline;

	/* look into mame.cfg, [section] */
	if (def == 0)
		yesnoauto = get_config_string(section, option, "no");
	else if (def > 0)
		yesnoauto = get_config_string(section, option, "yes");
	else /* def < 0 */
		yesnoauto = get_config_string(section, option, "auto");

	/* if the option doesn't exist in the cfgfile, create it */
	if (get_config_string(section, option, "#") == "#")
		set_config_string(section, option, yesnoauto);

	/* look into mame.cfg, [gamename] */
//	yesnoauto = get_config_string((char *)drivers[game]->name, option, yesnoauto);

	/* also take numerical values instead of "yes", "no" and "auto" */
	if		(stricmp(yesnoauto, "no"  ) == 0) res = 0;
	else if (stricmp(yesnoauto, "yes" ) == 0) res = 1;
	else if (stricmp(yesnoauto, "auto") == 0) res = -1;
	else	res = atoi (yesnoauto);

cmdline:
	return res;
}

static int get_int (char *section, char *option, char *shortcut, int def)
{
	int res;

	res = def;

	if (!ignorecfg)
	{
		/* if the option does not exist, create it */
		if (get_config_int (section, option, -777) == -777)
			set_config_int (section, option, def);

		/* look into mame.cfg, [section] */
		res = get_config_int (section, option, def);

		/* look into mame.cfg, [gamename] */
//		res = get_config_int ((char *)drivers[game]->name, option, res);
	}

	return res;
}

static float get_float (char *section, char *option, char *shortcut, float def)
{
	float res;

	res = def;

	if (!ignorecfg)
	{
		/* if the option does not exist, create it */
		if (get_config_float (section, option, 9999.0) == 9999.0)
			set_config_float (section, option, def);

		/* look into mame.cfg, [section] */
		res = get_config_float (section, option, def);

		/* look into mame.cfg, [gamename] */
//		res = get_config_float ((char *)drivers[game]->name, option, res);
	}

	return res;
}

static char *get_string (char *section, char *option, char *shortcut, char *def)
{
	char *res;

	res = def;

	if (!ignorecfg)
	{
		/* if the option does not exist, create it */
		if (get_config_string (section, option, "#") == "#" )
			set_config_string (section, option, def);

		/* look into mame.cfg, [section] */
		res = get_config_string(section, option, def);

		/* look into mame.cfg, [gamename] */
//		res = get_config_string((char*)drivers[game]->name, option, res);
	}

	return res;
}


static char *get_string_alloc (char *section, char *option, char *shortcut, char *def)
{
	char * tmp;
	char * res;
	
	res = def;
	
	tmp = get_string(section, option, shortcut, def);
	
	if (def != tmp)
	{
		res = malloc(strlen(tmp)+1);
		
		memcpy(res, tmp, strlen(tmp)+1);
	}
		
	return res;
}

void get_rom_sample_path (int game_index)
{
	alternate_name = 0;
	game = game_index;

	rompath = NULL;
	if (rompath == NULL || rompath[0] == 0)
	{
#ifndef MESS
		rompath    = get_string_alloc ("directory", "rompath",    NULL, "/B/SYSTEM/ROMS");
#else
		rompath    = get_string_alloc ("directory", "biospath",   NULL, "/B/SYSTEM/BIOS");
#endif
	}

#ifndef MESS
	samplepath = get_string_alloc ("directory", "samplepath", NULL, "/B/SYSTEM/SAMPLES");
#else
	softwarepath= get_string_alloc ("directory", "softwarepath", NULL, "/B/SYSTEM/SOFTWARE");
#endif

	/* decompose paths into components (handled by fileio.c) */
	decompose_rom_sample_path (rompath, samplepath);
}


/* for playback of .inp files */
void init_inpdir(void)
{
	inpdir = get_string_alloc ("directory", "inp",     NULL, "INP");
}

void parse_cmdline (int game_index)
{
	static float f_beam, f_flicker;
	char *tmpstr;

	/* read graphic configuration */
	options.use_artwork = get_bool	 ("config", "artwork",  NULL,  options.use_artwork);
	options.use_samples = get_bool	 ("config", "samples",  NULL,  options.use_samples);
	use_dirty	= get_bool	 ("config", "dirty",    NULL,   use_dirty);
	options.antialias	= get_bool	 ("config", "antialias",    NULL,  1);
	options.translucency = get_bool    ("config", "translucency", NULL, 1);

	skiplines	= get_int	 ("config", "skiplines",    NULL, 0);
	skipcolumns = get_int	 ("config", "skipcolumns",  NULL, 0);
	f_beam		= get_float  ("config", "beam",         NULL, 1.0);
	if (f_beam < 1.0) f_beam = 1.0;
	if (f_beam > 16.0) f_beam = 16.0;
	f_flicker	= get_float  ("config", "flicker",      NULL, 0.0);
	if (f_flicker < 0.0) f_flicker = 0.0;
	if (f_flicker > 100.0) f_flicker = 100.0;
	osd_gamma_correction = get_float ("config", "gamma",   NULL, 1.0);
	if (osd_gamma_correction < 0.5) osd_gamma_correction = 0.5;
	if (osd_gamma_correction > 2.0) osd_gamma_correction = 2.0;

	tmpstr			   = get_string_alloc ("config", "frameskip", "fs", "auto");
	if (!stricmp(tmpstr,"auto"))
	{
		frameskip = 0;
		autoframeskip = 1;
	}
	else
	{
		frameskip = atoi(tmpstr);
		autoframeskip = 0;
	}
	options.norotate  = get_bool ("config", "norotate",  NULL, options.norotate);
	options.ror 	  = get_bool ("config", "ror",       NULL, options.ror);
	options.rol 	  = get_bool ("config", "rol",       NULL, options.rol);
	options.flipx	  = get_bool ("config", "flipx",     NULL, options.flipx);
	options.flipy	  = get_bool ("config", "flipy",     NULL, options.flipy);

	/* read sound configuration */

	attenuation 		= get_int  ("config", "volume",  NULL,  0);
	if (attenuation < -32) attenuation = -32;
	if (attenuation > 0) attenuation = 0;

	/* misc configuration */
	options.cheat	   = get_bool ("config", "cheat", NULL, 0);
	options.mame_debug = get_bool ("config", "debug", NULL, 0);

	cheatfile = get_string_alloc ("config", "cheatfile", "cf", CHEAT_NAME );

	history_filename  = get_string_alloc ("config", "historyfile", NULL, HISTRY_NAME);
	mameinfo_filename  = get_string_alloc ("config", "mameinfofile", NULL, "/B/SYSTEM/MAMEINFO.DAT");    /* JCK 980917 */
	db_filename  = get_string_alloc ("config", "hiscorefile", NULL, "/B/SYSTEM/HISCORE.DAT");

	/* set default subdirectories */
#ifndef MESS
	nvdir		= get_string_alloc ("directory", "nvram",   NULL, "/B/SYSTEM/NVRAM");
	hidir		= get_string_alloc ("directory", "hidir",      NULL, "/B/SYSTEM/HI");
	memcarddir	= get_string_alloc ("directory", "memcard", NULL, "/B/SYSTEM/MEMCARD");
	stadir		= get_string_alloc ("directory", "sta",     NULL, "/B/SYSTEM/STA");
	cheatdir	= get_string_alloc ("directory", "cheatdir",   NULL, "/B/SYSTEM/");
#else
	crcdir		= get_string_alloc ("directory",  "crc",     NULL, "/B/SYSTEM/CRC");
	cheatdir	= get_string_alloc ("directory",  "cheatdir",   NULL, "/B/SYSTEM/CHEAT");
#endif
	artworkdir	= get_string_alloc ("directory", "artdir", NULL, "/B/SYSTEM/ARTWORK");
	cfgdir		= get_string_alloc ("directory", "cfg",     NULL, "/B/SYSTEM/CFG");
	screenshotdir = get_string_alloc ("directory", "snap", NULL, "/B/SYSTEM/SNAP");


	logerror("cheatfile = %s - cheatdir = %s\n",cheatfile,cheatdir);

	tmpstr = get_string_alloc ("config", "language", NULL, "english");
	options.language_file = osd_fopen(0,tmpstr,OSD_FILETYPE_LANGUAGE,0);

	/* this is handled externally cause the audit stuff needs it, too */
	get_rom_sample_path (game_index);

	/* get -centerx */
//	center_x = get_int ("config", "centerx", NULL,  0);
	/* get -centery */
//	center_y = get_int ("config", "centery", NULL,  0);

	/* process some parameters */
	options.beam = (int)(f_beam * 0x00010000);
	if (options.beam < 0x00010000)
		options.beam = 0x00010000;
	if (options.beam > 0x00100000)
		options.beam = 0x00100000;

	options.flicker = (int)(f_flicker * 2.55);
	if (options.flicker < 0)
		options.flicker = 0;
	if (options.flicker > 255)
		options.flicker = 255;

	if (options.mame_debug)
	{
		options.debug_width = gfx_width = 640;
		options.debug_height = gfx_height = 480;
		options.vector_width = gfx_width;
		options.vector_height = gfx_height;
		use_dirty = 0;
	}

#ifdef MESS
	/* Is there an override for softwarepath= for this driver? */
	tmpstr = get_string_alloc ("directory", "softwarepath", NULL, NULL);
	if (tmpstr)
		softwarepath = tmpstr;
	logerror("Using Software Path %s\n", softwarepath);
	decompose_software_path(softwarepath);
#endif

	tmpstr = get_string("MAMED", "Auto Rotate", NULL, "Auto Right");
	if (!stricmp(tmpstr, "Off"))
		auto_rotate = 0;
	else if (!stricmp(tmpstr, "Auto Right"))
		auto_rotate = 1;
	else if (!stricmp(tmpstr, "Auto Left"))
		auto_rotate = 2;
	else
		auto_rotate = 1;

	tmpstr	= get_string("MAMED", "Resolution", NULL, "Med");
	if (!stricmp(tmpstr, "Low"))
		gResolution = -1;
	else if (!stricmp(tmpstr, "Med"))
		gResolution = 0;
	else if (!stricmp(tmpstr, "High"))
		gResolution = 1;
	else if (!stricmp(tmpstr, "High"))
		gResolution = 1;
	else if (!stricmp(tmpstr, "Stretch"))
		gResolution = 2;
	else if (!stricmp(tmpstr, "Expand"))
		gResolution = 3;
	else
		gResolution = 0;

	tmpstr	= get_string("MAMED", "Pad Orientation", NULL, "Up");
	if (!stricmp(tmpstr, "Up"))
		gPadOrientation = 0;
	else if (!stricmp(tmpstr, "Right"))
		gPadOrientation = 1;
	else if (!stricmp(tmpstr, "Down"))
		gPadOrientation = 2;
	else if (!stricmp(tmpstr, "Left"))
		gPadOrientation = 3;
	else
		gPadOrientation = 0;

	tmpstr	= get_string("MAMED", "Fake Sound", NULL, "No");
	if (!stricmp(tmpstr, "Yes"))
		play_sound = 0;
	else if (!stricmp(tmpstr, "No"))
		play_sound = 1;
	else 
		play_sound = 1;
		
	tmpstr = get_string("MAMED", "CPU Slice Speedup", NULL, "Yes");
	if (!stricmp(tmpstr, "Yes"))
		cpu_slices_per_frame_override = 1;
	else if (!stricmp(tmpstr, "No"))
		cpu_slices_per_frame_override = 0;
	else 
		cpu_slices_per_frame_override = 1;
		
#ifdef DIGITA_SERIAL
	tmpstr = get_string("MAMED", "Keyboard", NULL, "Serial");
	if (!stricmp(tmpstr, "Off"))
		keyboard_type = 0;
	else if (!stricmp(tmpstr, "Serial"))
		keyboard_type = 1;
	else if (!stricmp(tmpstr, "Keycode"))
		keyboard_type = 2;
	else if (!stricmp(tmpstr, "Matrix"))
		keyboard_type = 3;
	else 
		keyboard_type = 0;
#endif		
}
