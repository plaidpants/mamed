//#include "mamalleg.h"
#include "driver.h"
//#include <dos.h>
//#include <signal.h>
#include <time.h>
#include <ctype.h>
#include "ticker.h"

#ifdef MESS
#include "../mess/msdos.h"
/* from msdos/config.c */
extern char *crcdir;
static char crcfilename[256] = "";
const char *crcfile = crcfilename;
extern char *pcrcdir;
static char pcrcfilename[256] = "";
const char *pcrcfile = pcrcfilename;
#endif


void parse_cmdline (int game);

int  ignorecfg;

static FILE *errorlog;

extern long 				camera_type;
extern int					play_sound;

extern void decompose_rom_sample_path (char *rompath, char *samplepath);

/* put here anything you need to do when the program is started. Return 0 if */
/* initialization was successful, nonzero otherwise. */
int osd_init(void)
{
	return 0;
}


/* put here cleanup routines to be executed when the program is terminated. */
void osd_exit(void)
{
}

/* fuzzy string compare, compare short string against long string        */
/* e.g. astdel == "Asteroids Deluxe". The return code is the fuzz index, */
/* we simply count the gaps between maching chars.                       */
int fuzzycmp (const char *s, const char *l)
{
	int gaps = 0;
	int match = 0;
	int last = 1;

	for (; *s && *l; l++)
	{
		if (*s == *l)
			match = 1;
		else if (*s >= 'a' && *s <= 'z' && (*s - 'a') == (*l - 'A'))
			match = 1;
		else if (*s >= 'A' && *s <= 'Z' && (*s - 'A') == (*l - 'a'))
			match = 1;
		else
			match = 0;

		if (match)
			s++;

		if (match != last)
		{
			last = match;
			if (!match)
				gaps++;
		}
	}

	/* penalty if short string does not completely fit in */
	for (; *s; s++)
		gaps++;

	return gaps;
}

void * mame (char * gamename)
{
	int i, res, game_index;
    char *playbackname = NULL;
	char override_path[256];


//	memset(&options,0,sizeof(options));

	/* these two are not available in mame.cfg */
	ignorecfg = 0;
	errorlog = 0;

	game_index = -1;

	#ifdef MESS
//    set_config_file ("/B/SYSTEM/MESS.CFG");
	#else
//    set_config_file ("/B/SYSTEM/MAME.CFG");
	#endif

	/* check for frontend options */
//	res = frontend_help (argc, argv);

	/* if frontend options were used, return to DOS with the error code */
//	if (res != 1234)
//		exit (res);

    /* handle playback which is not available in mame.cfg */
	init_inpdir(); /* Init input directory for opening .inp for playback */

    if (playbackname != NULL)
        options.playback = osd_fopen(playbackname,0,OSD_FILETYPE_INPUTLOG,0);

    /* check for game name embedded in .inp header */
    if (options.playback)
    {
        INP_HEADER inp_header;

        /* read playback header */
        osd_fread(options.playback, &inp_header, sizeof(INP_HEADER));

        if (!isalnum(inp_header.name[0])) /* If first byte is not alpha-numeric */
            osd_fseek(options.playback, 0, SEEK_SET); /* old .inp file - no header */
        else
        {
            for (i = 0; (drivers[i] != 0); i++) /* find game and play it */
			{
                if (strcmp(drivers[i]->name, inp_header.name) == 0)
                {
                    game_index = i;
                    printf("Playing back previously recorded game %s (%s) [press return]\n",
                        drivers[game_index]->name,drivers[game_index]->description);
                    getchar();
                    break;
                }
            }
        }
    }

	/* If not playing back a new .inp file */
    if (game_index == -1)
    {
        /* do we have a driver for this? */
        {
            for (i = 0; (drivers[i] != 0) && (game_index == -1); i++)
            {
            	if (drivers[i])
            	{
	                if (strcmp(gamename, drivers[i]->name) == 0)
	                {
	                    game_index = i;
	                    break;
	                }
	            }
            }
        }

        if (game_index == -1)
        {
            printf("Game \"%s\" not supported\n", gamename);
            return 0;
        }
        else
        {
            printf("Running Game \"%s\"\n", gamename);
        }
    }

	/* parse generic (os-independent) options */
//	parse_cmdline(game_index);

	/* Minolta, HP and old FW DC290's don't support sound, so turn it off */
	if ((camera_type == kTypeMinolta1) || 
		(camera_type == kTypeHP1) || (camera_type == kTypeHP2) || 
		((camera_type == kTypeKodak2) && (AUDOpenCodec == 0)))
	{
		play_sound = 0;
	}

	#ifdef MESS
	/* Build the CRC database filename */
	sprintf(crcfilename, "%s/%s.crc", crcdir, drivers[game_index]->name);
	if (drivers[game_index]->clone_of->name)
		sprintf (pcrcfilename, "%s/%s.crc", crcdir, drivers[game_index]->clone_of->name);
	else
		pcrcfilename[0] = 0;
    #endif

	/* go for it */
	res = run_game (game_index);

	/* close open files */
	if (errorlog) fclose (errorlog);
	if (options.playback) osd_fclose (options.playback);
	if (options.record)   osd_fclose (options.record);
	if (options.language_file) osd_fclose (options.language_file);

	osd_exit();
	
	return 0;
}

void CLIB_DECL logerror(const char *text,...)
{
//	printf(text);
}
