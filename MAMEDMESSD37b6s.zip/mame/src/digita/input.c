// MAME includes
#include "driver.h"

// external globals
extern int 					gPadOrientation;
extern int					mameTaskID;

#ifdef DIGITA_SOUND
extern int 					soundTaskID;
#endif

// local globals
long camera_type = -1;
void * event_Sem;

#ifdef DIGITA_SERIAL
typedef short(*DeallocateProcPtr)(void * ptr);

typedef struct 
{
	long fError;
	unsigned long fLength;
	void * fDataPtr;
	DeallocateProcPtr fDeallocateProc;
} TSCCmd;

typedef struct 
{
	unsigned long fCommand;
	unsigned long fLength;
	void * fDataPtr;
	DeallocateProcPtr fDeallocateProc;
} TSCCmdList;

static short nop(void * ptr);

short (*NOP)(void * ptr) = nop;
extern short (*CDPSerialManager)(TSCCmdList * cmdIn, TSCCmd * cmdOut);

#define KEY_A				'A'
#define KEY_B				'B'
#define KEY_C				'C'
#define KEY_D				'D'
#define KEY_E				'E'
#define KEY_F				'F'
#define KEY_G				'G'
#define KEY_H				'H'
#define KEY_I				'I'
#define KEY_J				'J'
#define KEY_K				'K'
#define KEY_L				'L'
#define KEY_M				'M'
#define KEY_N				'N'
#define KEY_O				'O'
#define KEY_P				'P'
#define KEY_Q				'Q'
#define KEY_R				'R'
#define KEY_S				'S'
#define KEY_T				'T'
#define KEY_U				'U'
#define KEY_V				'V'
#define KEY_W				'W'
#define KEY_X				'X'
#define KEY_Y				'Y'
#define KEY_Z				'Z'

#define KEY_0				'0'
#define KEY_1				'1'
#define KEY_2				'2'
#define KEY_3				'3'
#define KEY_4				'4'
#define KEY_5				'5'
#define KEY_6				'6'
#define KEY_7				'7'
#define KEY_8				'8'
#define KEY_9				'9'

#define KEY_0_PAD			200
#define KEY_1_PAD			201
#define KEY_2_PAD			202
#define KEY_3_PAD			203
#define KEY_4_PAD			204
#define KEY_5_PAD			205
#define KEY_6_PAD			206
#define KEY_7_PAD			207
#define KEY_8_PAD			208
#define KEY_9_PAD			209

#define KEY_F1				210
#define KEY_F2				211
#define KEY_F3				212
#define KEY_F4				213
#define KEY_F5				214
#define KEY_F6				215
#define KEY_F7				216
#define KEY_F8				217
#define KEY_F9				218
#define KEY_F10				219
#define KEY_F11				220
#define KEY_F12				248

#define KEY_ESC				27
#define KEY_TILDE			'`'
#define KEY_MINUS			'-'
#define KEY_EQUALS			'='
#define KEY_BKSPACE			221
#define KEY_TAB				9
#define KEY_OPENBRACE		'['
#define KEY_CLOSEBRACE		']'
#define KEY_ENTER			13
#define KEY_COLON			';'
#define KEY_QUOTE			'\''
#define KEY_BACKSLASH		'\\'
#define KEY_BACKSLASH2		222
#define KEY_COMMA			','
#define KEY_STOP			'.'
#define KEY_SLASH			'/'
#define KEY_SPACE			' '
#define KEY_INSERT			223
#define KEY_DEL				224
#define KEY_HOME			225
#define KEY_END				226
#define KEY_PGUP			227
#define KEY_PGDN			228
#define KEY_LEFT			8
#define KEY_RIGHT			12
#define KEY_UP				11
#define KEY_DOWN			10
#define KEY_SLASH_PAD		229
#define KEY_ASTERISK		'*'
#define KEY_MINUS_PAD		230
#define KEY_PLUS_PAD		231
#define KEY_DEL_PAD			232
#define KEY_ENTER_PAD		233
#define KEY_PRTSCR			234
#define KEY_PAUSE			235
#define KEY_LSHIFT			236
#define KEY_RSHIFT			237
#define KEY_LCONTROL		238
#define KEY_RCONTROL		239
#define KEY_LALT			240
#define KEY_RALT			241
#define KEY_SCRLOCK			242
#define KEY_NUMLOCK			243
#define KEY_CAPSLOCK		244
#define KEY_LWIN			245
#define KEY_RWIN			246
#define KEY_MENU			247

static struct KeyboardInfo fullkeylist[] =
{
	{ "A",			KEY_A,				KEYCODE_A },
	{ "B",			KEY_B,				KEYCODE_B },
	{ "C",			KEY_C,				KEYCODE_C },
	{ "D",			KEY_D,				KEYCODE_D },
	{ "E",			KEY_E,				KEYCODE_E },
	{ "F",			KEY_F,				KEYCODE_F },
	{ "G",			KEY_G,				KEYCODE_G },
	{ "H",			KEY_H,				KEYCODE_H },
	{ "I",			KEY_I,				KEYCODE_I },
	{ "J",			KEY_J,				KEYCODE_J },
	{ "K",			KEY_K,				KEYCODE_K },
	{ "L",			KEY_L,				KEYCODE_L },
	{ "M",			KEY_M,				KEYCODE_M },
	{ "N",			KEY_N,				KEYCODE_N },
	{ "O",			KEY_O,				KEYCODE_O },
	{ "P",			KEY_P,				KEYCODE_P },
	{ "Q",			KEY_Q,				KEYCODE_Q },
	{ "R",			KEY_R,				KEYCODE_R },
	{ "S",			KEY_S,				KEYCODE_S },
	{ "T",			KEY_T,				KEYCODE_T },
	{ "U",			KEY_U,				KEYCODE_U },
	{ "V",			KEY_V,				KEYCODE_V },
	{ "W",			KEY_W,				KEYCODE_W },
	{ "X",			KEY_X,				KEYCODE_X },
	{ "Y",			KEY_Y,				KEYCODE_Y },
	{ "Z",			KEY_Z,				KEYCODE_Z },
	{ "0",			KEY_0,				KEYCODE_0 },
	{ "1",			KEY_1,				KEYCODE_1 },
	{ "2",			KEY_2,				KEYCODE_2 },
	{ "3",			KEY_3,				KEYCODE_3 },
	{ "4",			KEY_4,				KEYCODE_4 },
	{ "5",			KEY_5,				KEYCODE_5 },
	{ "6",			KEY_6,				KEYCODE_6 },
	{ "7",			KEY_7,				KEYCODE_7 },
	{ "8",			KEY_8,				KEYCODE_8 },
	{ "9",			KEY_9,				KEYCODE_9 },
	{ "0 PAD",		KEY_0_PAD,			KEYCODE_0_PAD },
	{ "1 PAD",		KEY_1_PAD,			KEYCODE_1_PAD },
	{ "2 PAD",		KEY_2_PAD,			KEYCODE_2_PAD },
	{ "3 PAD",		KEY_3_PAD,			KEYCODE_3_PAD },
	{ "4 PAD",		KEY_4_PAD,			KEYCODE_4_PAD },
	{ "5 PAD",		KEY_5_PAD,			KEYCODE_5_PAD },
	{ "6 PAD",		KEY_6_PAD,			KEYCODE_6_PAD },
	{ "7 PAD",		KEY_7_PAD,			KEYCODE_7_PAD },
	{ "8 PAD",		KEY_8_PAD,			KEYCODE_8_PAD },
	{ "9 PAD",		KEY_9_PAD,			KEYCODE_9_PAD },
	{ "F1",			KEY_F1,				KEYCODE_F1 },
	{ "F2",			KEY_F2,				KEYCODE_F2 },
	{ "F3",			KEY_F3,				KEYCODE_F3 },
	{ "F4",			KEY_F4,				KEYCODE_F4 },
	{ "F5",			KEY_F5,				KEYCODE_F5 },
	{ "F6",			KEY_F6,				KEYCODE_F6 },
	{ "F7",			KEY_F7,				KEYCODE_F7 },
	{ "F8",			KEY_F8,				KEYCODE_F8 },
	{ "F9",			KEY_F9,				KEYCODE_F9 },
	{ "F10",		KEY_F10,			KEYCODE_F10 },
	{ "F11",		KEY_F11,			KEYCODE_F11 },
	{ "F12",		KEY_F12,			KEYCODE_F12 },
	{ "ESC",		KEY_ESC,			KEYCODE_ESC },
	{ "~",			KEY_TILDE,			KEYCODE_TILDE },
	{ "-",          KEY_MINUS,         	KEYCODE_MINUS },
	{ "=",          KEY_EQUALS,     	KEYCODE_EQUALS },
	{ "BKSPACE",	KEY_BKSPACE,		KEYCODE_BACKSPACE },
	{ "TAB",		KEY_TAB,			KEYCODE_TAB },
	{ "[",          KEY_OPENBRACE,      KEYCODE_OPENBRACE },
	{ "]",          KEY_CLOSEBRACE,     KEYCODE_CLOSEBRACE },
	{ "ENTER",		KEY_ENTER,			KEYCODE_ENTER },
	{ ";",          KEY_COLON,          KEYCODE_COLON },
	{ "'",          KEY_QUOTE,         	KEYCODE_QUOTE },
	{ "\\",         KEY_BACKSLASH,     	KEYCODE_BACKSLASH },
	{ "<",          KEY_BACKSLASH2,     KEYCODE_BACKSLASH2 },
	{ ",",          KEY_COMMA,          KEYCODE_COMMA },
	{ ".",          KEY_STOP,           KEYCODE_STOP },
	{ "/",          KEY_SLASH,          KEYCODE_SLASH },
	{ "SPACE",		KEY_SPACE,			KEYCODE_SPACE },
	{ "INS",		KEY_INSERT,			KEYCODE_INSERT },
	{ "DEL",		KEY_DEL,			KEYCODE_DEL },
	{ "HOME",		KEY_HOME,			KEYCODE_HOME },
	{ "END",		KEY_END,			KEYCODE_END },
	{ "PGUP",		KEY_PGUP,			KEYCODE_PGUP },
	{ "PGDN",		KEY_PGDN,			KEYCODE_PGDN },
	{ "LEFT",		KEY_LEFT,			KEYCODE_LEFT },
	{ "RIGHT",		KEY_RIGHT,			KEYCODE_RIGHT },
	{ "UP",			KEY_UP,				KEYCODE_UP },
	{ "DOWN",		KEY_DOWN,			KEYCODE_DOWN },
	{ "/ PAD",      KEY_SLASH_PAD,      KEYCODE_SLASH_PAD },
	{ "* PAD",      KEY_ASTERISK,       KEYCODE_ASTERISK },
	{ "- PAD",      KEY_MINUS_PAD,      KEYCODE_MINUS_PAD },
	{ "+ PAD",      KEY_PLUS_PAD,       KEYCODE_PLUS_PAD },
	{ ". PAD",      KEY_DEL_PAD,        KEYCODE_DEL_PAD },
	{ "ENTER PAD",  KEY_ENTER_PAD,      KEYCODE_ENTER_PAD },
	{ "PRTSCR",     KEY_PRTSCR,         KEYCODE_PRTSCR },
	{ "PAUSE",      KEY_PAUSE,          KEYCODE_PAUSE },
	{ "LSHIFT",		KEY_LSHIFT,			KEYCODE_LSHIFT },
	{ "RSHIFT",		KEY_RSHIFT,			KEYCODE_RSHIFT },
	{ "LCTRL",		KEY_LCONTROL,		KEYCODE_LCONTROL },
	{ "RCTRL",		KEY_RCONTROL,		KEYCODE_RCONTROL },
	{ "LALT",		KEY_LALT,			KEYCODE_LALT },
	{ "RALT",		KEY_RALT,			KEYCODE_RALT },
	{ "LWIN",		KEY_LWIN,			KEYCODE_OTHER },
	{ "RWIN",		KEY_RWIN,			KEYCODE_OTHER },
	{ "MENU",		KEY_MENU,			KEYCODE_OTHER },
	{ "SCRLOCK",    KEY_SCRLOCK,        KEYCODE_SCRLOCK },
	{ "NUMLOCK",    KEY_NUMLOCK,        KEYCODE_NUMLOCK },
	{ "CAPSLOCK",   KEY_CAPSLOCK,       KEYCODE_CAPSLOCK },
	{ 0, 0, 0 }	/* end of table */
};
#endif

#if 0
// these are the buttons for the DC220, DC260, & DC265
static struct KeyboardInfo keylistKodak[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kSoftkeyLeft,				KEYCODE_1 },
	{ "Middle SK",	kSoftkeyMid,				KEYCODE_ESC },
	{ "Right SK",	kSoftkeyRight,				KEYCODE_5 },
	{ "Up",			kUpArrow,					KEYCODE_UP },
	{ "Left",		kLeftArrow,					KEYCODE_LEFT },
	{ "Right",		kRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kDownArrow,					KEYCODE_DOWN },
	{ "Menu",		kMenuButton,				KEYCODE_TAB },
	{ "Zoom In",	kZoomIn,					KEYCODE_LALT },
	{ "Zoom Out",	kZoomOut,					KEYCODE_LCONTROL },
	{ "Display",	kOverlayButton,				KEYCODE_ENTER },
	{ "Record",		kRecordButton,				KEYCODE_TILDE },
	{ "Shutter 1",	kShutter1,					KEYCODE_E },
	{ "Shutter 2",	kShutter2,					KEYCODE_F12 },

/* these buttons are not avalible */
	{ "LCD 1",		kLCDStatus1,				KEYCODE_G },
	{ "LCD 2",		kLCDStatus2,				KEYCODE_H },
	{ "Connect",	kMode0Button,				KEYCODE_I },
	{ "Capture",	kMode1Button,				KEYCODE_J },
	{ "Review",		kMode2Button,				KEYCODE_K },
	{ "Info",		kMode3Button,				KEYCODE_L },
	{ "Spare 1",	kSpare1,					KEYCODE_M },
	{ "Spare 2",	kSpare2,					KEYCODE_N },
	{ 0, 0, 0 }	/* end of table */
};

// these are the buttons for the Minolta 1500 EX
static struct KeyboardInfo keylistMinolta[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kMinoltaSoftkeyLeft,			KEYCODE_1 },
	{ "Middle SK",	kMinoltaSoftkeyMid,				KEYCODE_ESC },
	{ "Right SK",	kMinoltaSoftkeyRight,			KEYCODE_5 },
	{ "Up",			kMinoltaUpArrow,				KEYCODE_UP },
	{ "Left",		kMinoltaLeftArrow,				KEYCODE_LEFT },
	{ "Right",		kMinoltaRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kMinoltaDownArrow,				KEYCODE_DOWN },
	{ "Menu",		kMinoltaMenuButton,				KEYCODE_TAB },
	{ "Overlay",	kMinoltaOverlayButton,			KEYCODE_ENTER },
	{ "Status",		kMinoltaStatusButton,			KEYCODE_LCONTROL },
	{ "Shutter 1",	kMinoltaShutter1,				KEYCODE_E },
	{ "Shutter 2",	kMinoltaShutter2,				KEYCODE_F12 },
/* these buttons are not avalible */
	{ "Connect",	kMinoltaMode0Button,			KEYCODE_I },
	{ "Capture",	kMinoltaMode1Button,			KEYCODE_J },
	{ "Review",		kMinoltaMode2Button,			KEYCODE_K },
	{ "Info",		kMinoltaMode3Button,			KEYCODE_L },
	{ 0, 0, 0 }	/* end of table */
};

// these are the buttons for the DC290 & HP C500
static struct KeyboardInfo keylistDigita[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kDigitaSoftKey1,				KEYCODE_1 },
	{ "Middle SK",	kDigitaSoftKey2,				KEYCODE_ESC },
	{ "Right SK",	kDigitaSoftKey3,				KEYCODE_5 },
	{ "Up",			kDigitaUpArrow,					KEYCODE_UP },
	{ "Left",		kDigitaLeftArrow,				KEYCODE_LEFT },
	{ "Right",		kDigitaRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kDigitaDownArrow,				KEYCODE_DOWN },
	{ "Menu",		kDigitaMenu,					KEYCODE_TAB },
	{ "Zoom In",	kDigitaZoomIn,					KEYCODE_LALT },
	{ "Zoom Out",	kDigitaZoomOut,					KEYCODE_LCONTROL },
	{ "Display",	kDigitaOverlay,					KEYCODE_ENTER },

/* these buttons are not avalible */
	{ "Record",		kDigitaRecord,					KEYCODE_TILDE },
	{ "Shutter 1",	kDigitaShutter1,				KEYCODE_E },
	{ "Shutter 2",	kDigitaShutter2,				KEYCODE_F12 },
	{ "LCD 1",		kDigitaLCDStatus1,				KEYCODE_G },
	{ "LCD 2",		kDigitaLCDStatus2,				KEYCODE_H },
	{ "Connect",	kDigitaHostMode,				KEYCODE_I },
	{ "Capture",	kDigitaCaptureMode,				KEYCODE_J },
	{ "Review",		kDigitaReviewMode,				KEYCODE_K },
	{ "Info",		kDigitaPlayMode,				KEYCODE_L },
	{ "Spare 1",	kDigitaSpare1,					KEYCODE_M },
	{ "Spare 2",	kDigitaSpare2,					KEYCODE_N },
	{ 0, 0, 0 }	/* end of table */
};

// these are the buttons for the HP & PENTAX
static struct KeyboardInfo keylistDigita2[] =
{
/* these are the normal set of buttons */
	{ "Left SK",	kDigitaSoftKey1,				KEYCODE_1 },
	{ "Middle SK",	kDigitaSoftKey2,				KEYCODE_ESC },
	{ "Right SK",	kDigitaSoftKey3,				KEYCODE_5 },
	{ "Up",			kDigitaUpArrow,					KEYCODE_UP },
	{ "Left",		kDigitaLeftArrow,				KEYCODE_LEFT },
	{ "Right",		kDigitaRightArrow,				KEYCODE_RIGHT },
	{ "Down",		kDigitaDownArrow,				KEYCODE_DOWN },
	{ "Menu",		kDigitaMenu,					KEYCODE_TAB },
	{ "Zoom In",	kDigitaZoomIn,					KEYCODE_LALT },
	{ "Zoom Out",	kDigitaZoomOut,					KEYCODE_LCONTROL },
	{ "Display",	kDigitaLCDOnOff,				KEYCODE_ENTER },

/* these buttons are not avalible */
	{ "Record",		kDigitaRecord,					KEYCODE_TILDE },
	{ "Shutter 1",	kDigitaShutter1,				KEYCODE_E },
	{ "Shutter 2",	kDigitaShutter2,				KEYCODE_F12 },
	{ "LCD 1",		kDigitaLCDStatus1,				KEYCODE_G },
	{ "LCD 2",		kDigitaLCDStatus2,				KEYCODE_H },
	{ "Connect",	kDigitaHostMode,				KEYCODE_I },
	{ "Capture",	kDigitaCaptureMode,				KEYCODE_J },
	{ "Review",		kDigitaReviewMode,				KEYCODE_K },
	{ "Info",		kDigitaPlayMode,				KEYCODE_L },
	{ "Spare 1",	kDigitaSpare1,					KEYCODE_M },
	{ "Spare 2",	kDigitaSpare2,					KEYCODE_N },
	{ 0, 0, 0 }	/* end of table */
};
#endif

// Globals
unsigned char    	altAppID;

void detect_camera_type(void)
{
	short err = 0;
	TPARMNameTypeValue data;
	char vendor[50];
	char product[50];

	// Get vendor name.
	err = PARMGetProductInfo( "vdid", &data );
	if (err != 0)
		memset( vendor, 0, sizeof( data.fStr ) );
	else
		strcpy( vendor, data.fStr );

	// Get product name.
	err = PARMGetProductInfo( "ptid", &data );
	if (err != 0)
		memset( product, 0, sizeof( data.fStr ) );
	else
		strcpy( product, data.fStr );
	
	if (strcmp( vendor, strKodakVendorName ) == 0)
	{
		if (strcmp( product, strKodakDC220ProductName ) == 0)
		{
			camera_type = kTypeKodak0;
		}
		else if (strcmp( product, strKodakDC260ProductName) == 0)
		{
			camera_type = kTypeKodak0;
		}
		else if (strcmp( product, strKodakDC265ProductName) == 0)
		{
			camera_type = kTypeKodak1;
		}
		else if (strcmp( product, strKodakDC290ProductName) == 0)
		{
			camera_type = kTypeKodak2;
		}
		else
		{
			camera_type = kTypeKodak2;
		}
	}
	else if (strcmp( vendor, strHPVendorName ) == 0)
	{
		if (strcmp( product, strHPC500ProductName ) == 0)
		{
			camera_type = kTypeHP1;
		}
	}
	else if (strcmp( vendor, strMinoltaVendorName ) == 0)
	{
		if (strcmp( product, strMinoltaDimage1500EXProductName ) == 0)
		{
			camera_type = kTypeMinolta1;
		}
	}
	else if (strcmp( vendor, strHP2VendorName ) == 0)
	{
		if (strcmp( product, strHPC615ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		if (strcmp( product, strHPC618ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strHPC912ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
	}
	else if (strcmp( vendor, strPENTAXVendorName ) == 0)
	{
		if (strcmp( product, strPENTAXEI200ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
		else if (strcmp( product, strPENTAXEI2000ProductName ) == 0)
		{
			camera_type = kTypeHP2;
		}
	}
	else
	{
		// Unknown
		camera_type = -1;
	}
}

#ifdef DIGITA_SERIAL
static short nop(void * ptr)
{
	return 0;
}

// these are the same operations available through scripts
short closeSerial(void) 
{
	TSCCmd outParm = {0,0,0,0};
	TSCCmdList inParm = {5, 0, NULL, NULL};
	short status = 0 ;
	
	status = CDPSerialManager(&inParm, &outParm);

	return status ;
}

short openSerial(long baudRate) 
{
	TSCCmd outParm = {0,0,0,0};
	TSCCmdList inParm = {1, sizeof(baudRate), &baudRate, NOP};
	short status = 0;
	
	status = CDPSerialManager(&inParm, &outParm);

	return status;
}

short receiveSerial(char *receiveData) 
{
	TSCCmd outParm = {0,0,0,0};
	TSCCmdList inParm = {4, 0, NULL, NULL};
	short status = 0;
	
	outParm.fDataPtr = receiveData;
	outParm.fLength = 1;
	
	status = CDPSerialManager(&inParm, &outParm);
	if (status == 0) 
	{
		if (outParm.fLength > 0) 
		{
			memcpy(receiveData, outParm.fDataPtr, outParm.fLength);
		}

	}

	if (outParm.fLength > 0) 
	{
		if (outParm.fDeallocateProc != NULL)
		{
			outParm.fDeallocateProc(outParm.fDataPtr);
		}
		else
		{
			MMDisposePtr(outParm.fDataPtr);
		}
	}
	
	return status;
}

short sendSerial(long sendSize, long receiveSize, void * sendData) 
{
	TSCCmd outParm = {0,0,0,0};
	TSCCmdList inParm = {2, 0, NULL, NULL};
	short status = 0;
	char * tmp;
	
	inParm.fLength = (2 * sizeof(long)) + sendSize;
	inParm.fDataPtr = malloc(inParm.fLength);

	tmp = inParm.fDataPtr ;
	memcpy(tmp, &sendSize, sizeof(long));
	tmp += sizeof(long);
	memcpy(tmp, &receiveSize, sizeof(long));
	tmp += sizeof(long);
	memcpy(tmp, sendData, sendSize);
	
	status = CDPSerialManager(&inParm, &outParm);
	
	free(inParm.fDataPtr);

	return status;
}

short sendReceiveSerial(long sendSize, long receiveSize, void * sendData, char * receiveData) 
{
	TSCCmd outParm = {0,0,0,0};
	TSCCmdList inParm = {3, 0, NULL, NULL};
	short status = 0;
	char * tmp;
	
	outParm.fDataPtr = receiveData;
	outParm.fLength = receiveSize;
	
	inParm.fLength = (2 * sizeof(long)) + sendSize;
	inParm.fDataPtr = malloc(inParm.fLength);

	tmp = inParm.fDataPtr;
	memcpy(tmp, &sendSize, sizeof(long));
	tmp += sizeof(long);
	memcpy(tmp, &receiveSize, sizeof(long));
	tmp += sizeof(long);
	memcpy(tmp, sendData, sendSize);
	
	status = CDPSerialManager(&inParm, &outParm);
	if (status == 0) 
	{
		if (outParm.fLength > 0) 
		{
			memcpy(receiveData, outParm.fDataPtr, outParm.fLength);
		}

	}
	free(inParm.fDataPtr);

	if (outParm.fLength > 0) 
	{
		if (outParm.fDeallocateProc != NULL)
		{
			outParm.fDeallocateProc(outParm.fDataPtr);
		}
		else
		{
			MMDisposePtr(outParm.fDataPtr);
		}
	}

	return status ;
}

int serial_event_mq = 0;

char actual_pressed[128] = {'2','A','B','C', 'D','E','F','G', 'H','I','J','K', 'L','M','N','O',
							'P','Q','R','S', 'T','U','V','W', 'X','Y','Z','[', '\\',']','^','_',
							
							' ','1','\'','3','4','5','7','\'','9','0','8','=', ',','-','.','/',
							'0','1','2','3', '4','5','6','7', '8','9',';',';', ',','=','.','/',
							
							'2','A','B','C', 'D','E','F','G', 'H','I','J','K', 'L','M','N','O',
							'P','Q','R','S', 'T','U','V','W', 'X','Y','Z','[', '\\',']','6','-',
							
							'`','A','B','C', 'D','E','F','G', 'H','I','J','K', 'L','M','N','O',
							'P','Q','R','S', 'T','U','V','W', 'X','Y','Z','[', '\\',']','`',127};
							
int control_pressed[128] = {1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1,
							1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1,
							
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0};
							
int shift_pressed[128] =   {1,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							
							0,1,1,1, 1,1,1,0, 1,1,1,1, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,1,0, 1,0,1,1,
							
							1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1,
							1,1,1,1, 1,1,1,1, 1,1,1,0, 0,0,1,1,

							0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
							0,0,0,0, 0,0,0,0, 0,0,0,1, 1,1,1,0};

extern unsigned long gSCCCmdResponseTimeOut;
extern unsigned long gSCCHostCmdTimeOut;
extern int keyboard_type;

void keyboard_type_serial(char buffer)
{
	long buttomMsg;

	buttomMsg = 0;

	// we won't convert these to their key combinations
	if ((buffer != KEY_SCRLOCK) 
		&& (buffer != KEY_LEFT)
		&& (buffer != KEY_TAB)
		&& (buffer != KEY_DOWN)
		&& (buffer != KEY_UP)
		&& (buffer != KEY_RIGHT)
		&& (buffer != KEY_ENTER)
		&& (buffer != KEY_ESC))
	{
		if (control_pressed[buffer]) 
		{
			// need to press the control key for these
			buttomMsg |= KEY_LCONTROL << 16;
		}
		
		if (shift_pressed[buffer]) 
		{
			// need to press the shift key for this one
			buttomMsg |= KEY_LSHIFT << 24;
		}
	
		buttomMsg |= actual_pressed[buffer];
	}
	else
	{
		buttomMsg |= buffer;
	}
	
	// key down will be reset once read
	buttomMsg = buttomMsg | (10 << 8);
	
	mq_send(serial_event_mq, &buttomMsg, sizeof(buttomMsg), 0);			
}

#define MAX_KEYCODE_BUFFER 5
#define MAX_KEYS 2
#define MAX_KEYCODES 255

typedef struct 
{
	char keys[MAX_KEYS]; // actual keys pressed
	char downseq[MAX_KEYCODE_BUFFER];
	char upseq[MAX_KEYCODE_BUFFER];
} keycodeseq;

#if 0
keycodeseq keycodes[MAX_KEYCODES] = 
							{{{KEY_TAB, 0}, {'A','B','1', 0}, {'C','D','1', 0}},
							{{KEY_ENTER, 0},{'A','B','2', 0}, {'C','D','2', 0}},
							{{0}, {0}, {0}}};
#endif

keycodeseq keycodes[MAX_KEYCODES] =
	{{{KEY_A, 0}, {0x1E, 0}, {0x9E, 0}},
	{{KEY_B, 0}, {0x30, 0}, {0xB0, 0}},
	{{KEY_C, 0}, {0x2E, 0}, {0xAE, 0}},
	{{KEY_D, 0}, {0x20, 0}, {0xA0, 0}},
	{{KEY_E, 0}, {0x12, 0}, {0x92, 0}},
	{{KEY_F, 0}, {0x21, 0}, {0xA1, 0}},
	{{KEY_G, 0}, {0x22, 0}, {0xA2, 0}},
	{{KEY_H, 0}, {0x23, 0}, {0xA3, 0}},
	{{KEY_I, 0}, {0x17, 0}, {0x97, 0}},
	{{KEY_J, 0}, {0x24, 0}, {0xA4, 0}},
	{{KEY_K, 0}, {0x25, 0}, {0xA5, 0}},
	{{KEY_L, 0}, {0x26, 0}, {0xA6, 0}},
	{{KEY_M, 0}, {0x32, 0}, {0xB2, 0}},
	{{KEY_N, 0}, {0x31, 0}, {0xB1, 0}},
	{{KEY_O, 0}, {0x18, 0}, {0x98, 0}},
	{{KEY_P, 0}, {0x19, 0}, {0x99, 0}},
	{{KEY_Q, 0}, {0x10, 0}, {0x90, 0}},
	{{KEY_R, 0}, {0x13, 0}, {0x93, 0}},
	{{KEY_S, 0}, {0x1F, 0}, {0x9F, 0}},
	{{KEY_T, 0}, {0x14, 0}, {0x94, 0}},
	{{KEY_U, 0}, {0x16, 0}, {0x96, 0}},
	{{KEY_V, 0}, {0x2F, 0}, {0xAF, 0}},
	{{KEY_W, 0}, {0x11, 0}, {0x91, 0}},
	{{KEY_X, 0}, {0x2D, 0}, {0xAD, 0}},
	{{KEY_Y, 0}, {0x15, 0}, {0x95, 0}},
	{{KEY_Z, 0}, {0x2C, 0}, {0xAC, 0}},
	
	{{KEY_0, 0}, {0x0B, 0}, {0x8B, 0}},
	{{KEY_1, 0}, {0x02, 0}, {0x82, 0}},
	{{KEY_2, 0}, {0x03, 0}, {0x83, 0}},
	{{KEY_3, 0}, {0x04, 0}, {0x84, 0}},
	{{KEY_4, 0}, {0x05, 0}, {0x85, 0}},
	{{KEY_5, 0}, {0x06, 0}, {0x86, 0}},
	{{KEY_6, 0}, {0x07, 0}, {0x87, 0}},
	{{KEY_7, 0}, {0x08, 0}, {0x88, 0}},
	{{KEY_8, 0}, {0x09, 0}, {0x89, 0}},
	{{KEY_9, 0}, {0x0A, 0}, {0x8A, 0}},
	
	{{KEY_0_PAD, 0}, {0x52, 0}, {0xD2, 0}},
	{{KEY_1_PAD, 0}, {0x4F, 0}, {0xCF, 0}},
	{{KEY_2_PAD, 0}, {0x50, 0}, {0xD0, 0}},
	{{KEY_3_PAD, 0}, {0x4B, 0}, {0xCB, 0}},
	{{KEY_4_PAD, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_5_PAD, 0}, {0x4C, 0}, {0xCC, 0}},
	{{KEY_6_PAD, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_7_PAD, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_8_PAD, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_9_PAD, 0}, {0x00, 0}, {0x00, 0}},
	
	{{KEY_F1, 0}, {0x3B, 0}, {0xBB, 0}},
	{{KEY_F2, 0}, {0x3C, 0}, {0xBC, 0}},
	{{KEY_F3, 0}, {0x3D, 0}, {0xBD, 0}},
	{{KEY_F4, 0}, {0x3E, 0}, {0xBE, 0}},
	{{KEY_F5, 0}, {0x3F, 0}, {0xBF, 0}},
	{{KEY_F6, 0}, {0x40, 0}, {0xC0, 0}},
	{{KEY_F7, 0}, {0x41, 0}, {0xC1, 0}},
	{{KEY_F8, 0}, {0x42, 0}, {0xC2, 0}},
	{{KEY_F9, 0}, {0x43, 0}, {0xC3, 0}},
	{{KEY_F10, 0}, {0x44, 0}, {0xC4, 0}},
	{{KEY_F11, 0}, {0x57, 0}, {0xD7, 0}},
	{{KEY_F12, 0}, {0x58, 0}, {0xD8, 0}},
	
	{{KEY_ESC, 0}, {0x01, 0}, {0x81, 0}},
	{{KEY_TILDE, 0}, {0x29, 0}, {0xA9, 0}},
	{{KEY_MINUS, 0}, {0x0D, 0}, {0x8D, 0}},
	{{KEY_EQUALS, 0}, {0x2B, 0}, {0xAB, 0}},
	{{KEY_BKSPACE, 0}, {0x0E, 0}, {0x8E, 0}},
	{{KEY_TAB, 0}, {0x0F, 0}, {0x8F, 0}},
	{{KEY_OPENBRACE, 0}, {0x1A, 0}, {0x9A, 0}},
	{{KEY_CLOSEBRACE, 0}, {0x1B, 0}, {0x9B, 0}},
	{{KEY_ENTER, 0}, {0x1C, 0}, {0x9C, 0}},
	{{KEY_COLON, 0}, {0x27, 0}, {0xA7, 0}},
	{{KEY_QUOTE, 0}, {0x28, 0}, {0xA8, 0}},
	{{KEY_BACKSLASH, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_BACKSLASH2, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_COMMA, 0}, {0x33, 0}, {0xB3, 0}},
	{{KEY_STOP, 0}, {0x34, 0}, {0xB4, 0}},
	{{KEY_SLASH, 0}, {0x35, 0}, {0xB5, 0}},
	{{KEY_SPACE, 0}, {0x39, 0}, {0xB9, 0}},
	{{KEY_INSERT, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_DEL, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_HOME, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_END, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_PGUP, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_PGDN, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_LEFT, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_RIGHT, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_UP, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_DOWN, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_SLASH_PAD, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_ASTERISK, 0}, {0x37, 0}, {0xB7, 0}},
	{{KEY_MINUS_PAD, 0}, {0x4A, 0}, {0xCA, 0}},
	{{KEY_PLUS_PAD, 0}, {0x4E, 0}, {0xCE, 0}},
	{{KEY_DEL_PAD, 0}, {0x53, 0}, {0xD3, 0}},
	{{KEY_ENTER_PAD, 0}, {0x1C, 0xE0, 0}, {0x9C, 0xE0, 0}},
	{{KEY_PRTSCR, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_PAUSE, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_LSHIFT, 0}, {0x2A, 0}, {0xAA, 0}},
	{{KEY_RSHIFT, 0}, {0x36, 0}, {0xB6, 0}},
	{{KEY_RCONTROL, 0}, {0x1D, 0xE0, 0}, {0x9D, 0xE0, 0}},
	{{KEY_LCONTROL, 0}, {0x1D, 0}, {0x9D, 0}},
	{{KEY_LALT, 0}, {0x38, 0}, {0xB8, 0}},
	{{KEY_RALT, 0}, {0x38, 0xE0, 0}, {0xB8, 0xE0, 0}},
	{{KEY_SCRLOCK, 0}, {0x46, 0}, {0xC6, 0}},
	{{KEY_NUMLOCK, 0}, {0x90, 0}, {0xC5, 0}},
	{{KEY_CAPSLOCK, 0}, {0x3A, 0}, {0xBA, 0}},
	{{KEY_LWIN, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_RWIN, 0}, {0x00, 0}, {0x00, 0}},
	{{KEY_MENU, 0}, {0x00, 0}, {0x00, 0}},
	{{0},{0},{0}}};

char keycodebuffer[MAX_KEYCODE_BUFFER];

void keyboard_type_keycode(char buffer)
{
	long buttomMsg;
	int i,j,k;
	
	// add the new keycode to the keycode scan buffer
	keycodebuffer[4] = keycodebuffer[3];
	keycodebuffer[3] = keycodebuffer[2];
	keycodebuffer[2] = keycodebuffer[1];
	keycodebuffer[1] = keycodebuffer[0];
	keycodebuffer[0] = buffer;

	for (i = 0; i < MAX_KEYCODES; i++)
	{
		// are we at the end of the list
		if (keycodes[i].keys[0] == 0)
			break;
		
		// make sure I've bothered to enter this sequence
		if ((keycodes[i].downseq[0] != 0) && (keycodes[i].upseq[0] != 0))
			{
			// check keycode for up seq match
			for (j = 0; j < MAX_KEYCODE_BUFFER; j++)
			{
				if (keycodes[i].upseq[j] == 0)
				{
					// end of seq, we have a match, so send the keys
					for (k = 0; k < MAX_KEYS; k++)
					{
						// are we at the end of the list
						if (keycodes[i].keys[k] == 0)
							break;
							
						buttomMsg = keycodes[i].keys[k];
						mq_send(serial_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					}
					break;
				}
	
				if (keycodes[i].upseq[j] != keycodebuffer[j])
				{
					// mismatch, so bail
					break;
				}
				
				// so far so good , keep going
			}
	
			// check keycode for down seq match
			for (j = 0; j < MAX_KEYCODE_BUFFER; j++)
			{
				if (keycodes[i].downseq[j] == 0)
				{
					// end of seq, we have a match, so send the keys
					for (k = 0; k < MAX_KEYS; k++)
					{
						// are we at the end of the list
						if (keycodes[i].keys[k] == 0)
							break;
							
						buttomMsg = keycodes[i].keys[k] | 0x100;
						mq_send(serial_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
					}
					break;		
				}
	
				if (keycodes[i].downseq[j] != keycodebuffer[j])
				{
					// mismatch, so bail
					break;
				}
				
				// so far so good , keep going
			}
		}
	}
}

char keymatrix[] =    {'1', '2', '3', 'Z', '4', '5', '6', '7', 
					 0 , 'Q', 'W', 'E', 'R', 'T', 'Y', '`',
					'X', 'A', 'S', 'D', 'F', 'G', 'H', ' ',
					 KEY_CAPSLOCK, KEY_TAB, KEY_LCONTROL,  0 ,  0 ,  0 ,  0 ,  0 ,
					 0 ,  0 ,  0 , KEY_LALT,  0 ,  0 ,  0 ,  0 ,
					 0 ,  0 ,  0 ,  0 , 'C', 'V', 'B', 'N',
					'-', '=', KEY_BKSPACE,  0 , '8', '9', '0', ' ',
					'[', ']','\\',  0 , 'U', 'I', 'O', 'P',
				    '\'', KEY_ENTER,  0 ,  0 , 'J', 'K', 'L', ';',
					'/', KEY_UP,  0 ,  0 , 'M', ',', '.',  0 ,
					 KEY_DEL, KEY_LEFT, KEY_DOWN, KEY_RIGHT,  0 ,  0 ,  0 ,  0,
					 KEY_LSHIFT, KEY_RSHIFT,  0 ,  0 ,  0 ,  0 ,  0 ,  0  };
					
void keyboard_type_matrix(char buffer)
{
	long buttomMsg;
	int keyDown;
	int key1, key2;
	
	keyDown = !(buffer & 0x80);
	
	key1 = (buffer & 0x78);
	key2 = (buffer & 0x07);
	
	buttomMsg = keymatrix[key1 * 8 + key2] | (keyDown << 8);
	
	mq_send(serial_event_mq, &buttomMsg, sizeof(buttomMsg), 0);			
}

void serialPortEventTask(void)
{
	char * prompt = "Ready!";
	char buffer;
	struct mq_attr mqa;
	int mode;
	short status = 0;
	
	mqa.mq_flags = O_RDWR | O_CREAT;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	// open the message queue for sending
	serial_event_mq = mq_open("EVENTS", O_WRONLY | O_CREAT, mode, &mqa);

	while (TRUE)
	{
		// wait for keyboard to become active
		while (!keyboard_type)
			taskDelay(10);
		
		status = openSerial(38400);
		if (status == 0)
		{
			// keep it from timing out, cause it dies after timing out
			gSCCCmdResponseTimeOut = 0;
			gSCCHostCmdTimeOut = 0;
			status = sendSerial(strlen(prompt), 0, prompt);
			if (status == 0)
			{
				while (keyboard_type)
				{
					// keep it from timing out, cause it dies after timing out
					gSCCCmdResponseTimeOut = 0;
					gSCCHostCmdTimeOut = 0;
				
					// send the last character & get the next character
					status = sendReceiveSerial(0, 1, NULL, &buffer);
					if (status == 0)
					{
						switch (keyboard_type)
						{
							case 1:
							{
								keyboard_type_serial(buffer);
								break;
							}
							case 2:
							{
								keyboard_type_keycode(buffer);
								break;
							}
							case 3:
							{
								keyboard_type_matrix(buffer);
								break;
							}
							case 0:
							default:
							{
								break;
							}
						}
					}
				}
			}
			closeSerial();
		}
	}
}
#endif

// concentrate all events here
int event_receive_mq = 0;
int gLastKey = 0;
int gLastKeyState = 0;
unsigned short keyStates[256];

void getEventTask(void)
{
    int buttomMsg;
    int priority;
	struct mq_attr mqa;
	int mode;
	int i;
	
	// init key states
	for (i = 0; i < 256; i++)
	{
		keyStates[i] = 0;
	}
	
    mqa.mq_flags = O_RDWR | O_CREAT;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	// open the message queue for receiving
	event_receive_mq = mq_open("EVENTS", O_RDONLY | O_CREAT, mode, &mqa);

	while (TRUE)
	{
		if (mq_receive(event_receive_mq, &buttomMsg, 4, &priority) != -1)
		{
			gLastKeyState =  (buttomMsg >> 8) & 0xff;

			if (gLastKeyState > 1)
				gLastKeyState = tickGet() + gLastKeyState;
				
			gLastKey = (buttomMsg & 0xff0000) >> 16;
			if (gLastKey)
			    keyStates[gLastKey] = gLastKeyState + 5;
			gLastKey = (buttomMsg & 0xff000000) >> 24;
			if (gLastKey)
			    keyStates[gLastKey] = gLastKeyState + 5;
			
			gLastKey = buttomMsg & 0xff;
			
		    keyStates[gLastKey] = gLastKeyState;
		}
	}
}

int digita_event_mq = 0;

void digitaEventTask(void)
{
	short				result;
	int 				buttomMsg;
	struct mq_attr 		mqa;
	int 				mode;
	TEMEventRecordPtr	event;
	int					lastKey;
	
    mqa.mq_flags = O_RDWR | O_CREAT;
    mqa.mq_msgsize = 4;
    mqa.mq_maxmsg = 10;
    
	mode = 0;

	// open the message queue for sending
	digita_event_mq = mq_open("EVENTS", O_WRONLY | O_CREAT, mode, &mqa);

    // run this task at high priority
	taskPrioritySet(taskIdSelf(), 3);
	
    // Event loop setup
    result = AMGetSelfAppID(&altAppID);
    result = EMOpen(altAppID, 0);
    
	while(TRUE)
	{
		// don't hog the system
		if (event_Sem == 0)
		{
			event_Sem = semCCreate(SEM_Q_PRIORITY, 0);
		}
		semTake(event_Sem, WAIT_FOREVER);

		while (TRUE)
		{
			if ((result = EMGetEvent( altAppID, &event )) != 0)
			{
				// event queue is empty
				break;
			}
			
			switch (event->fEvClass)
			{
				case kButtonClassEvent:
				{
					if ((camera_type == kTypeKodak2) || (camera_type == kTypeHP1) || (camera_type == kTypeHP2))
					{
						switch (event->fButtonIndex)
						{
							case kDigitaUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_UP;
										break;
									}
									case 1:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 2:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 3:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									default:
									{
										lastKey = KEY_UP;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 1:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 2:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 3:
									{
										lastKey = KEY_UP;
										break;
									}
									default:
									{
										lastKey = KEY_LEFT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 1:
									{
										lastKey = KEY_UP;
										break;
									}
									case 2:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 3:
									{
										lastKey = KEY_DOWN;
										break;
									}
									default:
									{
										lastKey = KEY_RIGHT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 1:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 2:
									{
										lastKey = KEY_UP;
										break;
									}
									case 3:
									{
										lastKey = KEY_LEFT;
										break;
									}
									default:
									{
										lastKey = KEY_DOWN;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
	
							case kDigitaSoftKey1:
							{
								lastKey = '1';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaSoftKey2:
							{
								lastKey = KEY_ESC;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaSoftKey3:
							{
								lastKey = '5';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaOverlay:
							{
								lastKey = KEY_ENTER;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaLCDOnOff:
							{
								lastKey = KEY_ENTER;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaMenu:
							{
								lastKey = KEY_TAB;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaZoomIn:
							{
								lastKey = KEY_LALT;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaZoomOut:
							{
								lastKey = KEY_LCONTROL;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaRecord:
							{
								lastKey = '`';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaShutter1:
							{
								lastKey = KEY_DOWN;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDigitaShutter2:
							{
								lastKey = KEY_F12;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
//							case kDigitaLCDStatus1:
//							case kDigitaLCDStatus2:
//							case kDigitaSpare1:
//							case kDigitaSpare2:
//							case kDigitaPlayMode:
//							case kDigitaHostMode:
//							case kDigitaReviewMode:
//							case kDigitaCaptureMode:
							default:
							{
								break;
							}
						}
	
						if (camera_type == kTypeHP1)
						{
							if ((event->fButtonIndex == kDigitaPowerOnOff) 
								&& event->fPosition) // note the difference with below, after button down no more events
							{
								// Stop the MAME task so we can shutdown
								taskSuspend(mameTaskID);
#ifdef DIGITA_SOUND
								taskSuspend(soundTaskID);
#endif
								pmPowerDown(1);
								
								// Wait for power off
								while(TRUE)
									taskDelay(10);
							}
						}
						else if ((camera_type == kTypeKodak2) || (camera_type == kTypeHP2))
						{
							if ((event->fButtonIndex == kDigitaPowerOnOff) 
								&& (event->fPosition == 0)) // note the difference with above
							{
								// Stop the MAME task so we can shutdown
								taskSuspend(mameTaskID);
#ifdef DIGITA_SOUND
								taskSuspend(soundTaskID);
#endif
								// this now works correctly becaue of correct init code
								SUPowerDown(0);
								
								// Wait for power off
								while(TRUE)
									taskDelay(10);
							}
						}
					}
					else if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1))
					{
						switch (event->fButtonIndex)
						{
							case kUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_UP;
										break;
									}
									case 1:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 2:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 3:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									default:
									{
										lastKey = KEY_UP;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 1:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 2:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 3:
									{
										lastKey = KEY_UP;
										break;
									}
									default:
									{
										lastKey = KEY_LEFT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 1:
									{
										lastKey = KEY_UP;
										break;
									}
									case 2:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 3:
									{
										lastKey = KEY_DOWN;
										break;
									}
									default:
									{
										lastKey = KEY_RIGHT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 1:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 2:
									{
										lastKey = KEY_UP;
										break;
									}
									case 3:
									{
										lastKey = KEY_LEFT;
										break;
									}
									default:
									{
										lastKey = KEY_DOWN;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
	
							case kSoftkeyLeft:
							{
								lastKey = '1';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kSoftkeyMid:
							{
								lastKey = KEY_ESC;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kSoftkeyRight:
							{
								lastKey = '5';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kOverlayButton:
							{
								lastKey = KEY_ENTER;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMenuButton:
							{
								lastKey = KEY_TAB;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kZoomIn:
							{
								lastKey = KEY_LALT;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kZoomOut:
							{
								lastKey = KEY_LCONTROL;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kRecordButton:
							{
								lastKey = '`';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kShutter1:
							{
								lastKey = KEY_DOWN;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kShutter2:
							{
								lastKey = KEY_F12;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
//							case kLCDStatus1:
//							case kLCDStatus2:
//							case kMode0Button:
//							case kMode1Button:
//							case kMode2Button:
//							case kMode3Button:
//							case kSpare1:
//							case kSpare2:
							default:
							{
								break;
							}
						}
						
						if ((event->fButtonIndex == kPowerEvent) 
							&& (event->fPosition == 0))
						{
							// Stop the MAME task so we can shutdown
							taskSuspend(mameTaskID);
#ifdef DIGITA_SOUND
							taskSuspend(soundTaskID);
#endif
// this one works great for DC220, DC260, & DC265
							PMPowerDown( 0 );
							// Wait for power off					
							while(TRUE)
								taskDelay(10);
						}
					}
					else if (camera_type == kTypeMinolta1)
					{
						switch (event->fButtonIndex)
						{
							case kMinoltaUpArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_UP;
										break;
									}
									case 1:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 2:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 3:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									default:
									{
										lastKey = KEY_UP;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaLeftArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 1:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 2:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 3:
									{
										lastKey = KEY_UP;
										break;
									}
									default:
									{
										lastKey = KEY_LEFT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaRightArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 1:
									{
										lastKey = KEY_UP;
										break;
									}
									case 2:
									{
										lastKey = KEY_LEFT;
										break;
									}
									case 3:
									{
										lastKey = KEY_DOWN;
										break;
									}
									default:
									{
										lastKey = KEY_RIGHT;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaDownArrow:
							{
								switch (gPadOrientation)
								{
									case 0:
									{
										lastKey = KEY_DOWN;
										break;
									}
									case 1:
									{
										lastKey = KEY_RIGHT;
										break;
									}
									case 2:
									{
										lastKey = KEY_UP;
										break;
									}
									case 3:
									{
										lastKey = KEY_LEFT;
										break;
									}
									default:
									{
										lastKey = KEY_DOWN;
										break;
									}
								}
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
	
							case kMinoltaSoftkeyLeft:
							{
								lastKey = '1';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaSoftkeyMid:
							{
								lastKey = KEY_ESC;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaSoftkeyRight:
							{
								lastKey = '5';
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaStatusButton:
							{
								lastKey = KEY_LALT;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaOverlayButton:
							{
								lastKey = KEY_ENTER;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaMenuButton:
							{
								lastKey = KEY_TAB;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaShutter1:
							{
								lastKey = KEY_DOWN;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
							case kMinoltaShutter2:
							{
								lastKey = KEY_F12;
								buttomMsg = lastKey | (event->fPosition << 8);
			 					mq_send(digita_event_mq, &buttomMsg, sizeof(buttomMsg), 0);
								break;
							}
//							case kMode0Button:
//							case kMode1Button:
//							case kMode2Button:
//							case kMode3Button:
							default:
							{
								break;
							}
						}
						
						if ((event->fButtonIndex == kMinoltaPowerEvent) 
							&& (event->fPosition == 0))
						{
							// Stop the MAME task so we can shutdown
							taskSuspend(mameTaskID);
#ifdef DIGITA_SOUND
							taskSuspend(soundTaskID);
#endif
							PMPowerDown(0);
							// Wait for power off					
							while(TRUE)
								taskDelay(10);
						}
					}
					break;
				}
				default:
				{
					break;
				}
			}
	
			result = EMReleaseEventRecord(event);
		}
	}
}

/* return a list of all available keys */
const struct KeyboardInfo *osd_get_key_list(void)
{
	return fullkeylist;
}

int led_state[4] = {0,0,0,0};

void osd_led_w(int led, int on)
{
	// ooooh this is so cool I can even emulate the game LED's!!!
	if ((camera_type == kTypeKodak0) || (camera_type == kTypeKodak1) || (camera_type == kTypeKodak2))
	{
		if (on)
		{
			switch (led)
			{
				case 0:
				{
					if (led_state[0] == 0)
					{
						MPUSetLED( LED_VIEWFINDER | LED_ON | LED_GREEN | LED_SOLID );
						led_state[0] = 1;
					}
					break;
				}
				case 1:
				{
					if (led_state[1] == 0)
					{
						MPUSetLED( LED_AUDIOREC | LED_ON | LED_GREEN | LED_SOLID );
						led_state[1] = 1;
					}
					break;
				}
				case 2:
				{
					if (led_state[2] == 0)
					{
						MPUSetLED( LED_SELFTIMER | LED_ON | LED_GREEN | LED_SOLID );
						led_state[2] = 1;
					}
					break;
				}
				case 3:
				{
					if (led_state[3] == 0)
					{
						MPUSetLED( LED_CF | LED_ON | LED_GREEN | LED_SOLID );
						led_state[3] = 1;
					}
					break;
				}
			}
		}
		else
		{
			switch (led)
			{
				case 0:
				{
					if (led_state[0] == 1)
					{
						MPUSetLED( LED_VIEWFINDER | LED_OFF );
						led_state[0] = 0;
					}
					break;
				}
				case 1:
				{
					if (led_state[1] == 1)
					{
						MPUSetLED( LED_AUDIOREC| LED_OFF );
						led_state[1] = 0;
					}
					break;
				}
				case 2:
				{
					if (led_state[2] == 1)
					{
						MPUSetLED( LED_SELFTIMER  | LED_OFF );
						led_state[2] = 0;
					}
					break;
				}
				case 3:
				{
					if (led_state[3] == 1)
					{
						MPUSetLED( LED_CF | LED_OFF );
						led_state[3] = 0;
					}
					break;
				}
			}
		}
	}
}

/* check if a key is pressed. The keycode is the standard PC keyboard code, as */
/* defined in osdepend.h. Return 0 if the key is not pressed, nonzero otherwise. */
int osd_is_key_pressed(int keycode)
{
	int state = keyStates[keycode];
	
	if (state)
	{
		if (state > 1)
		{
			if (tickGet() > state)
			{	
				keyStates[keycode] = 0;
				return 0;
			}
		}
		return 1;
	}
	
	return 0;
}

int osd_readkey_unicode(int flush)
{
	return 0;
}

/* wait for a key press and return the keycode */
int osd_wait_keypress(void)
{
	while (gLastKeyState == 0)
	{
		taskDelay(5);
	}

	return gLastKey;
}

#define MAX_JOY 1

static struct JoystickInfo joylist[MAX_JOY] =
{
	{0, 0, 0} /* end of table */
};

/* return a list of all available joys */
const struct JoystickInfo *osd_get_joy_list(void)
{
	return joylist;
}


int osd_is_joy_pressed(int joycode)
{
	return 0;
}

void osd_poll_joysticks(void)
{
}

/* return a value in the range -128 .. 128 (yes, 128, not 127) */
void osd_analogjoy_read(int player,int *analog_x, int *analog_y)
{
	*analog_x = 0;
	*analog_y = 0;
}

int osd_joystick_needs_calibration (void)
{
	return 0;
}

void osd_joystick_start_calibration (void)
{
}

char *osd_joystick_calibrate_next (void)
{
	return 0;
}

void osd_joystick_calibrate (void)
{
}

void osd_joystick_end_calibration (void)
{
}

void osd_trak_read(int player,int *deltax,int *deltay)
{
	*deltax = 0;
	*deltay = 0;
}

void osd_customize_inputport_defaults(struct ipd *defaults)
{
}