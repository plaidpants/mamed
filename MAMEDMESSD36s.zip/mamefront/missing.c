/* The DC290 is missing some GNU generated functions so I will force
   them to be included here. */

extern void __adddf3(void);
extern void __addsf3(void);
extern void __divdf3(void);
extern void __divdi3(void);
extern void __divsf3(void);
extern void __eqdf2(void);
extern void __eqsf2(void);
extern void __extendsfdf2(void);
extern void __fixdfsi(void);
extern void __fixsfsi(void);
extern void __fixunsdfsi(void);
extern void __floatsidf(void);
extern void __floatsisf(void);
extern void __gedf2(void);
extern void __gtdf2(void);
extern void __gtsf2(void);
extern void __ledf2(void);
extern void __ltdf2(void);
extern void __ltsf2(void);
extern void __moddi3(void);
extern void __muldf3(void);
extern void __mulsf3(void);
extern void __nedf2(void);
extern void __negdf2(void);
extern void __subdf3(void);
extern void __subsf3(void);
extern void __truncdfsf2(void);
extern void __udivdi3(void);
extern void __umoddi3(void);
extern void __divsi3(void);
extern void __fixunssfsi(void);
extern void __modsi3(void);
extern void __mulsi3(void);
extern void __udivsi3(void);
extern void __umodsi3(void);
extern void abs(void);
extern void atan(void);
extern void ceil(void);
extern void cos(void);
extern void exp(void);
extern void floor(void);
extern void log10(void);
extern void sin(void);
extern void pow(void);
extern void rand(void);
 
void * missing[] = {
__divsi3,
__fixunssfsi,
__modsi3,
__mulsi3,
__udivsi3,
__umodsi3,
__adddf3,
__addsf3,
__divdf3,
__divdi3,
__divsf3,
__eqdf2,
__eqsf2,
__extendsfdf2,
__fixdfsi,
__fixsfsi,
__fixunsdfsi,
__floatsidf,
__floatsisf,
__gedf2,
__gtdf2,
__gtsf2,
__ledf2,
__ltdf2,
__ltsf2,
__moddi3,
__muldf3,
__mulsf3,
__nedf2,
__negdf2,
__subdf3,
__subsf3,
__truncdfsf2,
__udivdi3,
__umoddi3,
abs,
atan,
ceil,
cos,
exp,
floor,
log10,
pow,
rand,
sin
};