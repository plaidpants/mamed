#ifndef __SOUNDPRIVATE__
#define __SOUNDPRIVATE__

#ifndef __FPTYPES__
#include <FPTypes.h>
#endif

#ifndef __FPSOUND__
#include <FPSound.h>
#endif

#define kSNDConfigureCodecOutput 0x00000001
#define kSNDConfigureCodecInput 0x00000002
#define kSNDHWPowerAndClockOff 0
#define kSNDHWClockOn 1
#define kSNDHWPowerAmpOn 2
#define kSNDHWPowerAmpOff 3
#define kSNDCodecFrameSize 2
#define kSNDDefaultRXASetup 0x0187
#define kSNDDefaultTXASetup 0x0187
#define kSNDChannelCount 4
#define kSNDStackSize (4 * 1024)
#define kSNDMessageCtlParamsCount 4
#define kSNDMaxMessageCount 16
#define kSND16BitSampleLengthMask (~(0x01UL))
#define kSND16MonoSampleSize 2
#define kSNDLPCMSamplesPerBlock 1
#define kSNDADPCMCompressionRatio 4
#define kSNDADPCMSamplesPerByte (kSNDADPCMCompressionRatio / kSND16MonoSampleSize) 
#define kSNDADPCMSamplesPerBlock (kSNDADPCMSamplesPerByte * kSNDADPCMSampleBlockSize)
#define kSND16MonoSampleToFrameMultiple (kSNDCodecFrameSize / kSND16MonoSampleSize)
#define kSNDCodecFrameControlSize (kSNDCodecFrameSize - kSND16MonoSampleSize)
#define kSNDDefaultNumberOfADPCMBlocksPerBD 1
#define kSNDDefaultNumberOfFramesPerBD (kSNDDefaultNumberOfADPCMBlocksPerBD * kSNDADPCMSamplesPerBlock * kSND16MonoSampleToFrameMultiple)
#define kSNDDefaultBDLength (kSNDDefaultNumberOfFramesPerBD * kSNDCodecFrameSize)
#define kSNDBDSyncOffset 0

#define kSMCBDInitTransparent 0x0000U	// no interrupt will be generated when this BD is serviced.
#define kSMCBDLastBDInTable 0x2000U		// this is the "W" (wrap or final BD in table) bit in the
#define kSMCBDInterrupt 0x1000U			// this is the "I" (interrupt may be generated) bit in the
#define kSMCBDReady 0x8000U				// this is the "R" (ready) bit in the SMC buffer descriptor.
#define kSMCBDLastByteInMessage 0x0800U	// this is the "L" (last) bit in the SMC buffer descriptor.
#define kSMCBDUnderrun	0x0002U			// this is the "UN" (underrun) bit in the SMC buffer descriptor.
#define kSMCBDOverrun	0x0002U			// this is the "OV" (overrun) bit in the SMC buffer descriptor.
#define kSMCBDReceiveEmpty 0x8000U		// this is the "E" bit in the receive buffer descriptor.
#define kSMCBDContinuousMode 0x0200U	// this is the "CM" bit in the SMC buffer descriptor.
#define kSMCEventBufferIsTransmitted 0x02	// this is the "TX" bit in the SMC Event register.
#define kSMCEventReceiveBufferIsClosed 0x01	// this is the "RX" bit in the SMC Event register.
#define kSMCEventUnderrun 0x10				// this is the TXE (underrun) bit in the SMC Event register.
#define kSMCEventBusy 0x04					// this is the BSY (busy condition) bit in the SMC Event register.
#define kSMC8BitTransparentNormal 0x3930U
#define kSMC16BitTransparentNormal 0x7B30U	// 16 bit data, reversed data, transmit low address byte first (CHRP821).
#define kSMCEnableTransmitter 0x0002U
#define kSMCEnableReceiver 0x0001U

#define kUCodeOffset 0xD00
#define kSMC2TxBDOffset (kUCodeOffset + 0x0060)	
#define	kSMC2TxBD(dprBase)	((VUINT16 *)(dprBase + kSMC2TxBDOffset))	

typedef enum
{
	kSNDSync = 1,
	kSNDAsync = 2
} TSNDMode;

struct TSNDChannelParams
{
	TInt		fChannelTask;
	TCStr15		fQueueName;
	TLong		fSendQueueID;
	TLong		fReceiveQueueID;
	TSNDCallBackProcPtr	fChannelCallBack;
	TSNDCallBackProcPtr	fClientCallBack;
	TLong		fChannelStatus;
	TLong		fSyncStatus;
	TULong		fInputLevel;
	TULong		fOutputLevel;
	TBoolean	fSwAGC;
	TBoolean	fHwAGC;
	TBoolean	fBilevelVolumeFull;
};
typedef struct TSNDChannelParams TSNDChannelParams;
typedef TSNDChannelParams *TSNDChannelParamsPtr;

typedef struct TAUDBufferDescriptor
{
	TUShort	fStatus				__attribute ((packed));
	TUShort	fDataLength			__attribute ((packed));
	TUChar	*fBufferPointer		__attribute ((packed));
} TAUDBufferDescriptor;

extern TUShort gSNDCodecPlaySettings[2];

/* prototypes */
extern TErrCo sndWriteCodec(TSNDParamBlockPtr snd, TShort codecMode, TChar *pSndChannelParams, TULong *pIOCount);
extern TErrCo sndConfigureCodec(TULong configure);
extern TErrCo sndOpenCodec(void);
extern TErrCo sndCloseCodec(void);
extern TErrCo sndHWPowerCodec( TUInt n );
extern TErrCo sndHWSetBilevelVolume(TBoolean volumeFull);
extern TErrCo sndMuteAudio(TBoolean muteOn);
extern TErrCo sndGetChannelParams(TSNDChannel channel, TSNDChannelParamsPtr *pSndChannelParamsPtr);
extern TErrCo sndInitCodecTransmit(TVoid);
extern TErrCo sndCloseCodecTransmit(TVoid);

extern void SNDSMC2InterruptHandler(void);

//
// Unity and 290
extern void AUD1InterruptHandler(void *, void *);
extern TErrCo AUDConfigureCodec(TULong configure);
extern TErrCo AUDOpenCodec(void);
extern TErrCo AUDCloseCodec(void);
extern TErrCo AUDHWSetBilevelVolume(TBoolean volumeFull);
extern TErrCo AUDMuteAudio(TBoolean muteOn);
extern TErrCo AUDInitCodecTransmit(TVoid);
extern TErrCo AUDCloseCodecTransmit(TVoid);
extern TErrCo AUDPowerCodec(TUInt n);

#endif	/* __SOUNDPRIVATE__	*/