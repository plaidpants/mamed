#include "osd_cpu.h"


#define TICKER unsigned long
#define TICKS_PER_SEC 60
#define ticker tickGet
