#ifndef OSD_DEPEND_H
#define OSD_DEPEND_H

#include "SoundPrivate.h"
#include <semLib.h>

/* HP C500 & Kodak DC290 button IDs */
typedef enum 
{
    kDigitaMenu,
    kDigitaOverlay,
    kDigitaPortraitLeft,
    kDigitaPortraitRight,
    kDigitaLCDStatus2,
    kDigitaLCDStatus1,
    kDigitaSpare1,
    kDigitaSpare2,
    kDigitaSoftKey2,
    kDigitaSoftKey3,
    kDigitaZoomOut,
    kDigitaZoomIn,
    kDigitaShutter1,
    kDigitaShutter2,
    kDigitaRecord,
    kDigitaInstantReview,
    kDigitaHostMode,
    kDigitaPlayMode,
    kDigitaUpArrow,
    kDigitaLeftArrow,
    kDigitaRightArrow,
    kDigitaDownArrow,
    kDigitaLCDOnOff,
    kDigitaSoftKey1,
    kDigitaPowerOnOff,
    kDigitaUnused6,
    kDigitaUnused5,
    kDigitaUnused4,
    kDigitaUnused3,
    kDigitaUnused2,
    kDigitaUnused1,
    kDigitaUnused0,
    kDigitaReviewMode,
    kDigitaCaptureMode,
    kDigitaLandscape
} TBTNDigitaButtonId;

// Kodak DC220, DC260, & DC265 button IDs */
#define kSoftkeyLeft   					14
#define kOverlayButton 					16
#define kDownArrow     					30
#define kRightArrow    					28
#define kLeftArrow     					29
#define kUpArrow       					31
#define kRecordButton  					17
#define kShutter2      					 9
#define kShutter1      					10
#define kZoomIn        					26
#define kZoomOut       					27
#define kSoftkeyRight  					12
#define kSoftkeyMid    					13
#define kMenuButton    					25
#define kPowerEvent    					11
#define kDiskEvent     					102
#define kSleepEvent   					103
#define kStatusLCDEvent    				104
#define kAVJackEvent   					105
#define kStatusLCDBatteryStatusEvent  	106
#define kStatusLCDCFAnimationEvent  	107
#define kMode0Button   					23
#define kMode1Button   					22
#define kMode2Button   					21
#define kMode3Button   					20
#define kShutterHome    				 8
#define kInstantReview  				116
#define kSpare2        					124
#define kSpare1        					125
#define kLCDStatus1    					126
#define kLCDStatus2    					127
#define kPortrait      					128
#define kLandscape     					129
#define kLCDOnOff      					130
#define kAlertEvent    					1100

/* Minolta button IDs */
#define kMinoltaLCDOnOff				  0
#define kMinoltaPowerEvent				  1
#define kMinoltaShutter2				  2
#define kMinoltaShutter1				  3
#define kMinoltaMode3Button				  4 
#define kMinoltaMode2Button				  5
#define kMinoltaMode0Button				  6 
#define kMinoltaMode1Button				  7
#define kMinoltaUpArrow					  8
#define kMinoltaDownArrow				  9
#define kMinoltaLeftArrow				 10
#define kMinoltaRightArrow				 11
#define kMinoltaSoftkeyRight			 12
#define kMinoltaSoftkeyMid				 13
#define kMinoltaSoftkeyLeft				 14
#define kMinoltaMenuButton				 16
#define kMinoltaOverlayButton			 17
#define kMinoltaStatusButton			 18
#define kMinoltaRecordButton			 19
#define kMinoltaMacroButton				 21
#define kMinoltaAVJackButton			 22
#define kMinoltaACJackButton			 23
#define kMinoltaDiskEvent    			102

/* Digita Common Structures */
typedef struct {
	char fPName[4];
	long fType;
	char fStr[32];
} TPARMNameTypeValue;
typedef TPARMNameTypeValue *TPARMNameTypeValuePtr;

typedef enum {
    kButtonClassEvent = 2,
} TEMEventClass;

typedef struct {
	unsigned short		fEvClass;
	unsigned long		fEvModifiers;
	long 				fPosition;
	long    			fButtonIndex;
	long				fLength;
	void *				fDataPtr;
	void *				fDeallocProc;
} TEMEventRecord;
typedef TEMEventRecord *TEMEventRecordPtr;

/* Common Digita function prototypes */
extern void  (*GMInitGraf)(void *);
extern void  (*GMInitFonts)(void);
extern short (*AMGetSelfAppID)(char * appID);
extern short (*EMOpen)(const char appID, int signo);
extern short (*EMGetEvent)(const char appID, TEMEventRecordPtr *message);
extern short (*EMReleaseEventRecord)(TEMEventRecordPtr message);
extern short (*MMNewAlignedPtr)(unsigned long size, unsigned long alignment, char *p);
extern short (*MMDisposePtr)(char * p);
extern short (*PARMGetProductInfo) (char *tag, TPARMNameTypeValuePtr ntvp);
extern unsigned long (*PMPowerDown)(unsigned long deepSleepTime);

/* Minolta & Kodak DC220, DC260, DC265 */
extern short (*LMEnableLCDController)(void);
extern short (*LMSetupBuffers)(unsigned long *lcdBuffer, unsigned long *displayBuffer, char interlace);
extern short (*LMSwitchBuffer)(unsigned long *lcdBuffer);

/* Kodak DC290 */
extern void (*LMSetUpInterlacedMode)(unsigned long *lcdPtr, unsigned long *displayPtr);

/* HP C500 & Kodak DC290 */
extern void (*LMAllocateBuffers)(void);
extern void (*LMSwitchNormalMode)(void);
extern void (*LMSwitchToNextLiveviewFrame)(void);
extern void (*LMSwitchLiveviewMode)(void);
extern char * (*LMGetNextLiveviewFrame)(void);
extern short (*AMAppInit)(long appStyle);
extern void (*AMAppExit)(const char appID);

/* Kodak DC290 only */
extern unsigned long (*SUPowerDown)(unsigned long deepSleepTime);
extern STATUS CreateSymtbl(void *);
extern STATUS EmptySymtbl(void);
extern void HYInit(void);
extern short (*CMInit) (void);

/* HP C500 only */
extern unsigned long pmPowerDown(unsigned long deepSleepTime);

extern unsigned long (*CAPowerDown)(unsigned long deepSleepTime);

/* Minolta 1500 EX only */
extern int (*MPUSendLens)(unsigned int value);

/* Kodak DC220, DC260, DC265, & DC290 only */
#define LED_VIEWFINDER 		0x00000000
#define LED_OFF 			0x00000200
extern int (*MPUSetLED)(unsigned int ledstat);
extern int (*MPUInit)(void);
extern int smMconStat;

/* DCAM 2K sram address, use for color table lookup */
#define PHYS_M_DPSRAM_MEM0      0x1c000000
#define	PHYS_TO_K1(x)			((unsigned)(x)|0xA0000000)
#define M_DPSRAM_MEM0       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0)
#define M_DPSRAM_MEM1       	PHYS_TO_K1(PHYS_M_DPSRAM_MEM0 + 1024)

#define M_CPM_MEM1       	0xff002000
#define M_CPM_MEM2       	0xff002400
#define M_CPM_MEM3       	0xff002800

#define strKodakVendorName						"Eastman Kodak Company"
#define strKodakDC220ProductName				"KODAK DIGITAL SCIENCE DC220"
#define strKodakDC260ProductName				"KODAK DIGITAL SCIENCE DC260"
#define strKodakDC265ProductName				"KODAK DC265 ZOOM DIGITAL CAMERA"
#define strKodakDC290ProductName				"KODAK DC290 ZOOM DIGITAL CAMERA"
#define strHPVendorName							"Hewlett Packard"
#define strHPC500ProductName					"HP PhotoSmart C500"
#define strMinoltaVendorName					"Minolta Co., Ltd."
#define strMinoltaDimage1500EXProductName		"Dimage EX"

#define kTypeKodak1 		0
#define kTypeKodak2 		1
#define kTypeHP1 			2
#define kTypeMinolta1 		3

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <ioLib.h>

INLINE void DEBUG_PRINT(char * message)
{
	FILE *log;
	
	log = fopen("/B/debug.log", "a");
	
	if(log)
	{
		fprintf(log, "%s\r\n", message);
		fclose(log);
	}
}

INLINE STATUS DEBUG_CreateSymtbl(void * A)
{
	STATUS val;
	DEBUG_PRINT("Before CreateSymtbl");
	val = CreateSymtbl(A);
	DEBUG_PRINT("After CreateSymtbl");
	return val;
}

#define CreateSymtbl DEBUG_CreateSymtbl

INLINE STATUS DEBUG_EmptySymtbl(void * A)
{
	STATUS val;
	DEBUG_PRINT("Before EmptySymtbl");
	val = EmptySymtbl(A);
	DEBUG_PRINT("After EmptySymtbl");
	return val;
}

#define EmptySymtbl DEBUG_EmptySymtbl

INLINE void DEBUG_GMInitGraf(void * A)
{
	DEBUG_PRINT("Before GMInitGraf");
	GMInitGraf(A);
	DEBUG_PRINT("After GMInitGraf");
}

#define GMInitGraf DEBUG_GMInitGraf

INLINE void DEBUG_GMInitFonts(void)
{
	DEBUG_PRINT("Before GMInitFonts");
	GMInitFonts();
	DEBUG_PRINT("After GMInitFonts");
}

#define GMInitFonts DEBUG_GMInitFonts

INLINE short DEBUG_AMGetSelfAppID(char * appID)
{
	short val;
	DEBUG_PRINT("Before AMGetSelfAppID");
	val = AMGetSelfAppID(appID);
	DEBUG_PRINT("After AMGetSelfAppID");
	return val;
}

#define AMGetSelfAppID DEBUG_AMGetSelfAppID

INLINE short DEBUG_EMOpen(const char appID, int signo)
{
	short val;
	DEBUG_PRINT("Before EMOpen");
	val = EMOpen(appID, signo);
	DEBUG_PRINT("After EMOpen");
	return val;
}

#define EMOpen DEBUG_EMOpen

INLINE short DEBUG_EMGetEvent(const char appID, TEMEventRecordPtr *message)
{
	short val;
	DEBUG_PRINT("Before EMGetEvent");
	val = EMGetEvent(appID, message);
	DEBUG_PRINT("After EMGetEvent");
	return val;
}

#define EMGetEvent DEBUG_EMGetEvent

INLINE short DEBUG_EMReleaseEventRecord(TEMEventRecordPtr message)
{
	short val;
	DEBUG_PRINT("Before EMReleaseEventRecord");
	val = EMReleaseEventRecord(message);
	DEBUG_PRINT("After EMReleaseEventRecord");
	return val;
}

#define EMReleaseEventRecord DEBUG_EMReleaseEventRecord

INLINE short DEBUG_MMNewAlignedPtr(unsigned long size, unsigned long alignment, char *p)
{
	short val;
	DEBUG_PRINT("Before MMNewAlignedPtr");
	val = MMNewAlignedPtr(size,alignment,p);
	DEBUG_PRINT("After MMNewAlignedPtr");
	return val;
}

#define MMNewAlignedPtr DEBUG_MMNewAlignedPtr

INLINE short DEBUG_PARMGetProductInfo(char *tag, TPARMNameTypeValuePtr ntvp)
{
	short val;
	DEBUG_PRINT("Before PARMGetProductInfo");
	val =  PARMGetProductInfo(tag, ntvp);
	DEBUG_PRINT("After PARMGetProductInfo");
	return val;
}

#define PARMGetProductInfo DEBUG_PARMGetProductInfo

INLINE unsigned long DEBUG_PMPowerDown(unsigned long deepSleepTime)
{
	unsigned long val;
	DEBUG_PRINT("Before PMPowerDown");
	val = PMPowerDown(deepSleepTime);
	DEBUG_PRINT("After PMPowerDown");
	return val;
}

#define PMPowerDown DEBUG_PMPowerDown
#endif

#endif	/* defined OSD_DEPEND_H */