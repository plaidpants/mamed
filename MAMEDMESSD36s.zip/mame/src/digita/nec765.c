/*****************************************************************************
 *
 *	nec765.c
 *
 *	allow direct access to a PCs NEC 765 floppy disc controller
 *
 *	!!!! this is ALPHA - be careful !!!!
 *
 *****************************************************************************/

#include "driver.h"

int osd_fdc_init(void)
{
    return 1;
}

void osd_fdc_exit(void)
{
}

void osd_fdc_motors(UINT8 unit)
{
}

/*****************************************************************************
 * specify density, sectors per track and sector length
 *****************************************************************************/
void osd_fdc_density(UINT8 unit, UINT8 density, UINT8 tracks, UINT8 spt, UINT8 eot, UINT8 secl)
{
}

void osd_fdc_interrupt(int param)
{
}

UINT8 osd_fdc_recal(UINT8 * track)
{
	return 0;
}

UINT8 osd_fdc_seek(UINT8 t, UINT8 * track)
{
	return 0;
}

UINT8 osd_fdc_step(int dir, UINT8 * track)
{
	return 0;
}

UINT8 osd_fdc_format(UINT8 t, UINT8 h, UINT8 spt, UINT8 * fmt)
{
	return 0;
}

UINT8 osd_fdc_put_sector(UINT8 track, UINT8 side, UINT8 head, UINT8 sector, UINT8 *buff, UINT8 ddam)
{
	return 0;
}

UINT8 osd_fdc_get_sector(UINT8 track, UINT8 side, UINT8 head, UINT8 sector, UINT8 *buff)
{
	return 0;
}
