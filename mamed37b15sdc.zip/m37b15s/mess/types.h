#ifndef TYPES_H
#define TYPES_H

/* types used by the CPU emulations */
typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned       dword;

#endif
