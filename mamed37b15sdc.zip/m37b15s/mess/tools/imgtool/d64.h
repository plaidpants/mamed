void d64_open_helper (void);
int cbm_compareNames (const unsigned char *left, const unsigned char *right);

