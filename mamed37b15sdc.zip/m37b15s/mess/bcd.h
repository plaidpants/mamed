
#ifdef __cplusplus
extern "C" {
#endif

	int bcd_adjust(int value);
	int dec_2_bcd(int a);
	int bcd_2_dec(int a);

#ifdef __cplusplus
}
#endif
