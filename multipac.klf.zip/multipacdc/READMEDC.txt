To run Multipac for Dreamcast with the KOSH command line interface. Burn a CD with MULTIPAC.KLF and a ROMS directory at the root level.

Put your pacman roms in a Roms Folder. You must unzip the roms and put them in separate folders. The roms and directories must be named differently for different versions of pacman. NOTE: don't ask me about where to find roms.

EXAMPLE CD LAYOUT:
/
/roms/

/roms/crush/
/roms/crush/CR1
/roms/crush/CR2
/roms/crush/CR3
/roms/crush/CR4
/roms/crush/CR5
/roms/crush/CR6
/roms/crush/CR7
/roms/crush/CR8
/roms/crush/CRA
/roms/crush/CRB
/roms/crush/CRC
/roms/crush/CRD

/roms/HANGLY/hangly.5e
/roms/hangly.5f
/roms/hangly.6e
/roms/hangly.6f
/roms/hangly.6h
/roms/hangly.6j

/roms/MSPACMAN/5e
/roms/MSPACMAN/5f
/roms/MSPACMAN/boot1
/roms/MSPACMAN/boot2
/roms/MSPACMAN/boot3
/roms/MSPACMAN/boot4
/roms/MSPACMAN/boot5
/roms/MSPACMAN/boot6

/roms/namcopac/namcopac.5e
/roms/namcopac/namcopac.5f
/roms/namcopac/namcopac.6e
/roms/namcopac/namcopac.6f
/roms/namcopac/namcopac.6h
/roms/namcopac/namcopac.6j

/roms/PACMAN/pacman.5e
/roms/PACMAN/pacman.5f
/roms/PACMAN/pacman.6e
/roms/PACMAN/pacman.6f
/roms/PACMAN/pacman.6h
/roms/PACMAN/pacman.6j

/roms/pacmod/
/roms/pacmod/6e.mod
/roms/pacmod/pacman.6f
/roms/pacmod/6h.mod
/roms/pacmod/pacman.6j
/roms/pacmod/5e
/roms/pacmod/5f

/roms/piranha/
/roms/piranha/pr1.cpu
/roms/piranha/pr2.cpu
/roms/piranha/pr3.cpu
/roms/piranha/pr4.cpu
/roms/piranha/pr5.cpu
/roms/piranha/pr6.cpu
/roms/piranha/pr7.cpu
/roms/piranha/pr8.cpu

/roms/puckman/puckman.5e
/roms/puckman/puckman.5f
/roms/puckman/puckman.6e
/roms/puckman/puckman.6f
/roms/puckman/puckman.6h
/roms/puckman/puckman.6j

Boot KOS and instert the multipac CD. You can run any of these versions of pacman by just typing from the KOSH command line. Running multipac without a rom name will default to mspacman.

EXAMPLE:
$ multipac pacmod
$ multipac mspacman
$ multipac crush
$ multipac piranha
$ mutlipac

I also support generic rom names just name the directory the same as the rom suffix. From the KOSH command line just use the directory name as the rom name.

EXAMPLE CD LAYOUT:
/
/roms/
/roms/namcopac/
/roms/namcopac.6e
/roms/namcopac.6f
/roms/namcopac.6h
/roms/namcopac.6j
/roms/namcopac.5e
/roms/namcopac.5f

EXAMPLE:
$ multipac namcopac

Multipac Keys & Controller Buttons:
(START)      3       Insert coin
(A)          1       Start 1 player game
(B)          2       Start 2 player game
(D-PAD)      Arrows  Move around
             F1      Skip level
             F2      Test mode
             Tab     Change dip switch settings
             P       Pause
(Y)          ESC     Exit emulator

Don't ask me how to make a bootable CD as I don't even know how to make one myself.

Have fun.

James Surine,
xevious@holonet.net